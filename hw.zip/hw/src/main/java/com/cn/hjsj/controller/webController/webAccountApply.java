package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.User;
import com.cn.hjsj.pojo.UserState;
import com.cn.hjsj.service.IUserService;
import com.cn.hjsj.service.IUserStateService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Create by WangFeng on 2018-07-23


@Controller
@RequestMapping("/webAccountApply")
public class webAccountApply {

    @Resource
    private IUserStateService userStateService;
    @Resource
    private IUserService userService;

    @ResponseBody
    @RequestMapping("/accApplication")
    @Permission("login")
    public Map accApplication(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("user");
            arraylist.add("password");
            arraylist.add("tel");
            arraylist.add("enterpriseName");
            arraylist.add("enterpriseID");
            arraylist.add("licenseID");
            arraylist.add("licenseAddress");
            arraylist.add("enterpriseAddress");
            arraylist.add("licensePhoto");
            arraylist.add("liableName");
            arraylist.add("liableID");
            arraylist.add("liableIDAddress");
            arraylist.add("liableAddress");
            arraylist.add("liablePhoto1");
            arraylist.add("liablePhoto2");
            arraylist.add("agencyName");
            arraylist.add("agencyID");
            arraylist.add("agencyIDAddress");
            arraylist.add("agencyAddress");
            arraylist.add("agencyTel");
            arraylist.add("agencyPhoto1");
            arraylist.add("agencyPhoto2");
            arraylist.add("agencyPhoto3");
            arraylist.add("email");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String user = paramMap.get("user").toString();
            String password = paramMap.get("password").toString();
            String tel = paramMap.get("tel").toString();
            String enterpriseName = paramMap.get("enterpriseName").toString();
            String enterpriseID = paramMap.get("enterpriseID").toString();
            String licenseID = paramMap.get("licenseID").toString();
            String licenseAddress = paramMap.get("licenseAddress").toString();
            String enterpriseAddress = paramMap.get("enterpriseAddress").toString();
            String licensePhoto = paramMap.get("licensePhoto").toString();
            String liableName = paramMap.get("liableName").toString();
            String liableID = paramMap.get("liableID").toString();
            String liableIDAddress = paramMap.get("liableIDAddress").toString();
            String liableAddress = paramMap.get("liableAddress").toString();
            String liablePhoto1 = paramMap.get("liablePhoto1").toString();
            String liablePhoto2 = paramMap.get("liablePhoto2").toString();
            String agencyName = paramMap.get("agencyName").toString();
            String agencyID = paramMap.get("agencyID").toString();
            String agencyIDAddress = paramMap.get("agencyIDAddress").toString();
            String agencyAddress = paramMap.get("agencyAddress").toString();
            String agencyTel = paramMap.get("agencyTel").toString();
            String agencyPhoto1 = paramMap.get("agencyPhoto1").toString();
            String agencyPhoto2 = paramMap.get("agencyPhoto2").toString();
            String agencyPhoto3 = paramMap.get("agencyPhoto3").toString();
            String email = paramMap.get("email").toString();
            //业务逻辑
            //先根据输入账号是否存在于user表中
            User userInfo = new User();
            userInfo.setUser(user);
            List<User> listUser = userService.getList(userInfo);
            if (listUser.size() == 0 || (listUser.size() != 0 && listUser.get(0).getState().equals("N"))){
                //不存在user表里时再判断账号是否存在于user_state表中
                UserState userState = new UserState();
                userState.setUser(user);
                List<UserState> list = userStateService.getList(userState);
                if ((list.size() == 0) || (list.size() != 0 && list.get(0).getExamineState() == 2)){
                    //1.当账号不存在user_state表中时 直接提交该账号
                    //2.当账号存在user_state表中并且审核状态为 审核未通过时 也一样提交该账号信息
                    userState.setPassword(password);
                    userState.setTel(tel);
                    userState.setEnterpriseName(enterpriseName);
                    userState.setEnterpriseID(enterpriseID);
                    userState.setLicenseID(licenseID);
                    userState.setLicenseAddress(licenseAddress);
                    userState.setEnterpriseAddress(enterpriseAddress);
                    userState.setLicensePhoto(licensePhoto);
                    userState.setLiableName(liableName);
                    userState.setLiableID(liableID);
                    userState.setLiableIDAddress(liableIDAddress);
                    userState.setLiableAddress(liableAddress);
                    userState.setLiablePhoto1(liablePhoto1);
                    userState.setLiablePhoto2(liablePhoto2);
                    userState.setAgencyName(agencyName);
                    userState.setAgencyID(agencyID);
                    userState.setAgencyIDAddress(agencyIDAddress);
                    userState.setAgencyAddress(agencyAddress);
                    userState.setAgencyTel(agencyTel);
                    userState.setAgencyPhoto1(agencyPhoto1);
                    userState.setAgencyPhoto2(agencyPhoto2);
                    userState.setAgencyPhoto3(agencyPhoto3);
                    userState.setEmail(email);
                    userState.setExamineState(0);//新提交的账号审核状态：0 待审核
                    userState.setExamineStateName("待审核");
                    userState.setCreateDate(TimeUtil.getNowStr());
                    userState.setUpdateDate(TimeUtil.getNowStr());
                    int addCount = userStateService.insert(userState);
                    if (addCount == 1){//添加成功
                        map.put("code",10000);
                        map.put("msg","提交资料成功，请耐心等待审核结果");
                    }else {//添加失败
                        map.put("code", 10003);
                        map.put("msg", "提交资料失败");
                    }
                }else if ((list.size() != 0 && list.get(0).getExamineState() == 0) || (list.size() != 0 && list.get(0).getExamineState() == 1)){
                    //当该账号存在于user_state表中并且审核状态为 待审核 或 审核通过 则不允许提交该账号
                    map.put("code", 10003);
                    map.put("msg", "该账号已存在，不可重复提交！");
                    return map;
                }
            }else{
                map.put("code", 10003);
                map.put("msg", "该账号已存在，不可重复提交！");
                return map;
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }


}