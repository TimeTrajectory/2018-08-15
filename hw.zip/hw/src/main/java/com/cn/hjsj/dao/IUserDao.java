package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IUserDao")
public interface IUserDao {

	public List<User> getUserCacheList(User user);
	public List<User> getList(User user);
	public Integer insert(User user);
	public Integer update(@Param("user")User user, @Param("userParmeter")User userParmeter);
	public Integer getListCount(User user);

}
