/**
 * FileName: I_VoiceController
 * Author:   duzenjie
 * Date:     2018/7/22 10:45
 */
package com.cn.hjsj.controller.interfaceController;

import com.cn.hjsj.interfaces.AppImpl.AbilityVoiceImpl;
import com.cn.hjsj.pojo.SoundRecording;
import com.cn.hjsj.service.ISoundRecordingService;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("abilityVoiceImpl")
public class I_VoiceController implements AbilityVoiceImpl {
    @Resource(name = "soundRecordingService")
    private ISoundRecordingService soundRecordingService;

    @Override
    public Map getList(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            SoundRecording soundRecording = new SoundRecording();
            if (maps.get("subscriptionId") != null) {
                soundRecording.setBindID(maps.get("subscriptionId").toString());
            }
            if (maps.get("called") != null) {
                soundRecording.setCalled(maps.get("called").toString());
            }
            if (maps.get("calling") != null) {
                soundRecording.setCalling(maps.get("calling").toString());
            }
            if (maps.get("duration") != null) {
                soundRecording.setDuration(maps.get("duration").toString());
            }
            String startTime = maps.get("startTime").toString();
            String endTime = maps.get("endTime").toString();
            soundRecording.setStartDate(startTime);
            soundRecording.setEndDate(endTime);
            Integer listCount = soundRecordingService.getListCount(soundRecording);

            Integer page = 1;
            Integer pageSize = 10;

            // 每页显示
            if (maps.get("pageSize") != null && Integer.parseInt(maps.get("pageSize").toString())>0) {
                pageSize = Integer.parseInt(maps.get("pageSize").toString());
                if (pageSize > 100) {
                    pageSize = 100;
                }
                soundRecording.setPageSize(pageSize);
            } else {
                soundRecording.setPageSize(pageSize);
            }

            // 第几页
            if (maps.get("page") != null && (Integer.parseInt(maps.get("page").toString()) - 1) > 0) {
                page = (Integer.parseInt(maps.get("page").toString()) - 1) * (soundRecording.getPageSize());
                soundRecording.setStartRow(page);
            } else {
                soundRecording.setStartRow((page - 1) * pageSize);
            }

            //System.out.println("测试"+soundRecording.getStartRow()+":"+soundRecording.getPageSize());
            soundRecording.setOrderColName("createTime");
            soundRecording.setOrderType("desc");
            List<SoundRecording> soundRecordings = soundRecordingService.getList(soundRecording);

            List<Map<String, Object>> soundRecordingDates = new ArrayList<Map<String, Object>>();
            if (soundRecordings != null && soundRecordings.size() > 0) {
                for (int i = 0; i < soundRecordings.size(); i++) {
                    Map temp = new HashMap();
                    SoundRecording tempListOne = soundRecordings.get(i);
                    temp.put("recordId", tempListOne.getRecordId());
                    temp.put("duration", tempListOne.getDuration());
                    temp.put("createTime", tempListOne.getCreateTime().replace(".0", ""));
                    temp.put("url", tempListOne.getRecordId());
                    soundRecordingDates.add(temp);
                }
            }

            Map data = new HashMap();
            data.put("result", soundRecordingDates);
            data.put("count", listCount);
            data.put("pageNo", page);

            map.put("code", 10000);
            map.put("data", data);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_TestController/test--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }
}
