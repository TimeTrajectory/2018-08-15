package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IRoleDao")
public interface IRoleDao {

    public Integer insert(Role role);
    public Integer update(@Param("role") Role role, @Param("roleParmeter") Role roleParmeter);
    public List<Role> getList(Role role);
    public Integer getListCount(Role role);
}
