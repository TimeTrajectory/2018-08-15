package com.cn.hjsj.controller.interfaceController;

import com.cn.hjsj.interfaces.AppImpl.*;
import com.cn.hjsj.pojo.Test;
import com.cn.hjsj.service.ITestService;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("abilityTestImpl")
public class I_TestController implements AbilityTestImpl {

    @Resource(name = "testService")
    private ITestService testService;

    @Override
    public Map test(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            Test test = new Test();
            List<Test> t = testService.getList(test);

            map.put("code", 10000);
            map.put("list",t);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_TestController/test--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }


}
