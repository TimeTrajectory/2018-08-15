package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class UserState extends BaseBean {

    private String user;
    private String password;
    private String tel;
    private String enterpriseName;
    private String enterpriseID;
    private String licenseID;
    private String licenseAddress;
    private String enterpriseAddress;
    private String licensePhoto;
    private String liableName;
    private String liableID;
    private String liableIDAddress;
    private String liableAddress;
    private String liablePhoto1;
    private String liablePhoto2;
    private String agencyName;
    private String agencyID;;
    private String agencyIDAddress;
    private String agencyAddress;
    private String agencyTel;
    private String agencyPhoto1;
    private String agencyPhoto2;
    private String agencyPhoto3;
    private String email;
    private String reason;
    private Integer examineState;
    private String examineStateName;
    private String examineName;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getLicenseID() {
        return licenseID;
    }

    public void setLicenseID(String licenseID) {
        this.licenseID = licenseID;
    }

    public String getEnterpriseID() {
        return enterpriseID;
    }

    public void setEnterpriseID(String enterpriseID) {
        this.enterpriseID = enterpriseID;
    }

    public String getLicenseAddress() {
        return licenseAddress;
    }

    public void setLicenseAddress(String licenseAddress) {
        this.licenseAddress = licenseAddress;
    }

    public String getLicensePhoto() {
        return licensePhoto;
    }

    public void setLicensePhoto(String licensePhoto) {
        this.licensePhoto = licensePhoto;
    }

    public String getEnterpriseAddress() {
        return enterpriseAddress;
    }

    public void setEnterpriseAddress(String enterpriseAddress) {
        this.enterpriseAddress = enterpriseAddress;
    }

    public String getLiableName() {
        return liableName;
    }

    public void setLiableName(String liableName) {
        this.liableName = liableName;
    }

    public String getLiableID() {
        return liableID;
    }

    public void setLiableID(String liableID) {
        this.liableID = liableID;
    }

    public String getLiableIDAddress() {
        return liableIDAddress;
    }

    public void setLiableIDAddress(String liableIDAddress) {
        this.liableIDAddress = liableIDAddress;
    }

    public String getLiableAddress() {
        return liableAddress;
    }

    public void setLiableAddress(String liableAddress) {
        this.liableAddress = liableAddress;
    }

    public String getLiablePhoto1() {
        return liablePhoto1;
    }

    public void setLiablePhoto1(String liablePhoto1) {
        this.liablePhoto1 = liablePhoto1;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getAgencyID() {
        return agencyID;
    }

    public void setAgencyID(String agencyID) {
        this.agencyID = agencyID;
    }

    public String getLiablePhoto2() {
        return liablePhoto2;
    }

    public void setLiablePhoto2(String liablePhoto2) {
        this.liablePhoto2 = liablePhoto2;
    }

    public String getAgencyAddress() {
        return agencyAddress;
    }

    public void setAgencyAddress(String agencyAddress) {
        this.agencyAddress = agencyAddress;
    }

    public String getAgencyIDAddress() {
        return agencyIDAddress;
    }

    public void setAgencyIDAddress(String agencyIDAddress) {
        this.agencyIDAddress = agencyIDAddress;
    }

    public String getAgencyTel() {
        return agencyTel;
    }

    public void setAgencyTel(String agencyTel) {
        this.agencyTel = agencyTel;
    }

    public String getAgencyPhoto1() {
        return agencyPhoto1;
    }

    public void setAgencyPhoto1(String agencyPhoto1) {
        this.agencyPhoto1 = agencyPhoto1;
    }

    public String getAgencyPhoto2() {
        return agencyPhoto2;
    }

    public void setAgencyPhoto2(String agencyPhoto2) {
        this.agencyPhoto2 = agencyPhoto2;
    }

    public String getAgencyPhoto3() {
        return agencyPhoto3;
    }

    public void setAgencyPhoto3(String agencyPhoto3) {
        this.agencyPhoto3 = agencyPhoto3;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getExamineStateName() {
        return examineStateName;
    }

    public void setExamineStateName(String examineStateName) {
        this.examineStateName = examineStateName;
    }

    public Integer getExamineState() {
        return examineState;
    }

    public void setExamineState(Integer examineState) {
        this.examineState = examineState;
    }

    public String getExamineName() {
        return examineName;
    }

    public void setExamineName(String examineName) {
        this.examineName = examineName;
    }
}
