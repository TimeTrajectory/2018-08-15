package com.cn.hjsj.verify;

import com.cn.hjsj.util.Md5Util;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class h5Check {
    //判断jsonstring
    public static Map checkJson(String jsonstring, ArrayList<String> arraylist) {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> paramMap = null;

        map = NonEmpty_jsonstring(jsonstring);

        if(Integer.parseInt(map.get("code").toString()) != 10000){
            return map;
        }

        JSONObject object = JSONObject.fromObject(jsonstring);
        paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
        map = checkParameter(paramMap,arraylist);

        return map;
    }


    public static Map NonEmpty_jsonstring(String jsonstring) {
        Map<String, Object> map = new HashMap<String, Object>();
        JSONObject object;

        if ("".equals(jsonstring) || jsonstring == null) {
            map.put("code", 30000);
            map.put("msg", "无请求数据");
            return map;
        }

        try {
            object = JSONObject.fromObject(jsonstring);
        } catch (Exception ex) {
            map.put("code", 20001);
            map.put("msg", "json格式错误");
            return map;
        }

        if (!object.containsKey("timeStamp")) {
            map.put("code", 20003);
            map.put("msg", "缺少timeStamp参数");
            return map;
        }
        if (!object.containsKey("parameter")) {
            map.put("code", 20004);
            map.put("msg", "缺少parameter参数");
            return map;
        }
        if (!object.containsKey("sign")) {
            map.put("code", 20005);
            map.put("msg", "缺少sign参数");
            return map;
        }

        String identifier = "HjsjAbility@2018#V1.0";
        String timeStamp = object.get("timeStamp").toString();
        String parameter = object.get("parameter").toString();
        String sign = object.get("sign").toString();

        String md5Sign = Md5Util.GetMD5Code(identifier + Md5Util.GetMD5Code(timeStamp + parameter));
        System.out.println("正确签名：" + md5Sign);
        System.out.println("传入签名：" + sign);
        if (!sign.equals(md5Sign)) {
            map.put("code", 20000);
            map.put("msg", "签名错误");
        }else{
            map.put("code", 10000);
            map.put("msg", "json初步校验通过");
        }

        return map;
    }

    public static Map checkParameter(Map maps, ArrayList<String> arrayList) {
        boolean flag = false;
        Map<String, Object> map = new HashMap<String, Object>();
        for (String s : arrayList) {
            if (maps.containsKey(s) && (maps.get(s) != null && !"".equals(maps.get(s)))) {
                flag = true;
            } else {
                flag = false;
                break;
            }
        }

        if(flag){
            map.put("code", 10000);
            map.put("msg", "json校验通过");
        }else{
            map.put("code", 20006);
            map.put("msg", "缺少参数");
        }

        return map;
    }
}
