package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.IUserInfoService;
import com.cn.hjsj.service.IUserService;
import com.cn.hjsj.service.IUserStateService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/webPersonal")
public class webPersonal {

    @Resource(name = "userInfoService")
    private IUserInfoService userInfoService;
    @Resource(name = "userService")
    private IUserService userService;
    @Resource(name = "userStateService")
    private IUserStateService userStateService;

//根据登入账号查询个人信息--Created by WangFeng on 2018-07-28
    @ResponseBody
    @RequestMapping("/getAccount")
    @Permission("login")
    public Map getAccount(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            String loginUser = ((SessionToken)mapToken.get("data")).getUser();//获取登入账号
            //根据登入账号在user表中获取userCode
            User user = new User();
            user.setUser(loginUser);
            User tempUser = userService.getList(user).get(0);
            String userCode = tempUser.getUserCode();
            //根据user在user_state表中获取email
            UserState userState = new UserState();
            userState.setUser(loginUser);
            String email = userStateService.getList(userState).get(0).getEmail();
            //根据上面获取的userCode在user_info表中获取用户个人信息
            UserInfo userInfo = new UserInfo();
            userInfo.setUserCode(userCode);
            List<UserInfo> list = userInfoService.getList(userInfo);
            Map userInfoMap = new HashMap();
            UserInfo tempUserInfo = list.get(0);
            userInfoMap.put("userCode", tempUserInfo.getUserCode());//帐号编号
            userInfoMap.put("userKey", tempUser.getUserKey());//key
            userInfoMap.put("user", tempUser.getUser());//帐号
            userInfoMap.put("tel", tempUser.getTel());//绑定手机号
            userInfoMap.put("enterpriseName", tempUserInfo.getEnterpriseName());//企业名称
            userInfoMap.put("enterpriseID", tempUserInfo.getEnterpriseID());//单位证件类型
            userInfoMap.put("licenseID", tempUserInfo.getLiableID());//营业执照证件号码
            userInfoMap.put("licenseAddress", tempUserInfo.getLiableAddress());//营业执照地址
            userInfoMap.put("enterpriseAddress", tempUserInfo.getEnterpriseAddress());//单位通讯地址
            userInfoMap.put("licensePhoto", tempUserInfo.getLicensePhoto());//营业执照
            userInfoMap.put("liableName", tempUserInfo.getLiableName());//责任人姓名
            userInfoMap.put("liableID", tempUserInfo.getLiableID());//责任人身份证号
            userInfoMap.put("liableIDAddress", tempUserInfo.getLiableIDAddress());//责任人身份证地址
            userInfoMap.put("liableAddress", tempUserInfo.getLiableAddress());//责任人通讯地址
            userInfoMap.put("liablePhoto1", tempUserInfo.getLiablePhoto1());//责任人身份证正面
            userInfoMap.put("liablePhoto2", tempUserInfo.getLiablePhoto2());//责任人身份证背面
            userInfoMap.put("agencyName", tempUserInfo.getAgencyName());//代办人姓名
            userInfoMap.put("agencyID", tempUserInfo.getAgencyID());//代办人身份证号
            userInfoMap.put("agencyIDAddress", tempUserInfo.getAgencyIDAddress());//代办人身份证地址
            userInfoMap.put("agencyAddress", tempUserInfo.getAgencyAddress());//代办人通讯地址
            userInfoMap.put("agencyTel", tempUserInfo.getAgencyTel());//代办人手机号
            userInfoMap.put("agencyPhoto1", tempUserInfo.getAgencyPhoto1());//代办人身份证正面
            userInfoMap.put("agencyPhoto2", tempUserInfo.getAgencyPhoto2());//代办人身份证背面
            userInfoMap.put("agencyPhoto3", tempUserInfo.getAgencyPhoto3());//代办人手持身份证
            userInfoMap.put("email", email);//邮箱地址

            map.put("data", userInfoMap);
            map.put("code", 10000);
            map.put("msg", "查询成功");

        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }
}