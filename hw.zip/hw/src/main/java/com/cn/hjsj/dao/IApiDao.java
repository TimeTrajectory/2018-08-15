package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.Api;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IApiDao")
public interface IApiDao {

    public Integer insert(Api api);
    public Integer update(@Param("api")Api api, @Param("apiParmeter")Api apiParmeter);
    public List<Api> getList(Api api);
    public Integer getListCount(Api api);

}
