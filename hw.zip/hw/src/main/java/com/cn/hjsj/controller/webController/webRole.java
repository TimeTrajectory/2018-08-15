package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.IRoleService;
import com.cn.hjsj.service.*;
import com.cn.hjsj.util.*;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.cglib.transform.impl.AddDelegateTransformer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhyuj on 2018/7/24.
 * 角色功能
 */
@Controller
@RequestMapping("/webRole")
public class webRole {
    @Resource(name="roleService")
    private IRoleService roleService;
    @Resource(name="sysMenu1Service")
    private ISysMenu1Service sysMenu1Service;
    @Resource(name="sysMenu2Service")
    private ISysMenu2Service sysMenu2Service;
    @Resource(name="sysMenu1Menu2Service")
    private ISysMenu1Menu2Service sysMenu1Menu2Service;
    @Resource(name="sysRolesMenu2Service")
    private ISysRolesMenu2Service sysRolesMenu2Service;

    //获取角色列表
    @ResponseBody
    @RequestMapping("/roleList")
    @Permission("login")
    public Object roleList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist，

            arraylist.add("pagesize");
            arraylist.add("pageNo");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
           if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            //获取角色名称
            String con_roleName =null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_roleName").toString())){
                con_roleName =  objectParameter.get("con_roleName").toString();
            }

            Integer pagesize = Integer.parseInt(objectParameter.get("pagesize").toString());//每页显示条数
            Integer pageNo = Integer.parseInt(objectParameter.get("pageNo").toString());//当前页数

            int startRow = (pageNo - 1) * pagesize;

            Role role = new Role();
            role.setRoleName(con_roleName);
            role.setPageSize(pagesize);
            role.setStartRow(startRow);

            // 按条件查询的总数
            Integer count =  roleService.getListCount(role);

            // 寻找符合条件的集合
            List<Role> roleList =  roleService.getList(role);

            List roleList1 = new ArrayList();
            for (int i=0;i<roleList.size();i++){
                Map mapTemp = new HashMap();
                Role roleBean = roleList.get(i);
                mapTemp.put("id",roleBean.getId());//角色主键id
                mapTemp.put("roleName",roleBean.getRoleName());//角色名称
                roleList1.add(mapTemp);
            }
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("roleLIst",roleList1);
            map1.put("count",count);
            map1.put("pageNo",pageNo);
            map.put("data",map1);

            map.put("code",10000);
            map.put("msg", "查询成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }




    //添加角色
    @ResponseBody
    @RequestMapping("/roleAdd")
    @Permission("login")
    public Object roleAdd(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist，

            arraylist.add("roleName");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            //获取登陆账户
            String user = ((SessionToken)mapToken.get("data")).getUser();

            JSONObject objectParameter = parseParameter(jsonstring);

            //角色名称
            String roleName = objectParameter.get("roleName").toString();
            Role role = new Role();
            role.setRoleName(roleName);
            role.setCreateDate(TimeUtil.getNowStr());
            role.setCreateBy(user);
            role.setUpdateBy(user);

            Integer add = roleService.insert(role);
            if (add==1){
                map.put("code",10000);
                map.put("msg", "添加成功");
            }
            LogUtil.error("添加角色:"+add);


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

    //获取一级菜单列表
    @ResponseBody
    @RequestMapping("/role_menuLevel1")
    @Permission("login")
    public Object role_menuLevel1(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist，


            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            SysMenu1 sysMenu1 = new SysMenu1();
            List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);

            List sysMenu1List1 = new ArrayList();
            for (int i = 0;i<sysMenu1List.size();i++){
                Map newMap = new HashMap();
                SysMenu1 sysMenu1Bean = sysMenu1List.get(i);
                newMap.put("menuLevel1Code",sysMenu1Bean.getMenu1Code());//一级菜单编码
                newMap.put("name",sysMenu1Bean.getMenu1Name());//一级菜单名称

                sysMenu1List1.add(newMap);

            }
            Map<String,Object> map1 = new HashMap<String, Object>();
            map1.put("menuLevel1",sysMenu1List1);
            map.put("data",map1);

            map.put("code",10000);
            map.put("msg", "获取成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }
    //获取指定二级菜单列表
    @ResponseBody
    @RequestMapping("/role_menuLevel2")
    @Permission("login")
    public Object role_menuLevel2(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("menuLevel1Code");
            arraylist.add("roleId");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            Integer menuLevel1Code = Integer.parseInt(objectParameter.get("menuLevel1Code").toString());//一级菜单编码
            Integer roleId = Integer.parseInt(objectParameter.get("roleId").toString());//角色id

            //指定二级菜单列表
            SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
            sysMenu1Menu2.setMenu1Code(menuLevel1Code);

            List<SysMenu1Menu2> sysMenu1Menu2List = sysMenu1Menu2Service.getList(sysMenu1Menu2);

            List sysMenu1Menu2List1 = new ArrayList();
            for (int i = 0;i<sysMenu1Menu2List.size();i++){
                Map newMap = new HashMap();
                SysMenu1Menu2 sysMenu1Menu2Bean = sysMenu1Menu2List.get(i);
                newMap.put("menuLevel2Code",sysMenu1Menu2Bean.getMenu2Code());//二级菜单编码
                newMap.put("name",sysMenu1Menu2Bean.getMenu2Name());//二级菜单名称
                newMap.put("menuUrl",sysMenu1Menu2Bean.getMenuUrl());//菜单url

                sysMenu1Menu2List1.add(newMap);

            }
            //指定二级菜单编码
            SysRolesMenu2 sysRolesMenu2 = new SysRolesMenu2();
            sysRolesMenu2.setRoleId(roleId);
            sysRolesMenu2.setMenu1Code(menuLevel1Code);
            List<SysRolesMenu2> sysRolesMenu2List = sysRolesMenu2Service.getList(sysRolesMenu2);

            List rolesMenu2List = new ArrayList();
            for (SysRolesMenu2 sysRolesMenu2Bean : sysRolesMenu2List){
                Map rolesMenu2Map = new HashMap();
                rolesMenu2Map.put("menuLevel2Code",sysRolesMenu2Bean.getMenu2Code());//二级菜单编号
                rolesMenu2List.add(rolesMenu2Map);
            }

            Map<String,Object> map1 = new HashMap<String, Object>();
            map1.put("menuLevel2",sysMenu1Menu2List1);
            map1.put("roles_menus2",rolesMenu2List);

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg", "获取成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }


    //保存按钮（与二级菜单关联）
    @ResponseBody
    @RequestMapping("/role_addMenuLevel2")
    @Permission("login")
    public Object role_addMenuLevel2(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("menuLevel1Code");
            arraylist.add("roleId");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            JSONObject objectParameter = parseParameter(jsonstring);
            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            JSONObject parameter =JSONObject.fromObject(object.get("parameter").toString());

            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            //获取登陆账户
            String user = ((SessionToken)mapToken.get("data")).getUser();

            Integer menuLevel1Code = Integer.parseInt(objectParameter.get("menuLevel1Code").toString());//一级菜单编码
            Integer roleId = Integer.parseInt(objectParameter.get("roleId").toString());//角色id
            //先删除原有的关联
            SysRolesMenu2 sysRolesMenu2 = new SysRolesMenu2();
            sysRolesMenu2.setMenu1Code(menuLevel1Code);
            sysRolesMenu2.setRoleId(roleId);
            Integer del =  sysRolesMenu2Service.delete(sysRolesMenu2);
            JSONArray jsonarray = parameter.getJSONArray("menuLevel2");
            List<SysRolesMenu2> lists = (List)JSONArray.toCollection(jsonarray, SysRolesMenu2.class);
            Integer add=0;
            for(SysRolesMenu2 x : lists){
                SysRolesMenu2 sysRolesMenu2Bean = new SysRolesMenu2();
                sysRolesMenu2Bean.setRoleId(roleId);
                sysRolesMenu2Bean.setMenu2Code(x.getMenuLevel2Code());
                sysRolesMenu2Bean.setMenu1Code(menuLevel1Code);
                sysRolesMenu2Bean.setCreateBy(user);
                sysRolesMenu2Bean.setUpdateBy(user);
                add =add+ sysRolesMenu2Service.insert(sysRolesMenu2Bean);
            }
            if (add == lists.size()){
                map.put("code",10000);
                map.put("msg", "保存成功");
            }else {
                map.put("code",10003);
                map.put("msg", "保存数据不正确");
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

    //获取角色详情
    @ResponseBody
    @RequestMapping("/getRole")
    @Permission("login")
    public Object getRole(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist，

            arraylist.add("id");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);


            //获取角色id
            Integer id = Integer.parseInt(objectParameter.get("id").toString());
            Role role = new Role();
            role.setId(id);

            List<Role> roleList = roleService.getList(role);
            Map newMap = new HashMap();
            newMap.put("roleName",roleList.get(0).getRoleName());//角色名称


            map.put("data",newMap);
            map.put("code",10000);
            map.put("msg", "获取成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }


    //解析parameter中数据
    public static JSONObject parseParameter(String json) {
        JSONObject fromObject = JSONObject.fromObject(json);
        Object object = fromObject.get("parameter");
        JSONObject object1 = JSONObject.fromObject(object);
        return object1;
    }

}