package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.SessionToken;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISessionTokenDao")
public interface ISessionTokenDao {

    public List<SessionToken> getList(SessionToken sessionToken);
    public Integer insert(SessionToken sessionToken);
    public Integer update(@Param("sessionToken")SessionToken sessionToken, @Param("sessionTokenParmeter")SessionToken sessionTokenParmeter);
    public Integer getListCount(SessionToken sessionToken);

    //zhyuj
    public Integer delete(SessionToken sessionToken);//用于注销
}
