package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISysRolesMenu2Dao")
public interface ISysRolesMenu2Dao {

    public Integer insert(SysRolesMenu2 sysRolesMenu2);
    public Integer update(@Param("sysRolesMenu2") SysRolesMenu2 sysRolesMenu2, @Param("sysRolesMenu2Parmeter") SysRolesMenu2 sysRolesMenu2Parmeter);
    public List<SysRolesMenu2> getList(SysRolesMenu2 sysRolesMenu2);
    public Integer delete(SysRolesMenu2 sysRolesMenu2);


}
