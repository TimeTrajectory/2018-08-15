package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.UserApiState;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IUserApiStateDao")
public interface IUserApiStateDao {

    public Integer insert(UserApiState userApiState);
    public Integer update(@Param("userApiState")UserApiState userApiState, @Param("userApiStateParmeter")UserApiState userApiStateParmeter);
    public List<UserApiState> getList(UserApiState userApiState);
    public Integer getListCount(UserApiState userApiState);

}
