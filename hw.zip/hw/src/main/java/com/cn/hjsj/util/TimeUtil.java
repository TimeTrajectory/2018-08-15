package com.cn.hjsj.util;

import java.text.SimpleDateFormat;
import java.util.Date;


public class TimeUtil {
    public static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static SimpleDateFormat df1 = new SimpleDateFormat("yyyyMMddHHmmss");
    public static SimpleDateFormat df2 = new SimpleDateFormat("yyyyMMdd");


    public static String getNowStr() {
        try {
            return df.format(new Date());
        } catch (Exception e) {
            return "1900-01-01 00:00:00";
        }
    }

}
