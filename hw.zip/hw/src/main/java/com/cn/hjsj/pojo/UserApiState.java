package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class UserApiState extends BaseBean {

    private String userCode;
    private String enterpriseName;
    private Integer apiCode;
    private String apiName;
    private Integer apiState;
    private String apiStateName;
    private String reason;
    private String examineName;

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public Integer getApiCode() {
        return apiCode;
    }

    public void setApiCode(Integer apiCode) {
        this.apiCode = apiCode;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public Integer getApiState() {
        return apiState;
    }

    public void setApiState(Integer apiState) {
        this.apiState = apiState;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getApiStateName() {
        return apiStateName;
    }

    public void setApiStateName(String apiStateName) {
        this.apiStateName = apiStateName;
    }

    public String getExamineName() {
        return examineName;
    }

    public void setExamineName(String examineName) {
        this.examineName = examineName;
    }
}
