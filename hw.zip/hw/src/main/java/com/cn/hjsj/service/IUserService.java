package com.cn.hjsj.service;

import com.cn.hjsj.pojo.User;
import java.util.List;


public interface IUserService {

    public List<User> getUserCacheList(User user);
    public List<User> getList(User user);
    public Integer insert(User user);
    public Integer update(User user,User userParmeter);
    public Integer getListCount(User user);

}
