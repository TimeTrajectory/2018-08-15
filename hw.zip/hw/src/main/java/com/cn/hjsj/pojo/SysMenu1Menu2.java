package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SysMenu1Menu2 extends BaseBean {

    private Integer menu1Code;
    private Integer menu2Code;
    private String menu2Name;
    private String menuUrl;

    public Integer getMenu1Code() {
        return menu1Code;
    }

    public void setMenu1Code(Integer menu1Code) {
        this.menu1Code = menu1Code;
    }

    public Integer getMenu2Code() {
        return menu2Code;
    }

    public void setMenu2Code(Integer menu2Code) {
        this.menu2Code = menu2Code;
    }

    public String getMenu2Name() {
        return menu2Name;
    }

    public void setMenu2Name(String menu2Name) {
        this.menu2Name = menu2Name;
    }

    public String getMenuUrl() {
        return menuUrl;
    }

    public void setMenuUrl(String menuUrl) {
        this.menuUrl = menuUrl;
    }
}
