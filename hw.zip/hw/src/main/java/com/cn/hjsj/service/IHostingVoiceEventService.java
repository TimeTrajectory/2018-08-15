package com.cn.hjsj.service;

/**
 * 话单通知
 *
 * @author  jy
 * @version  [版本号, 2018-7-23]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public interface IHostingVoiceEventService {
    /**
     * 短信通知
     * @param jsonBody 小号平台推送到客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    String onSmsEvent(String jsonBody);

    /**
     * 呼叫通知
     * @param jsonBody 小号平台推送客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    String onCallEvent(String jsonBody);

}
