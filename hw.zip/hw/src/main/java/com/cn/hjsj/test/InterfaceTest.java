/*
package com.cn.hjsj.test;

import com.cn.hjsj.interfaceUtil.AXBInterface;
import com.cn.hjsj.interfaceUtil.AXInterface;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/webLogin")
public class InterfaceTest {

    @Resource(name = "aXBInterfaceUtil")
    private AXBInterface axbInterface;

    @Resource(name = "aXInterfaceUtil")
    private AXInterface axInterface;

    //交易小号AXB绑定
    @RequestMapping(value="/test",method=RequestMethod.POST)
    public void test(){
        //这里传入所需要的绑定参数
        Map map = new HashMap();
        //其他参数可选，有则加
        map.put("aParty","8617040000524");//
        map.put("bParty","8617040000514");//
        map.put("isRecord","0");//是否录音
        map.put("bindDirection","0");//呼叫方向
        map.put("cityCode","010");//小号平台自动分配的虚号码所属城市的区号
        map.put("endTime","2018-07-26T23:59:59Z");//该绑定关系结束日期，UTC 时间

        Map<String,Object> resultMap = axbInterface.axbBindNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * @param 返回参数
         * {
         * "code": "000000",
         * "description":"Success",
         * "result": {
         * "subscriptionId":"sub00001"
         *      }
         * }
         *//*

        System.out.println(resultMap.get("code"));
    }
    //AXB解绑
    @RequestMapping(value="/test1",method=RequestMethod.POST)
    public void test1(){
        //根据按虚拟号码解除绑定
        Map map = new HashMap();
        map.put("type","1");//用于指示解绑方式。
        map.put("number","8617040000524");*/
/*1. 解绑对象：虚拟号码当 type取值为 1 时，
        该字段必须携 带并且取值不能为空。2. 当 type 取值为 2 时，该字段 允许不携带*//*


        //按绑定 ID 解除绑定关系
        //map.put("type","2");
        //map.put("subscriptionId","e599f586-431e-428a-abf4-18793f1d9da8");*/
/*
        // 1. 解绑对象：绑定 ID 当 type 取值为 2 时，该字段必须携带并且取值不能为空。
        //2. 当 type 取值为 1 时，该字段允许不携带
        // *//*


        Map<String,Object> resultMap = axbInterface.axbUnbindNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * @param 返回参数
         * {
         * {
         * "code": "000000",
         * "description": "Success"
         * }
         *//*

    }
    //AXB转绑
    @RequestMapping(value="/test2",method=RequestMethod.POST)
    public void test2(){
        Map map = new HashMap();
        map.put("subscriptionId","e599f586-431e-428a-abf4-18793f1d9da8");
        map.put("bPartyNew","8617040000624");

        Map<String,Object> resultMap = axbInterface.axbModifyNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * @param 返回参数
         * {
         * {
         * "code": "000000",
         * "description":"Success"
         * }
         *//*

    }
    //查询虚拟号码
    @RequestMapping(value="/test3",method=RequestMethod.POST)//post请求
    public void test3(){
        Map map = new HashMap();
        map.put("virtualNumber","8617040000524");//这里表示想要查询的虚拟号码，（必填项）
        // 格式：国家码+手机号。示例：8613800000000

        Map<String,Object> resultMap = axbInterface.queryOrderedNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         {
            "code": "000000",
            "description": "Success" //描述
            "result":{              //号码信息，查不到则不返回（可选）
                "virtualNumber": "8613800000000", //   虚拟号码。（必选）
                "numberStatus": "1",    号码状态 --0：空闲，即该号码没有任何绑定关系。1：使用中，即该号码至少有一个绑定关系。（必选）
                "bindInfos":                //号码的绑定信息。只有虚拟号码使用中才有绑定信息（可选）
                [
                    {
                        "subscriptionId": "xxxx-xxxx-xxx-xxxxx",    //绑定关系的绑定 ID。（必选）
                        "aParty": "8613800000001",                  //AXB、AX中的绑定的 A 方真实手机号。（必选）
                        "bParty": "8613800000002",                  //小号业务（AXB）virtualNumber 绑定的B方真实手机号。（必选）
                                                                     个人小号业务（AX）场景，不返回该字段（必选）
                        "bindTime": "2014-10-12T14:30:21Z"          // 该绑定关系的绑定时间（必选）
                    }
                ]
                "operator": "15601",        //所属运营商 ID。（可选）
                "province": "23",           //所属省份 ID。（可选）
                "createTime": "2014-10-12T14:30:21Z",   //商户申请号码时间，UTC 时间。格式：（可选）
                                                            YYYY-MM-DD'T'hh:mm:ss'Z'示例：2014-01-07T07:18:13Z
         }
         *//*

    }
    //个人小号绑定
    @RequestMapping(value="/test4",method=RequestMethod.POST)//post请求
    public void test4(){
        Map map = new HashMap();
        map.put("virtualNumber","8617040000524");//虚拟号码。(必填)
        map.put("aParty","8613065034721");         //个人小号业务（AX）场景，A 方真实手机号。（必填）
        map.put("calledNumDisplay","1");        //AX 模式下呼入场景（B 呼 A）的显示号码。0：显示虚号码 X；1：显示被叫号码 B；（选填）
        map.put("isRecord","0");                //是否录音。0：不录音。1录音（选填）
        //其他可选信息。（可填可不填）
        map.put("cityCode","010");                    //小号平台自动分配的虚号码所属城市的区号,例010 北京区号
        map.put("endTime","2018-07-26T23:59:59Z"); //该绑定关系结束日期，UTC时间。

        Map<String,Object> resultMap = axInterface.axBindNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * {
             "code": "000000",
             "description":"Success",
             "result": {
                 "subscriptionId":"sub00001"
             }
         }
         *//*

    }
    //个人小号 AX 解绑接口
    @RequestMapping(value="/test5",method=RequestMethod.POST)//post请求
    public void test5(){
        Map map = new HashMap();
        //根据type所选类型的不同进行解绑。1，根据虚拟号码进行解绑
        map.put("type","1");                    //类型（必填）
        map.put("number","8617040000524");      //虚拟号码（type选1,必填）

        //2.根据绑定 ID进行解绑
        */
/*map.put("type","2");
        map.put("subscriptionId","a4643bc6-cfa6-4ad5-a62c-203ddc6b4a40");*//*
 //解绑对象：绑定 ID（type选2，必填）
        Map<String,Object> resultMap = axInterface.axUnbindNumber(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * {
             "code": "000000",
             "description": "Success"
         }
         *//*

    }
    //个人小号 AX 逻辑开关机接口
    @RequestMapping(value="/test6",method=RequestMethod.POST)//post请求
    public void test6(){
        Map map = new HashMap();
        map.put("virtualNumber","8617040000524");   //虚拟号码(必填)
        map.put("function","VOICE");                   //功能类型（可选）
        map.put("status","PowerOff");                  //开关机状态，PowerOn：逻辑开机。PowerOff：逻辑关机（必填）

        Map<String,Object> resultMap = axInterface.axSetLogicPowerStatus(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * {
             "code": "000000",
             "description": "Success"
         }
         *//*

    }
    //查询录音列表
    @RequestMapping(value="/test7",method=RequestMethod.POST)
    public void test7(){
        Map map = new HashMap();
        map.put("subscriptionId","a4643bc6-cfa6-4ad5-a62c-203ddc6b4a40");//号码绑定关系的绑定 ID。（可选）
                                                               // 若 callIdentifier 不携带，则绑定 ID 不允许不携带，取值不能为空
        //map.put("callIdentifier",""); //呼叫唯一标识若 subscriptionId 不携带，则呼（可选）
                                        //叫唯一标识不允许不携带，取值不能为空
        map.put("endTime","2018-07-25T15:18:04Z");                 //查询条件的结束时间  YYYY-MM-DD'T'hh:mm:ss'Z'示例：2014-01-08T23:59:59Z(必填)
        map.put("startTime","2018-07-25T12:30:04Z");            //查询条件的起始时间   YYYY-MM-DD'T'hh:mm:ss'Z'示例：2014-01-07T00:00:00Z（必填）

        map.put("pageSize","10");       //每个录音列表页面包含的数量。默认值为 10，最大值为 100。超过 100 时，则按照 100 进行处理。(可选)

        map.put("page","1");        //录音列表当前页数，起始值为 1。默认值为 1（可选）

        Map<String,Object> resultMap = axInterface.queryRecordList(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * {
             "code": "000000",
             "description": "Success"
             "result":{
                "total": 1,
                "record":
                [
                    {
                        "recordId": "xxxxxxxxxxxxxxxx",
                        "duration": "30",
                        "createTime": "2014-10-12T14:30:21Z"
                    }
                ]
                    }
             }
         *//*

    }
    //删除录音接口
    @RequestMapping(value="/test8",method=RequestMethod.POST)
    public void test8(){
        Map map = new HashMap();
        map.put("recordId","123");  //录音资源的唯一标识(必填)

        Map<String,Object> resultMap = axInterface.deleteRecord(map);
        //resultMap的返回的参数形式依照《华为云通信小号接口参考》文档
        */
/**
         * {
             "code": "000000",
             "description": "Success"
         }
         *//*

    }
}
*/
