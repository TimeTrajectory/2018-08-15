package com.cn.hjsj.interfaces.AppImpl;

import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author duzj
 * @create 2018-09-10 16:12
 */
public interface AbilityConversationImpl {
    public Map QueryConversation(Map maps);
}
