/**
 * FileName: AbilityAXImpl
 * Author:   duzenjie
 * Date:     2018/7/22 10:24
 */
package com.cn.hjsj.interfaces.AppImpl;

import java.util.Map;

public interface AbilityAXImpl {
    public Map bindNumber(Map maps);//绑定
    public Map unbindNumber(Map maps);//解绑
    public Map setLogicPowerStatus(Map maps);//个人小号 AX 逻辑开关机接口
}
