package com.cn.hjsj.retime.task;

import com.cn.hjsj.base.cache.UserCache;
import com.cn.hjsj.util.LogUtil;

import java.util.TimerTask;

public class reloadUser extends TimerTask {
    @Override
    public void run() {

        LogUtil.error("重新加载用户表开始...");
        UserCache.reload();
        LogUtil.error("重新加载用户表结束");

    }
}
