package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ISysMenu1Dao;
import com.cn.hjsj.pojo.SysMenu1;
import com.cn.hjsj.pojo.SysRolesMenu2;
import com.cn.hjsj.pojo.SysRolesMenu2;
import com.cn.hjsj.service.ISysMenu1Service;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sysMenu1Service")
public class ISysMenu1ServiceImpl implements ISysMenu1Service {

    @Resource(name="ISysMenu1Dao")
    private ISysMenu1Dao iSysMenu1Dao;

    public List<SysMenu1> getList(SysMenu1 sysMenu1){
        return iSysMenu1Dao.getList(sysMenu1);
    }
    public Integer update(SysMenu1 sysMenu1,SysMenu1 sysMenu1Parmeter){
        return iSysMenu1Dao.update(sysMenu1,sysMenu1Parmeter);
    }
    public Integer insert(SysMenu1 sysMenu1){
        return  iSysMenu1Dao.insert(sysMenu1);
    }
    public Integer delete(SysMenu1 sysMenu1){
        return iSysMenu1Dao.delete(sysMenu1);
    }

}
