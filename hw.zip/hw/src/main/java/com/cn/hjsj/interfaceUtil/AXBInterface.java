package com.cn.hjsj.interfaceUtil;

import java.util.Map;

/**
 * Created by jiazh on 2018/8/7.
 */
public interface AXBInterface {
    /**
     * 交易小号AXB绑定
     */
     Map<String,Object> axbBindNumber(Map<String,String> map);
    /**
     * 交易小号AXB转绑
     */
     Map<String,Object> axbModifyNumber(Map<String,String> map);
    /**
     *  交易小号AXB解绑
     */
     Map<String,Object> axbUnbindNumber(Map<String,String> map);
    /**
     * 查询虚号码详情
     */
     Map<String,Object> queryOrderedNumber(Map<String,String> map);
    /**
     * 查询录音列表
     */
     Map<String,Object> queryRecordList(Map<String,String> map);
    /**
     * 下载录音
     */
     boolean downloadRecord(Map<String,String> map);
    /**
     * 删除小号平台上的录音
     */
     Map<String,Object> deleteRecord(Map<String,String> map);
}
