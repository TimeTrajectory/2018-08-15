package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class Test extends BaseBean {

    private String t1;
    private Integer t2;
    private Double t3;

    public String getT1() {
        return t1;
    }

    public void setT1(String t1) {
        this.t1 = t1;
    }

    public Integer getT2() {
        return t2;
    }

    public void setT2(Integer t2) {
        this.t2 = t2;
    }

    public Double getT3() {
        return t3;
    }

    public void setT3(Double t3) {
        this.t3 = t3;
    }
}
