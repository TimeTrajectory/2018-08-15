package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IReceiveMessageDao;
import com.cn.hjsj.pojo.ReceiveMessage;
import com.cn.hjsj.service.IReceiveMessageService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("receiveMessageService")
public class IReceiveMessageServiceImpl implements IReceiveMessageService {

    @Resource(name="IReceiveMessageDao")
    private IReceiveMessageDao iReceiveMessageDao;

    @Override
    public Integer insert(ReceiveMessage receiveMessage) {
        return iReceiveMessageDao.insert(receiveMessage);
    }

    @Override
    public List<ReceiveMessage> getList(ReceiveMessage receiveMessage) {
        return iReceiveMessageDao.getList(receiveMessage);
    }

    @Override
    public Integer update(ReceiveMessage receiveMessage, ReceiveMessage receiveMessageParmeter) {
        return iReceiveMessageDao.update(receiveMessage,receiveMessageParmeter);
    }

    @Override
    public Integer getListCount(ReceiveMessage receiveMessage){
        return iReceiveMessageDao.getListCount(receiveMessage);
    }
}
