package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.*;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.StringUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhyuj on 2018/7/23.
 * 菜单功能
 */

@Controller
@RequestMapping("/webMenu")
public class webMenu {
    @Resource(name = "userService")
    private IUserService userService;

    @Resource(name = "sysMenu1Service")
    private ISysMenu1Service sysMenu1Service;
    @Resource(name = "sysMenu2Service")
    private ISysMenu2Service sysMenu2Service;
    @Resource(name = "sysMenu1Menu2Service")
    private ISysMenu1Menu2Service sysMenu1Menu2Service;

    @Resource(name = "sysRolesMenu2Service")
    private ISysRolesMenu2Service sysRolesMenu2Service;

    //获取菜单
    @ResponseBody
    @RequestMapping("/menu")
    @Permission("login")
    public Object menu(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();

            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            //获取登陆账户
            String user = ((SessionToken) mapToken.get("data")).getUser();

            User user1 = new User();
            user1.setUser(user);
            List<User> userList = userService.getList(user1);
            SysRolesMenu2 sysRolesMenu2 = new SysRolesMenu2();
            sysRolesMenu2.setRoleId(userList.get(0).getRoleId());
            Map<String, Object> map1 = new HashMap<String, Object>();
            if (userList.get(0).getRoleId() != null) {
                List<SysRolesMenu2> sysRolesMenu2List = sysRolesMenu2Service.getList(sysRolesMenu2);
                System.out.println(sysRolesMenu2List.size());
                List<Integer> Menu1CodeList = new ArrayList<Integer>();
                List<Integer> Menu2CodeList = new ArrayList<Integer>();
                for (SysRolesMenu2 sysRolesMenu2Bean : sysRolesMenu2List) {
                    if (!Menu1CodeList.contains(sysRolesMenu2Bean.getMenu1Code())) {
                        Menu1CodeList.add(sysRolesMenu2Bean.getMenu1Code());
                    }
                    Menu2CodeList.add(sysRolesMenu2Bean.getMenu2Code());
                }
                List sysMenu1List1 = new ArrayList();
                for (int i = 0; i < Menu1CodeList.size(); i++) {
                    SysMenu1 sysMenu1 = new SysMenu1();
                    sysMenu1.setMenu1Code(Menu1CodeList.get(i));
                    List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);
                    System.out.println(sysMenu1List.get(0).getMenu1Code());
                    for (SysMenu1 sysMenu1Bean : sysMenu1List) {
                        Map mapTemp = new HashMap();
                        mapTemp.put("menuLevel1Code", sysMenu1Bean.getMenu1Code());//一级菜单编码
                        mapTemp.put("name", sysMenu1Bean.getMenu1Name());//一级菜单名称
                        sysMenu1List1.add(mapTemp);
                    }
                }
                map1.put("menuLevel1", sysMenu1List1);
                List sysMenu2List1 = new ArrayList();
                for (int i = 0; i < Menu2CodeList.size(); i++) {
                    SysMenu1Menu2 menu1Menu2 = new SysMenu1Menu2();
                    menu1Menu2.setMenu2Code(Menu2CodeList.get(i));
                    List<SysMenu1Menu2> sysMenu2List = sysMenu1Menu2Service.getList(menu1Menu2);
                    for (SysMenu1Menu2 sysMenu1Menu2Bean : sysMenu2List) {
                        Map mapTemp1 = new HashMap();
                        mapTemp1.put("name", sysMenu1Menu2Bean.getMenu2Name());//二级菜单名称
                        mapTemp1.put("menuLevel1Code", sysMenu1Menu2Bean.getMenu1Code());// 一级菜单编码
                        mapTemp1.put("menuUrl", sysMenu1Menu2Bean.getMenuUrl());//二级菜单指向地址
                        sysMenu2List1.add(mapTemp1);
                    }
                }
                map1.put("menuLevel2", sysMenu2List1);
            }
            map.put("data", map1);
            map.put("code", 10000);
            map.put("msg", "查询成功");
        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }


    //获取所有一级菜单
    @ResponseBody
    @RequestMapping("/menu_menuLevel1")
    @Permission("login")
    public Object menu_menuLevel1(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            SysMenu1 sysMenu1 = new SysMenu1();

            List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);

            List sysMenu1List1 = new ArrayList();
            for (int i = 0; i < sysMenu1List.size(); i++) {
                Map newMap = new HashMap();
                SysMenu1 sysMenu1Bean = sysMenu1List.get(i);
                newMap.put("menuLevel1Code", sysMenu1Bean.getMenu1Code());//一级菜单编码
                newMap.put("name", sysMenu1Bean.getMenu1Name());//一级菜单名称
                sysMenu1List1.add(newMap);
            }
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("menuLevel1", sysMenu1List1);
            map.put("data", map1);


            map.put("code", 10000);
            map.put("msg", "查询成功");


        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }


    //获取指定二级菜单列表
    @ResponseBody
    @RequestMapping("/menu_menuLevel2")
    @Permission("login")
    public Object menu_menuLevel2(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist


            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            JSONObject objectParameter = parseParameter(jsonstring);
            Integer menuLevel1Code = 0;//一级菜单编码
            if (StringUtil.isNotEmpty(objectParameter.optString("menuLevel1Code").toString())) {
                menuLevel1Code = Integer.parseInt(objectParameter.get("menuLevel1Code").toString());
            }

            List sysMenu1List1 = new ArrayList();
            List sysMenu1Menu2List1 = new ArrayList();
            if (menuLevel1Code == 0) {
                //获取指定一级菜单
                SysMenu1 sysMenu1 = new SysMenu1();
                List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);

                for (SysMenu1 sysMenu1Bean : sysMenu1List) {
                    Map menu1Map = new HashMap();
                    menu1Map.put("menuLevel1Code", sysMenu1Bean.getMenu1Code());//一级菜单编码
                    menu1Map.put("name", sysMenu1Bean.getMenu1Name());//一级菜单名称
                    sysMenu1List1.add(menu1Map);
                }
            } else {
                //获取指定二级菜单列表
                SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                sysMenu1Menu2.setMenu1Code(menuLevel1Code);
                List<SysMenu1Menu2> sysMenu1Menu2List = sysMenu1Menu2Service.getList(sysMenu1Menu2);

                for (int i = 0; i < sysMenu1Menu2List.size(); i++) {
                    Map newMap = new HashMap();
                    SysMenu1Menu2 sysMenu1Menu2Bean = sysMenu1Menu2List.get(i);
                    newMap.put("menuLevel2Code", sysMenu1Menu2Bean.getMenu2Code());//二级菜单编码
                    newMap.put("name", sysMenu1Menu2Bean.getMenu2Name());//二级菜单名称
                    newMap.put("url", sysMenu1Menu2Bean.getMenuUrl());//url菜单地址

                    sysMenu1Menu2List1.add(newMap);

                }
            }


            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("menuLevel2", sysMenu1Menu2List1);
            map1.put("menuLevel1", sysMenu1List1);
            map.put("data", map1);

            map.put("code", 10000);
            map.put("msg", "查询成功");


        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    //新增一二级菜单
    @ResponseBody
    @RequestMapping("/menu_addMenus")
    @Permission("login")
    public Object menu_addMenus(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("menuLevel1Code");
            arraylist.add("name");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            JSONObject objectParameter = parseParameter(jsonstring);

            Integer menuLevel1Code = Integer.parseInt(objectParameter.get("menuLevel1Code").toString());//一级菜单编码
            Integer menuLevel2Code = 0;//二级菜单编码
            if (StringUtil.isNotEmpty(objectParameter.optString("menuLevel2Code").toString())) {
                menuLevel2Code = Integer.parseInt(objectParameter.get("menuLevel2Code").toString());
            }

            System.out.println("menuLevel1Code:" + menuLevel1Code);
            System.out.println("menuLevel2Code:" + menuLevel2Code);
            //菜单名称
            String name = objectParameter.get("name").toString();

            //二级菜单url
            String url = null;
            if (StringUtil.isNotEmpty(objectParameter.optString("url").toString())) {
                url = objectParameter.get("url").toString();
            }

            //获取登陆账户
            String user = ((SessionToken) mapToken.get("data")).getUser();

            if (menuLevel1Code != 0 && menuLevel2Code == 0) {
                SysMenu1 sysMenu11 = new SysMenu1();
                sysMenu11.setMenu1Code(menuLevel1Code);
                sysMenu11.setMenu1Name(name);
                sysMenu11.setCreateDate(TimeUtil.getNowStr());//创建时间
                sysMenu11.setCreateBy(user);//创建人
                sysMenu11.setUpdateBy(user);//修改人
                Integer addMenu1 = sysMenu1Service.insert(sysMenu11);
                LogUtil.error("新增一级菜单:" + addMenu1);
                map.put("msg", "新增成功");

            }


            if (menuLevel2Code != 0) {
                //          新增二级菜单
                SysMenu2 sysMenu2 = new SysMenu2();
                sysMenu2.setMenu2Code(menuLevel2Code);//二级菜单编码
                sysMenu2.setMenu2Name(name);//二级菜单名称
                sysMenu2.setMenuUrl(url);//菜单地址
                sysMenu2.setCreateDate(TimeUtil.getNowStr());//创建时间
                sysMenu2.setCreateBy(user);//创建人
                sysMenu2.setUpdateBy(user);//修改人

                Integer addMenu2 = sysMenu2Service.insert(sysMenu2);
                LogUtil.error("新增二级菜单:" + addMenu2);

                //          新增一级菜单管理二级菜单
                SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                sysMenu1Menu2.setMenu1Code(menuLevel1Code);//一级菜单编码
                sysMenu1Menu2.setMenu2Code(menuLevel2Code);//二级菜单编码
                sysMenu1Menu2.setMenu2Name(name);//二级菜单名称
                sysMenu1Menu2.setMenuUrl(url);//菜单地址
                sysMenu1Menu2.setCreateDate(TimeUtil.getNowStr());//创建时间
                sysMenu1Menu2.setCreateBy(user);//创建人
                sysMenu1Menu2.setUpdateBy(user);//修改人

                Integer addM1M2 = sysMenu1Menu2Service.insert(sysMenu1Menu2);
                LogUtil.error("新增一级菜单管理二级菜单:" + addM1M2);
                map.put("msg", "新增成功");

            }


//
//            SysMenu1Menu2 newSysMenu1Menu2 = new SysMenu1Menu2();
//            List<SysMenu1Menu2> sysMenu1Menu2List = null;
//
//            //获取一级菜单
//            SysMenu1 sysMenu1 = new SysMenu1();
//            List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);
//
//            List sysMenu1List1 = new ArrayList();
//            for (int i = 0; i < sysMenu1List.size(); i++) {
//                Map mapTemp = new HashMap();
//                SysMenu1 sysMenu1Bean = sysMenu1List.get(i);
//                mapTemp.put("menuLevel1Code",sysMenu1Bean.getMenu1Code());//一级菜单编码
//                mapTemp.put("name",sysMenu1Bean.getMenu1Name());//一级菜单名称
//                sysMenu1List1.add(mapTemp);
//
//                newSysMenu1Menu2.setMenu1Code(sysMenu1Bean.getMenu1Code());            sysMenu1Menu2List = sysMenu1Menu2Service.getList(newSysMenu1Menu2);
//                sysMenu1Menu2List = sysMenu1Menu2Service.getList(newSysMenu1Menu2);
//
//            }
//
//            //获取二级菜单
//            List sysMenu2List1 = new ArrayList();
//            for (int i = 0; i < sysMenu1Menu2List.size(); i++) {
//                Map mapTemp1 = new HashMap();
//                SysMenu1Menu2 sysMenu1Menu2Bean = sysMenu1Menu2List.get(i);
//                mapTemp1.put("name",sysMenu1Menu2Bean.getMenu2Name());//二级菜单名称
//                mapTemp1.put("menuLevel1Code",sysMenu1Menu2Bean.getMenu1Code());// 一级菜单编码
//                mapTemp1.put("url",sysMenu1Menu2Bean.getMenuUrl());//二级菜单指向地址
//                sysMenu2List1.add(mapTemp1);
//
//            }
//
//            Map<String, Object> map1 = new HashMap<String, Object>();
//            map1.put("menuLevel1",sysMenu1List1);
//            map1.put("menuLevel2",sysMenu2List1);
//            map.put("data",map1);
            map.put("code", 10000);


        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    //获取菜单信息详情
    @ResponseBody
    @RequestMapping("/menu_getMenu")
    @Permission("login")
    public Object menu_getMenu(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("menuLevelCode");
            arraylist.add("level");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            Integer menuLevelCode = Integer.parseInt(objectParameter.get("menuLevelCode").toString());//菜单编码
            Integer level = 0;//1/2（一级/二级）
            if (StringUtil.isNotEmpty(objectParameter.optString("level").toString())) {
                level = Integer.parseInt(objectParameter.get("level").toString());
            }

            if (level == 1) {
                //获取一级菜单详情
                SysMenu1 sysMenu1 = new SysMenu1();
                sysMenu1.setMenu1Code(menuLevelCode);
                List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1);
                Map mapTemp = new HashMap();
//                for (int i = 0; i < sysMenu1List.size(); i++) {

//                    SysMenu1 sysMenu1Bean = sysMenu1List.get(i);
                mapTemp.put("menuLevelCode", sysMenu1List.get(0).getMenu1Code());//一级菜单编码
                mapTemp.put("name", sysMenu1List.get(0).getMenu1Name());//一级菜单名称

//                }
                map.put("data", mapTemp);
                map.put("code", 10000);
                map.put("msg", "查询成功");
            } else if (level == 2) {
                //获取二级菜单详情
                SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                sysMenu1Menu2.setMenu2Code(menuLevelCode);
                List<SysMenu1Menu2> sysMenu1Menu2List = sysMenu1Menu2Service.getList(sysMenu1Menu2);
                Map mapTemp1 = new HashMap();
//                for (int i = 0; i < sysMenu1Menu2List.size(); i++) {
//
//                    SysMenu1Menu2 sysMenu1Menu2Bean = sysMenu1Menu2List.get(i);
                mapTemp1.put("name", sysMenu1Menu2List.get(0).getMenu2Name());//二级菜单名称
                mapTemp1.put("menuLevelCode", sysMenu1Menu2List.get(0).getMenu2Code());// 二级菜单编码
                mapTemp1.put("menuUrl", sysMenu1Menu2List.get(0).getMenuUrl());//二级菜单指向地址

//                }
                map.put("data", mapTemp1);
                map.put("code", 10000);
                map.put("msg", "查询成功");
            } else {
                map.put("code", 10003);
                map.put("msg", "查询失败");
            }


        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    //保存菜单详情
    @ResponseBody
    @RequestMapping("/menu_updateMenu")
    @Permission("login")
    public Object menu_updateMenu(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("menuLevelCode");
            arraylist.add("name");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            Integer menuLevelCode = Integer.parseInt(objectParameter.get("menuLevelCode").toString());//菜单编码
            String name = objectParameter.get("name").toString();//菜单名称
            String menuUrl = null;//菜单URL
            if (StringUtil.isNotEmpty(objectParameter.optString("menuUrl").toString())) {
                menuUrl = objectParameter.get("menuUrl").toString();
            }

            //判断是否为一级菜单编码
            SysMenu1 sysMenu1Parmeter = new SysMenu1();
            sysMenu1Parmeter.setMenu1Code(menuLevelCode);
            List<SysMenu1> sysMenu1List = sysMenu1Service.getList(sysMenu1Parmeter);
            LogUtil.error("判断是否为一级菜单编码:" + sysMenu1List);

            if (sysMenu1List.size() == 1) {

                //修改一级菜单详细信息
                SysMenu1 sysMenu1 = new SysMenu1();
                sysMenu1.setMenu1Name(name);
                Integer menu1 = sysMenu1Service.update(sysMenu1, sysMenu1Parmeter);
                LogUtil.error("修改一级菜单:" + menu1);
                if (menu1 == 1) {
                    map.put("code", 10000);
                    map.put("msg", "修改成功");
                } else if (menu1 != 1) {
                    map.put("code", 10003);
                    map.put("msg", "修改失败");
                }

            }

            //判断是否为二级菜单编码
            SysMenu2 sysMenu2Parmeter = new SysMenu2();
            sysMenu2Parmeter.setMenu2Code(menuLevelCode);
            List<SysMenu2> sysMenu2List = sysMenu2Service.getList(sysMenu2Parmeter);
            LogUtil.error("判断是否为二级菜单编码:" + sysMenu2List);

            if (sysMenu2List.size() == 1) {
                //修改二级菜单详细信息
                SysMenu2 sysMenu2 = new SysMenu2();
                sysMenu2.setMenu2Name(name);
                sysMenu2.setMenuUrl(menuUrl);
                Integer menu2 = sysMenu2Service.update(sysMenu2, sysMenu2Parmeter);
                LogUtil.error("修改二级菜单:" + menu2);


                //修改一级菜单管理二级菜单的详细信息
                SysMenu1Menu2 sysMenu1Menu2Parmeter = new SysMenu1Menu2();
                sysMenu1Menu2Parmeter.setMenu2Code(menuLevelCode);

                SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                sysMenu1Menu2.setMenu2Name(name);
                sysMenu1Menu2.setMenuUrl(menuUrl);
                Integer menu1Menu2 = sysMenu1Menu2Service.update(sysMenu1Menu2, sysMenu1Menu2Parmeter);
                LogUtil.error("根据二级编码修改一二级菜单:" + menu1Menu2);

                if (menu2 == 1 && menu1Menu2 == 1) {
                    map.put("code", 10000);
                    map.put("msg", "修改成功");
                } else if (menu2 != 1 && menu1Menu2 != 1) {
                    map.put("code", 10003);
                    map.put("msg", "修改失败");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    //删除菜单
    @ResponseBody
    @RequestMapping("/menuDelMenu")
    @Permission("login")
    public Object menuDelMenu(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try {//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("level");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            JSONObject parameter = JSONObject.fromObject(object.get("parameter").toString());
            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            Integer level = Integer.parseInt(objectParameter.get("level").toString());//1/2（一级/二级）

            if (level == 1) {
                JSONArray jsonarray = parameter.getJSONArray("menuLevel1");
                List<SysMenu1> sysMenu1List = (List) JSONArray.toCollection(jsonarray, SysMenu1.class);
                System.out.println("sysMenu1List:" + sysMenu1List.size());
                for (SysMenu1 x : sysMenu1List) {
                    SysMenu1 sysMenu11 = new SysMenu1();
                    sysMenu11.setMenu1Code(x.getMenuLevel1Code());
                    Integer m1 = sysMenu1Service.delete(sysMenu11);

                    SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                    sysMenu1Menu2.setMenu1Code(x.getMenuLevel1Code());

                    List<SysMenu1Menu2> sysMenu1Menu2List = sysMenu1Menu2Service.getList(sysMenu1Menu2);
                    Integer m2 = 0;
                    for (SysMenu1Menu2 sysMenu1Menu2Bean : sysMenu1Menu2List) {
                        SysMenu2 sysMenu2 = new SysMenu2();
                        sysMenu2.setMenu2Code(sysMenu1Menu2Bean.getMenu2Code());
                        m2 = sysMenu2Service.delete(sysMenu2);

                    }

                    Integer mm1 = sysMenu1Menu2Service.delete(sysMenu1Menu2);

                    SysRolesMenu2 sysRolesMenu2 = new SysRolesMenu2();
                    sysRolesMenu2.setMenu1Code(x.getMenuLevel1Code());
                    Integer rm1 = sysRolesMenu2Service.delete(sysRolesMenu2);


//                    if (m1!=0&mm1!=0){
                    map.put("code", 10000);
                    map.put("msg", "删除成功");
//                    }
                    System.out.println("m1:" + m1 + "  mm1:" + mm1 + "  rm1:" + rm1 + "  m2:" + m2);

                }
            } else {
                JSONArray jsonarray = parameter.getJSONArray("menuLevel2");
                List<SysMenu2> sysMenu2List = (List) JSONArray.toCollection(jsonarray, SysMenu2.class);
                System.out.println("sysMenu2List:" + sysMenu2List.size());
                for (SysMenu2 x : sysMenu2List) {
                    SysMenu2 sysMenu12 = new SysMenu2();
                    sysMenu12.setMenu2Code(x.getMenuLevel2Code());
                    Integer m2 = sysMenu2Service.delete(sysMenu12);

                    SysMenu1Menu2 sysMenu1Menu2 = new SysMenu1Menu2();
                    sysMenu1Menu2.setMenu2Code(x.getMenuLevel2Code());
                    Integer mm2 = sysMenu1Menu2Service.delete(sysMenu1Menu2);

                    SysRolesMenu2 sysRolesMenu2 = new SysRolesMenu2();
                    sysRolesMenu2.setMenu2Code(x.getMenuLevel2Code());
                    Integer rm2 = sysRolesMenu2Service.delete(sysRolesMenu2);
//                    if (m2!=0&mm2!=0){
                    map.put("code", 10000);
                    map.put("msg", "删除成功");
//                    }
                    System.out.println("m2:" + m2 + "  mm2:" + mm2 + "  rm2:" + rm2);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }


    //解析parameter中数据
    public static JSONObject parseParameter(String json) {
        JSONObject fromObject = JSONObject.fromObject(json);
        Object object = fromObject.get("parameter");
        JSONObject object1 = JSONObject.fromObject(object);
        return object1;
    }

}
