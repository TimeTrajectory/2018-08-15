package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.service.IConversationService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.StringUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhyuj on 2018/8/7.
 * 话单
 */


@Controller
@RequestMapping("/webConversation ")
public class webConversation {

    @Resource(name="conversationService")
    private IConversationService conversationService;

    //话单查询
    @ResponseBody
    @RequestMapping("/getConversationList")
    @Permission("login")
    public Object getConversationList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("pagesize");
            arraylist.add("pageNo");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);
            //主叫号码
            String con_calling = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_calling").toString())){
                con_calling =  objectParameter.get("con_calling").toString();
            }
            //被叫号码
            String con_called = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_called").toString())){
                con_called =  objectParameter.get("con_called").toString();
            }
            //绑定关系
            String con_bindID = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_bindID").toString())){
                con_bindID =  objectParameter.get("con_bindID").toString();
            }

            //开始录音时间起始
            String con_startTime = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_startTime").toString())){
                con_startTime =  objectParameter.get("con_startTime").toString();
            }

            //开始录音时间结束
            String con_startTimeEnd = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_startTimeEnd").toString())){
                con_startTimeEnd =  objectParameter.get("con_startTimeEnd").toString();
            }
//            System.out.println(con_startTimeEnd);
            //录音时长
            Integer con_duration = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_duration").toString())){
                con_duration =  Integer.parseInt(objectParameter.get("con_duration").toString());
            }

            Integer pagesize = Integer.parseInt(objectParameter.get("pagesize").toString());//每页显示条数
            Integer pageNo = Integer.parseInt(objectParameter.get("pageNo").toString());//当前页数

            int startRow = (pageNo - 1) * pagesize;

            Conversation conversation = new Conversation();
            conversation.setCalling(con_calling);
            conversation.setCalled(con_called);
            conversation.setBindID(con_bindID);
            conversation.setStartDate(con_startTime);
            conversation.setEndDate(con_startTimeEnd);
            conversation.setDuration(con_duration);
            conversation.setPageSize(pagesize);
            conversation.setStartRow(startRow);

            // 按条件查询的总数
            Integer count =  conversationService.getListCount(conversation);

            // 寻找符合条件的集合
            List<Conversation> conversationList =  conversationService.getList(conversation);

            List conversationList1 = new ArrayList();
            for (int i=0;i<conversationList.size();i++){
                Map mapTemp = new HashMap();
                Conversation conversationBean = conversationList.get(i);
                mapTemp.put("calling",conversationBean.getCalling());//主叫号码
                mapTemp.put("called",conversationBean.getCalled());//被叫号码
                mapTemp.put("startTime",conversationBean.getStartTime());//开始录音时间
                mapTemp.put("duration",conversationBean.getDuration());//录音时长
                mapTemp.put("uniqueId",conversationBean.getUniqueId());//录音唯一标识
                conversationList1.add(mapTemp);
            }
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("conversation",conversationList1);
            map1.put("count",count);
            map1.put("pageNo",pageNo);
            map.put("data",map1);


            map.put("code",10000);
            map.put("msg", "查询成功");


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }


    //话单详情
    @ResponseBody
    @RequestMapping("/getConversation")
    @Permission("login")
    public Object getConversation(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("callIdentifier");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);
            //呼叫唯一标识
            String callIdentifier = objectParameter.get("callIdentifier").toString();

            Conversation conversation = new Conversation();
            conversation.setCallIdentifier(callIdentifier);
            List<Conversation> conversationList = conversationService.getList(conversation);

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("callIdentifier",conversationList.get(0).getCallIdentifier());//呼叫唯一标识
            map1.put("calling",conversationList.get(0).getCalling());//主叫号码
            map1.put("called",conversationList.get(0).getCalled());//被叫号码
            map1.put("virtualNumber",conversationList.get(0).getVirtualNumber());//虚拟号码
            map1.put("event",conversationList.get(0).getEvent());//呼叫状态事件
            map1.put("timestamp",conversationList.get(0).getTimestamp());//呼叫时间
            map1.put("rawCalling",conversationList.get(0).getRawCalling());//信令中的主叫号码
            map1.put("rawCallingNOA",conversationList.get(0).getRawCallingNOA());//信令中主叫号码的号码属性
            map1.put("rawCalled",conversationList.get(0).getRawCalled());//信令中的被叫号码
            map1.put("rawCalledNOA",conversationList.get(0).getRawCalledNOA());//信令中被叫号码的号码属性
            map1.put("releaseReason",conversationList.get(0).getReleaseReason());//呼叫结束原因
            map1.put("uniqueId",conversationList.get(0).getUniqueId());//标识消息的唯一 ID
            map1.put("bindID",conversationList.get(0).getBindID());//绑定关系 ID
            map1.put("StartTime",conversationList.get(0).getStartTime());//呼叫开始的时间戳
            map1.put("duration",conversationList.get(0).getDuration());//通话时长，单位为秒

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg", "查询成功");


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

    //解析parameter中数据
    public static JSONObject parseParameter(String json) {
        JSONObject fromObject = JSONObject.fromObject(json);
        Object object = fromObject.get("parameter");
        JSONObject object1 = JSONObject.fromObject(object);
        return object1;
    }
}
