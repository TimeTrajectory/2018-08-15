package com.cn.hjsj.base.validation;

public class PermissionValidation {
 public static boolean cheackPermission(String role,String keyValues)
 {
	 return true;
 }
}
