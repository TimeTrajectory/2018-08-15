package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SoundRecording extends BaseBean {

    private String recordId;
    private String callIdentifier;
    private String calling;
    private String called;
    private String bindID;
    private String duration;
    private String createTime;
    private String recordUrl;
    private String startDate;
    private String endDate;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {

        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }


    public String getRecordId() {
        return recordId;
    }
    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getCallIdentifier() {
        return callIdentifier;
    }
    public void setCallIdentifier(String callIdentifier) {
        this.callIdentifier = callIdentifier;
    }

    public String getCalling() {
        return calling;
    }
    public void setCalling(String calling) {
        this.calling = calling;
    }

    public String getCalled() {
        return called;
    }
    public void setCalled(String called) {
        this.called = called;
    }

    public String getBindID() {
        return bindID;
    }
    public void setBindID(String bindID) {
        this.bindID = bindID;
    }

    public String getDuration() {
        return duration;
    }
    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getCreateTime() {
        return createTime;
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getRecordUrl() {
        return recordUrl;
    }
    public void setRecordUrl(String recordUrl) {
        this.recordUrl = recordUrl;
    }

}
