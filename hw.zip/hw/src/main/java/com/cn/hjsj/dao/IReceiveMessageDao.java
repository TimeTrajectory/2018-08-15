package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.ReceiveMessage;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IReceiveMessageDao")
public interface IReceiveMessageDao {

    public Integer insert(ReceiveMessage receiveMessage);
    public List<ReceiveMessage> getList(ReceiveMessage receiveMessage);
    public Integer update(@Param("receiveMessage") ReceiveMessage receiveMessage, @Param("receiveMessageParmeter")ReceiveMessage receiveMessageParmeter);
    public Integer getListCount(ReceiveMessage receiveMessage);

}
