package com.cn.hjsj.service;

import com.cn.hjsj.pojo.Api;
import java.util.List;

public interface IApiService {

    public Integer insert(Api api);
    public Integer update(Api api,Api apiParmeter);
    public List<Api> getList(Api api);
    public Integer getListCount(Api api);

}
