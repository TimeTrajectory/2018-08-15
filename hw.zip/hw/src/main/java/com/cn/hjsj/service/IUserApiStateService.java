package com.cn.hjsj.service;

import com.cn.hjsj.pojo.UserApiState;
import java.util.List;

public interface IUserApiStateService {

    public Integer insert(UserApiState userApiState);
    public Integer update(UserApiState userApiState,UserApiState userApiStateParmeter);
    public List<UserApiState> getList(UserApiState userApiState);
    public Integer getListCount(UserApiState userApiState);

}
