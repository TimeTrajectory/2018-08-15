package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IConversationDao;
import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.service.IConversationService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("conversationService")
public class IConversationServiceImpl implements IConversationService {

    @Resource(name="IConversationDao")
    private IConversationDao iConversationDao;

    @Override
    public List<Conversation> getList(Conversation conversation) {
        return iConversationDao.getList(conversation);
    }

    @Override
    public Integer update(Conversation conversation, Conversation conversationParmeter) {
        return iConversationDao.update(conversation,conversationParmeter);
    }

    @Override
    public Integer insert(Conversation conversation) {
        return iConversationDao.insert(conversation);
    }

    public Integer getListCount(Conversation conversation){
        return iConversationDao.getListCount(conversation);
    }
}
