package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SessionToken;
import java.util.List;

public interface ISessionTokenService {

    public List<SessionToken> getList(SessionToken sessionToken);
    public Integer insert(SessionToken sessionToken);
    public Integer update(SessionToken sessionToken,SessionToken sessionTokenParmeter);
    public Integer getListCount(SessionToken sessionToken);
    public Integer delete(SessionToken sessionToken);//用于注销

}
