package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.UserApi;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IUserApiDao")
public interface IUserApiDao {

    public List<UserApi> getList(UserApi userApi);
    public Integer insert(UserApi userApi);
    public Integer update(@Param("userApi")UserApi userApi, @Param("userApiParmeter")UserApi userApiParmeter);
    public Integer getListCount(UserApi userApi);


}
