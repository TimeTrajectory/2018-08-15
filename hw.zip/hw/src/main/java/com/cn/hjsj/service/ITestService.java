package com.cn.hjsj.service;

import com.cn.hjsj.pojo.Test;

import java.util.List;

public interface ITestService {

    public Integer insert(Test test);
    public Integer update(Test test, Test testParmeter);
    public List<Test> getList(Test test);
    public Integer getListCount(Test test);

}
