package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.SysUserRoles;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISysUserRolesDao")
public interface ISysUserRolesDao {
    public Integer insert(SysUserRoles sysUserRoles);
    public Integer update(@Param("sysUserRoles") SysUserRoles sysUserRoles, @Param("sysUserRolesParmeter") SysUserRoles sysUserRolesParmeter);
    public List<SysUserRoles> getList(SysUserRoles sysUserRoles);


}
