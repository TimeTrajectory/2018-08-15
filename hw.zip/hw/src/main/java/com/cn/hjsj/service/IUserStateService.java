package com.cn.hjsj.service;

import com.cn.hjsj.pojo.UserState;
import java.util.List;

public interface IUserStateService {

    public Integer insert(UserState userState);
    public Integer update(UserState userState,UserState userStateParmeter);
    public List<UserState> getList(UserState userState);
    public Integer getListCount(UserState userState);

}
