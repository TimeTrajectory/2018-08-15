package com.cn.hjsj.base.cache;

import com.cn.hjsj.pojo.User;
import com.cn.hjsj.pojo.UserApi;
import com.cn.hjsj.service.impl.IUserApiServiceImpl;
import com.cn.hjsj.service.impl.IUserServiceImpl;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.SpringUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserCache {
    private static Map<String, Object> pars = null;

    static {
        try{
            IUserServiceImpl userService = (IUserServiceImpl) SpringUtil.getBean("userService");

            User user = new User();
            user.setState("Y");
            List<User> li = userService.getUserCacheList(user);

            pars = new HashMap<String, Object>();
            for (int i = 0; i < li.size(); i++) {
                Map<String, Object> map = new HashMap<String, Object>();

                IUserApiServiceImpl userApiService = (IUserApiServiceImpl) SpringUtil.getBean("userApiService");
                UserApi userApi = new UserApi();
                userApi.setUserCode(li.get(i).getUserCode());
                userApi.setState("Y");
                userApi.setOrderColName("apiCode");

                List<UserApi> u =  userApiService.getList(userApi);

                Integer a[] = new Integer[u.size()];
                if(u != null && u.size()>0){
                    for(int j=0;j<u.size();j++){
                        a[j] = u.get(j).getApiCode();
                    }
                }

                map.put("user",li.get(i).getUser());
                map.put("password",li.get(i).getPassword());
                map.put("key",li.get(i).getUserKey());
                map.put("apiCodePower",a);

                pars.put(li.get(i).getUser(),map);
            }
        }catch(Exception e){
            LogUtil.error("内存加载用户表失败，错误原因：" + e.getMessage());
        }
    }

    public static Object get(String key) {
        try{
            return pars.get(key);
        }catch(Exception e){
            LogUtil.error("内存获取用户失败，错误原因：" + e.getMessage());
        }

        return null;
    }

    public static boolean JudgeUser(String key) {
        boolean flag = false;
        try{
            flag = pars.containsKey(key);
        }catch(Exception e){
            LogUtil.error("内存校验用户是否存在失败，错误原因：" + e.getMessage());
        }

        return flag;
    }

    public static void reload() {
        try{
            IUserServiceImpl userService = (IUserServiceImpl) SpringUtil.getBean("userService");

            User user = new User();
            user.setState("Y");
            List<User> li = userService.getUserCacheList(user);

            if(li.size() > 0){
                pars = new HashMap<String, Object>();
                for (int i = 0; i < li.size(); i++) {
                    Map<String, Object> map = new HashMap<String, Object>();

                    IUserApiServiceImpl userApiService = (IUserApiServiceImpl) SpringUtil.getBean("userApiService");
                    UserApi userApi = new UserApi();
                    userApi.setUserCode(li.get(i).getUserCode());
                    userApi.setState("Y");
                    userApi.setOrderColName("apiCode");

                    List<UserApi> u =  userApiService.getList(userApi);

                    Integer a[] = new Integer[u.size()];
                    if(u != null && u.size()>0){
                        for(int j=0;j<u.size();j++){
                            a[j] = u.get(j).getApiCode();
                        }
                    }

                    map.put("user",li.get(i).getUser());
                    map.put("password",li.get(i).getPassword());
                    map.put("key",li.get(i).getUserKey());
                    map.put("apiCodePower",a);

                    pars.put(li.get(i).getUser(),map);
                }
                LogUtil.info("内存重新加载用户表成功");
            }
        }catch(Exception e){
            LogUtil.error("内存重新加载用户表失败，错误原因：" + e.getMessage());
        }
    }

    public static void reloadOne(String username) {
        try{
            IUserServiceImpl userService = (IUserServiceImpl) SpringUtil.getBean("userService");

            User user = new User();
            user.setUser(username);
            user.setState("Y");
            List<User> li = userService.getUserCacheList(user);

            if(li != null){
                IUserApiServiceImpl userApiService = (IUserApiServiceImpl) SpringUtil.getBean("userApiService");
                UserApi userApi = new UserApi();
                userApi.setUserCode(li.get(0).getUserCode());
                userApi.setState("Y");
                userApi.setOrderColName("apiCode");

                List<UserApi> u =  userApiService.getList(userApi);

                Integer a[] = new Integer[u.size()];
                if(u != null && u.size()>0){
                    for(int j=0;j<u.size();j++){
                        a[j] = u.get(j).getApiCode();
                    }
                }

                Map<String, Object> map = new HashMap<String, Object>();

                map.put("user",li.get(0).getUser());
                map.put("password",li.get(0).getPassword());
                map.put("key",li.get(0).getUserKey());
                map.put("apiCodePower",a);

                pars.put(username,map);

                LogUtil.info("内存重新加载" + username + "成功");
            }
        }catch(Exception e){
            LogUtil.error("内存重新加载" + username + "失败，错误原因：" + e.getMessage());
        }
    }

}
