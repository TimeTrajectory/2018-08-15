      package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SysMenu1 extends BaseBean {
    private Integer menu1Code;
    private String menu1Name;
    private Integer menuLevel1Code;

    public Integer getMenuLevel1Code() {
        return menuLevel1Code;
    }

    public void setMenuLevel1Code(Integer menuLevel1Code) {
        this.menuLevel1Code = menuLevel1Code;
    }

    public Integer getMenu1Code() {
        return menu1Code;
    }

    public void setMenu1Code(Integer menu1Code) {
        this.menu1Code = menu1Code;
    }

    public String getMenu1Name() {
        return menu1Name;
    }

    public void setMenu1Name(String menu1Name) {
        this.menu1Name = menu1Name;
    }
}
