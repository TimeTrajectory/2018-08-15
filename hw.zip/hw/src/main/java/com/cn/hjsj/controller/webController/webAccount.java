package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.*;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.Md5Util;
import com.cn.hjsj.util.StringUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import com.ctc.wstx.sw.EncodingXmlWriter;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;
//import org.apache.commons.mail.*;



/**
 * Created by zhyuj on 2018/8/1.
 * 企业帐号审核
 */
@Controller
@RequestMapping("/webAccount")
public class webAccount {

    @Resource(name="userStateService")
    private IUserStateService userStateService;
    @Resource(name="userService")
    private IUserService userService;
    @Resource(name="userInfoService")
    private IUserInfoService userInfoService;

    //批量查询
    @ResponseBody
    @RequestMapping("/getAccList")
    @Permission("login")
    public Object getAccList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("con_examineState");
            arraylist.add("pagesize");
            arraylist.add("pageNo");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();
            JSONObject objectParameter = parseParameter(jsonstring);

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }


            //审核状态
            Integer con_examineState =  Integer.parseInt(objectParameter.get("con_examineState").toString());
            //企业名称
            String con_enterpriseName = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("con_enterpriseName").toString())){
                con_enterpriseName =  objectParameter.get("con_enterpriseName").toString();
            }

            Integer pagesize = Integer.parseInt(objectParameter.get("pagesize").toString());//每页显示条数
            Integer pageNo = Integer.parseInt(objectParameter.get("pageNo").toString());//当前页数

            int startRow = (pageNo - 1) * pagesize;
            UserState userState = new UserState();
            userState.setExamineState(con_examineState);
            userState.setEnterpriseName(con_enterpriseName);
            userState.setStartRow(startRow);
            userState.setPageSize(pagesize);

            // 按条件查询的总数
            Integer count =  userStateService.getListCount(userState);

            // 寻找符合条件的集合
            List<UserState> userStateServiceList =  userStateService.getList(userState);

            List userStateServiceList1 = new ArrayList();
            for (int i=0;i<userStateServiceList.size();i++){
                Map mapTemp = new HashMap();
                UserState userStateBean = userStateServiceList.get(i);
                mapTemp.put("id",userStateBean.getId());//id
                mapTemp.put("user",userStateBean.getUser());//帐号
                mapTemp.put("tel",userStateBean.getTel());//绑定手机号
                mapTemp.put("enterpriseName",userStateBean.getEnterpriseName());//企业名称
                mapTemp.put("createDate",userStateBean.getCreateDate());//创建时间(即申请时间)
                userStateServiceList1.add(mapTemp);
            }
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("userState",userStateServiceList1);
            map1.put("count",count);
            map1.put("pageNo",pageNo);
            map.put("data",map1);

            map.put("code",10000);
            map.put("msg", "查询成功");


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

    //查询详情
    @ResponseBody
    @RequestMapping("/getAcc")
    @Permission("login")
    public Object getAcc(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("id");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject objectParameter = parseParameter(jsonstring);

            //id
            Integer id =  Integer.parseInt(objectParameter.get("id").toString());
            UserState userState = new UserState();
            userState.setId(id);

            // 寻找符合条件的集合
            List<UserState> userStateServiceList =  userStateService.getList(userState);

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("user",userStateServiceList.get(0).getUser());//帐号
            map1.put("tel",userStateServiceList.get(0).getTel());//绑定手机号
            map1.put("enterpriseName",userStateServiceList.get(0).getEnterpriseName());//企业名称
            map1.put("enterpriseID",userStateServiceList.get(0).getEnterpriseID());//单位证件类型（营业执照）
            map1.put("licenseID",userStateServiceList.get(0).getLicenseID());//营业执照证件号码
            map1.put("licenseAddress",userStateServiceList.get(0).getLicenseAddress());//营业执照地址
            map1.put("enterpriseAddress",userStateServiceList.get(0).getEnterpriseAddress());//单位通讯地址
            map1.put("licensePhoto",userStateServiceList.get(0).getLicensePhoto());//营业执照（照片名）
            map1.put("liableName",userStateServiceList.get(0).getLiableName());//责任人姓名
            map1.put("liableID",userStateServiceList.get(0).getLiableID());//责任人身份证号
            map1.put("liableIDAddress",userStateServiceList.get(0).getLiableAddress());//责任人身份证地址
            map1.put("liableAddress",userStateServiceList.get(0).getLiableAddress());//责任人通讯地址
            map1.put("liablePhoto1",userStateServiceList.get(0).getLiablePhoto1());//责任人身份证正面（照片名）
            map1.put("liablePhoto2",userStateServiceList.get(0).getLiablePhoto2());//责任人身份证背面（照片名）
            map1.put("agencyName",userStateServiceList.get(0).getAgencyName());//代办人姓名
            map1.put("agencyID",userStateServiceList.get(0).getAgencyID());//代办人身份证号
            map1.put("agencyIDAddress",userStateServiceList.get(0).getAgencyIDAddress());//代办人身份证地址
            map1.put("agencyAddress",userStateServiceList.get(0).getAgencyAddress());//代办人通讯地址
            map1.put("agencyTel",userStateServiceList.get(0).getAgencyTel());//代办人手机号
            map1.put("agencyPhoto1",userStateServiceList.get(0).getAgencyPhoto1());//代办人身份证正面（照片名）
            map1.put("agencyPhoto2",userStateServiceList.get(0).getAgencyPhoto2());//代办人身份证背面（照片名）
            map1.put("agencyPhoto3",userStateServiceList.get(0).getAgencyPhoto3());//代办人手持身份证照片（照片名）
            map1.put("email",userStateServiceList.get(0).getEmail());//邮箱地址（接收审核结果的通知）
            map1.put("examineState",userStateServiceList.get(0).getExamineState());//审核状态
            map1.put("examineStateName",userStateServiceList.get(0).getExamineStateName());//审核状态名称
            map1.put("reason",userStateServiceList.get(0).getReason());//审核未通过原因
            map1.put("examineName",userStateServiceList.get(0).getExamineName());//审核人

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg", "查询成功");


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }
    //审核
    @ResponseBody
    @RequestMapping("/examineAcc")
    @Permission("login")
    public Object examineAcc(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("id");
            arraylist.add("examineState");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            JSONObject objectParameter = parseParameter(jsonstring);

            //id
            Integer id =  Integer.parseInt(objectParameter.get("id").toString());
            //审核状态（1/2 审核通过/审核未通过）
            Integer examineState =  Integer.parseInt(objectParameter.get("examineState").toString());
            String stateName = null;
            if(examineState==1){
                stateName = "审核通过";
            }else if(examineState==2){
                stateName = "审核未通过";
            }
            //审核未通过原因
            String reason = null;
            if(StringUtil.isNotEmpty(objectParameter.optString("reason").toString())){
                reason =  objectParameter.get("reason").toString();
            }
            UserState userStateParmeter = new UserState();
            userStateParmeter.setId(id);

            UserState userState = new UserState();
            userState.setExamineState(examineState);
            userState.setExamineStateName(stateName);
            userState.setReason(reason);

            //修改审核结果
            Integer examine =  userStateService.update(userState,userStateParmeter);
            LogUtil.error("审核结果： "+ examine);
            // 寻找符合条件的集合
            List<UserState> userStateList = userStateService.getList(userStateParmeter);

            //获取登陆账户
            String user1 = ((SessionToken)mapToken.get("data")).getUser();

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddhhmmss");

            Date date = new Date();

            String str = simpleDateFormat.format(date);

            String pwd = "HJSJ"+userStateList.get(0).getPassword()+"2015GK#S";
//            System.out.println("pwd :"+pwd);
            Md5Util.GetMD5Code(pwd);
//            System.out.println("Md5Util.GetMD5Code(pwd):"+Md5Util.GetMD5Code(pwd));
            if(examineState==1){
                User user = new User();
                user.setUserCode(str);
                user.setUser(userStateList.get(0).getUser());
                user.setPassword(Md5Util.GetMD5Code(pwd));
                user.setRoleId(3);
                user.setUserKey(str);
                user.setTel(userStateList.get(0).getTel());
                user.setEnterpriseName(userStateList.get(0).getEnterpriseName());
                user.setState("Y");
                user.setCreateDate(TimeUtil.getNowStr());
                user.setCreateBy(user1);
                user.setUpdateDate(TimeUtil.getNowStr());
                user.setUpdateBy(user1);

                Integer addUser = userService.insert(user);
                System.out.println("addUser:" +addUser);

                UserInfo userInfo = new UserInfo();
                userInfo.setUserCode(str);
                userInfo.setEnterpriseName(userStateList.get(0).getEnterpriseName());
                userInfo.setEnterpriseID(userStateList.get(0).getEnterpriseID());
                userInfo.setLicenseID(userStateList.get(0).getLicenseID());
                userInfo.setLicenseAddress(userStateList.get(0).getLicenseAddress());
                userInfo.setEnterpriseAddress(userStateList.get(0).getEnterpriseAddress());
                userInfo.setLicensePhoto(userStateList.get(0).getLicensePhoto());
                userInfo.setLiableName(userStateList.get(0).getLiableName());
                userInfo.setLiableID(userStateList.get(0).getLiableID());
                userInfo.setLiableIDAddress(userStateList.get(0).getLiableIDAddress());
                userInfo.setLiableAddress(userStateList.get(0).getLiableAddress());
                userInfo.setLiablePhoto1(userStateList.get(0).getLiablePhoto1());
                userInfo.setLiablePhoto2(userStateList.get(0).getLiablePhoto2());
                userInfo.setAgencyName(userStateList.get(0).getAgencyName());
                userInfo.setAgencyID(userStateList.get(0).getAgencyID());
                userInfo.setAgencyIDAddress(userStateList.get(0).getAgencyIDAddress());
                userInfo.setAgencyAddress(userStateList.get(0).getAgencyAddress());
                userInfo.setAgencyTel(userStateList.get(0).getAgencyTel());
                userInfo.setAgencyPhoto1(userStateList.get(0).getAgencyPhoto1());
                userInfo.setAgencyPhoto2(userStateList.get(0).getAgencyPhoto2());
                userInfo.setAgencyPhoto3(userStateList.get(0).getAgencyPhoto3());

                Integer addUserInfo = userInfoService.insert(userInfo);

                System.out.println("addUserInfo:"+addUserInfo);
            }


            //邮箱
//            String email = userStateList.get(0).getEmail();
            String email = "wangjd@hjsj.com";
            //String email = "13732209507@163.com";
            String title = "审核结果";
            String content = userStateList.get(0).getExamineStateName()+"\t"+userStateList.get(0).getReason();
//            System.out.println("邮箱:"+email);


//            send(email,title,content);
            map.put("code",10000);
            map.put("msg",userStateList.get(0).getExamineStateName());



        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }



//    public static void send(String accEmail,String title ,String content)
//    {
//        SimpleEmail email = new SimpleEmail();
////        email.setTLS(true);
//      /*  email.setHostName("mail.hjsj.com");
//          email.setSmtpPort(587);
//          email.setAuthentication("hurt@hjsj.com", "Aa123456");   //用户名和密码*/
//        email.setHostName("smtp.qq.com");
//        email.setAuthentication("360898689@qq.com", "oirwfkmonzyxbjhh");
//
//        try
//        {
//            email.addTo(accEmail); //接收方
//            email.setFrom("360898689@qq.com");       //发送方
//            email.setSubject(title);         //标题
//            email.setMsg(content);   //内容
//            email.send();
//
//        } catch (EmailException e) {
//            e.printStackTrace();
//        }
//    }

    //解析parameter中数据
    public static JSONObject parseParameter(String json) {
        JSONObject fromObject = JSONObject.fromObject(json);
        Object object = fromObject.get("parameter");
        JSONObject object1 = JSONObject.fromObject(object);
        return object1;
    }


}
