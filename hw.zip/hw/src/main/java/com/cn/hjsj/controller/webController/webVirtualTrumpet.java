package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.interfaceUtil.AXBInterface;
import com.cn.hjsj.interfaceUtil.AXInterface;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Linz on 2018/8/7.
 */
@Controller
@RequestMapping("/webVirtualTrumpet")
public class webVirtualTrumpet {

    public static final String VIRTUAL_NUMBER = "virtualNumber";
    @Resource(name = "AXBInterfaceUtil")
    private AXBInterface axbInterface;

    @Resource(name = "AXInterfaceUtil")
    private AXInterface axInterface;


    //交易小号AXB绑定
    @ResponseBody
    @RequestMapping("/AXB_BD")
    @Permission("login")
    public Object AXB_BD(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);

        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("aParty");
            arraylist.add("bParty");
            map = webCheck.checkJson(jsonstring, arraylist);

            Map data = new HashMap();
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            JSONObject paramterJson = object.getJSONObject("parameter");

            //非空判断
            if (paramterJson.containsKey("virtualNumber")) {
                requestMap.put("virtualNumber", paramterJson.getString("virtualNumber"));
            }
            if (paramterJson.containsKey("isRecord")) {
                requestMap.put("isRecord", paramterJson.getString("isRecord"));
            }
            if (paramterJson.containsKey("bindDirection")) {
                requestMap.put("bindDirection", paramterJson.getString("bindDirection"));
            }
            if (paramterJson.containsKey("extParas")) {
                if (paramterJson.getJSONArray("extParas").size()!=0) {
                    if (paramterJson.getJSONArray("extParas").getJSONObject(0).get("cityCode")!=null) {
                        requestMap.put("cityCode",paramterJson.getJSONArray("extParas").getJSONObject(0).getString("cityCode"));
                    }
                    if (paramterJson.getJSONArray("extParas").getJSONObject(0).get("endTime")!=null) {
                        requestMap.put("endTime", paramterJson.getJSONArray("extParas").getJSONObject(0).getString("endTime"));
                    }
                }
            }
            requestMap.put("aParty", paramterJson.getString("aParty"));
            requestMap.put("bParty", paramterJson.getString("bParty"));

            Map<String, Object> returnMap = axbInterface.axbBindNumber(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
                map.put("data", returnMap.get("result"));
            } else {
                map.put("code", 10003);
                map.put("msg", "交易小号AXB绑定失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //交易小号 AXB 解绑接口
    @ResponseBody
    @RequestMapping("/AXB_JB")
    @Permission("login")
    public Object AXB_JB(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            JSONObject paramterJson = object.getJSONObject("parameter");

            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            if (paramterJson.get("type") != null && "2".equals(paramterJson.get("type").toString())) {
                arraylist.add("subscriptionId");
            } else {
                arraylist.add("number");
            }
            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            //非空判断
            if (paramterJson.get("type") != null && "2".equals(paramterJson.get("type").toString())) {
                requestMap.put("type", paramterJson.getString("type"));
                requestMap.put("subscriptionId", paramterJson.getString("subscriptionId"));
            } else {
                requestMap.put("number", paramterJson.getString("number"));
            }

            if (paramterJson.containsKey("protectInfo")) {
                if (paramterJson.getJSONArray("protectInfo").size()!=0) {
                    if (paramterJson.getJSONArray("protectInfo").getJSONObject(0).get("relationProtect")!=null) {
                        requestMap.put("relationProtect",paramterJson.getJSONArray("protectInfo").getJSONObject(0).getString("relationProtect"));
                    }
                    if (paramterJson.getJSONArray("protectInfo").getJSONObject(0).get("bindDirection")!=null) {
                        requestMap.put("bindDirection", paramterJson.getJSONArray("protectInfo").getJSONObject(0).getString("bindDirection"));
                    }
                    if (paramterJson.getJSONArray("protectInfo").getJSONObject(0).get("endTime")!=null) {
                        requestMap.put("endTime", paramterJson.getJSONArray("protectInfo").getJSONObject(0).getString("endTime"));
                    }
                }
            }

            Map<String, Object> returnMap = axbInterface.axbUnbindNumber(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
            } else {
                map.put("code", 10003);
                map.put("msg", "交易小号AXB解绑失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //交易小号 AXB 转绑接口
    @ResponseBody
    @RequestMapping("/AXB_ZB")
    @Permission("login")
    public Object AXB_ZB(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("subscriptionId");
            arraylist.add("bPartyNew");
            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject paramterJson = object.getJSONObject("parameter");

            requestMap.put("subscriptionId", paramterJson.getString("subscriptionId"));
            requestMap.put("bPartyNew", paramterJson.getString("bPartyNew"));

            Map<String, Object> returnMap = axbInterface.axbModifyNumber(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
            } else {
                map.put("code", 10003);
                map.put("msg", "交易小号AXB转绑失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


// 查询虚拟号码接口

    @ResponseBody
    @RequestMapping("/AXB_SEL")
    @Permission("login")
    public Object AXB_SEL(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("virtualNumber");
            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject paramterJson = object.getJSONObject("parameter");

            requestMap.put("virtualNumber", paramterJson.getString("virtualNumber"));

            Map<String, Object> returnMap = axbInterface.queryOrderedNumber(requestMap);
            Map result = new HashMap();
            if ("000000".equals(returnMap.get("code"))) {
                result = (Map) returnMap.get("result");
                Map resultMap = new HashMap();
                resultMap.put("result",result);

                map.put("code", 10000);
                map.put("msg", "成功");
                map.put("data", resultMap);
            } else {
                map.put("code", 10003);
                map.put("msg", "查询虚拟号码失败:" + returnMap.get("description"));
            }

        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //个人小号 AX 绑定接口
    @ResponseBody
    @RequestMapping("/AX_BD")
    @Permission("login")
    public Object AX_BD(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("virtualNumber");
            arraylist.add("aParty");
            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            JSONObject paramterJson = object.getJSONObject("parameter");

            //非空判断
            if (paramterJson.containsKey("isRecord")) {
                requestMap.put("isRecord", paramterJson.getString("isRecord"));
            }
            if (paramterJson.containsKey("calledNumDisplay")) {
                requestMap.put("calledNumDisplay", paramterJson.getString("calledNumDisplay"));
            }
            if (paramterJson.containsKey("extParas")) {
                if (paramterJson.getJSONArray("extParas").size()!=0) {
                    if (paramterJson.getJSONArray("extParas").getJSONObject(0).get("cityCode")!=null) {
                        requestMap.put("cityCode",paramterJson.getJSONArray("extParas").getJSONObject(0).getString("cityCode"));
                    }
                    if (paramterJson.getJSONArray("extParas").getJSONObject(0).get("endTime")!=null) {
                        requestMap.put("endTime", paramterJson.getJSONArray("extParas").getJSONObject(0).getString("endTime"));
                    }
                }
            }
            requestMap.put("virtualNumber", paramterJson.getString("virtualNumber"));
            requestMap.put("aParty", paramterJson.getString("aParty"));

            Map<String, Object> returnMap = axInterface.axBindNumber(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
                map.put("data", returnMap.get("result"));
            } else {
                map.put("code", 10003);
                map.put("msg", "个人小号AX绑定失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //个人小号 AX 解绑接口
    @ResponseBody
    @RequestMapping("/AX_JB")
    @Permission("login")
    public Object AX_JB(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            JSONObject paramterJson = object.getJSONObject("parameter");

            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            if (paramterJson.get("type") != null && "2".equals(paramterJson.get("type").toString())) {
                arraylist.add("subscriptionId");
            } else {
                arraylist.add("number");
            }
            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            //非空判断
            if (paramterJson.get("type") != null && "2".equals(paramterJson.get("type").toString())) {
                requestMap.put("type", paramterJson.getString("type"));
                requestMap.put("subscriptionId", paramterJson.getString("subscriptionId"));
            } else {
                requestMap.put("number", paramterJson.getString("number"));
            }

            Map<String, Object> returnMap = axInterface.axUnbindNumber(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
            } else {
                map.put("code", 10003);
                map.put("msg", "个人小号AX解绑失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //个人小号 AX 逻辑开关机接口
    @ResponseBody
    @RequestMapping("/AX_KG")
    @Permission("login")
    public Object AX_KG(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("virtualNumber");
            arraylist.add("status");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            JSONObject paramterJson = object.getJSONObject("parameter");

            //非空判断
            if (paramterJson.containsKey("function")) {
                requestMap.put("function", paramterJson.getString("function"));
            }
            requestMap.put("virtualNumber", paramterJson.getString("virtualNumber"));
            requestMap.put("status", paramterJson.getString("status"));

            Map<String, Object> returnMap = axInterface.axSetLogicPowerStatus(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
            } else {
                map.put("code", 10003);
                map.put("msg", "个人小号AX逻辑开关机失败:" + returnMap.get("description"));
            }
        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


    //查询录音列表接口
    @ResponseBody
    @RequestMapping("/getRecordingList")
    @Permission("login")
    public Object getRecordingList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>(2);
        Map<String, String> requestMap = new HashMap<String, String>();

        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            JSONObject paramterJson = object.getJSONObject("parameter");

            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("startTime");
            arraylist.add("endTime");

            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            if (!paramterJson.containsKey("subscriptionId") || paramterJson.containsKey("callIdentifier")) {
                map.put("code", 20006);
                map.put("msg", "缺少参数");
                return map;
            }

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回mapToken
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            //非空判断
            if (paramterJson.containsKey("subscriptionId")) {
                requestMap.put("subscriptionId", paramterJson.getString("subscriptionId"));
            }
            if (paramterJson.containsKey("callIdentifier")) {
                requestMap.put("callIdentifier", paramterJson.getString("callIdentifier"));
            }
            if (paramterJson.containsKey("page")) {
                requestMap.put("page", paramterJson.getString("page"));
            }
            if (paramterJson.containsKey("pageSize")) {
                requestMap.put("pageSize", paramterJson.getString("pageSize"));
            }

            requestMap.put("startTime", paramterJson.getString("startTime"));
            requestMap.put("endTime", paramterJson.getString("endTime"));

            Map<String, Object> returnMap = axInterface.queryRecordList(requestMap);
            if ("000000".equals(returnMap.get("code"))) {
                map.put("code", 10000);
                map.put("msg", "成功");
                map.put("data", returnMap.get("result"));
            } else {
                map.put("code", 10003);
                map.put("msg", "查询录音列表失败:" + returnMap.get("description"));
            }

        } catch (Exception e) {
            LogUtil.error("系统异常，请稍后重试:" + e.getMessage());
            map.put("code", 30001);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }


}