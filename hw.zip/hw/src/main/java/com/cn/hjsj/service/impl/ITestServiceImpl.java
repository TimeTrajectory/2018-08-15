package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ITestDao;
import com.cn.hjsj.pojo.Test;
import com.cn.hjsj.service.ITestService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("testService")
public class ITestServiceImpl implements ITestService {
    @Resource(name="ITestDao")
    private ITestDao iTestDao;

    public Integer insert(Test test){
        return iTestDao.insert(test);
    }

    public Integer update(Test test, Test testParmeter){
        return iTestDao.update(test,testParmeter);
    }

    public List<Test> getList(Test test){
        return iTestDao.getList(test);
    }

    public Integer getListCount(Test test){
        return iTestDao.getListCount(test);
    }

}
