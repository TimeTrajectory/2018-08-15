package com.cn.hjsj.service;

import com.cn.hjsj.pojo.ReceiveMessage;

import java.util.List;

public interface IReceiveMessageService {

    public Integer insert(ReceiveMessage receiveMessage);
    public List<ReceiveMessage> getList(ReceiveMessage receiveMessage);
    public Integer update(ReceiveMessage receiveMessage, ReceiveMessage receiveMessageParmeter);
    public Integer getListCount(ReceiveMessage receiveMessage);
}
