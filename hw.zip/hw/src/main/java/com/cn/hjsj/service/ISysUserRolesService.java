package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SysUserRoles;


import java.util.List;

public interface ISysUserRolesService {

    public Integer insert(SysUserRoles sysUserRoles);
    public Integer update(SysUserRoles sysUserRoles,SysUserRoles sysUserRolesParmeter);
    public List<SysUserRoles> getList(SysUserRoles sysUserRoles);

}
