package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.ApiDoc;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IApiDocDao")
public interface IApiDocDao {

    public Integer insert(ApiDoc apiDoc);
    public Integer update(@Param("apiDoc")ApiDoc apiDoc, @Param("apiDocParmeter")ApiDoc apiDocParmeter);
    public List<ApiDoc> getList(ApiDoc apiDoc);
    public Integer getListCount(ApiDoc apiDoc);
    public Integer delete(ApiDoc apiDoc);


}
