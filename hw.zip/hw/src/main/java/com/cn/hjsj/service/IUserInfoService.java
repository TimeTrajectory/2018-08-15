package com.cn.hjsj.service;

import com.cn.hjsj.pojo.UserInfo;
import java.util.List;

public interface IUserInfoService {

    public Integer insert(UserInfo userInfo);
    public Integer update(UserInfo userInfo,UserInfo userInfoParmeter);
    public List<UserInfo> getList(UserInfo userInfo);
    public Integer getListCount(UserInfo userInfo);

}
