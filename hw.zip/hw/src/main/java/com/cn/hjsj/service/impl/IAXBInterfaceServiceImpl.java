package com.cn.hjsj.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cn.hjsj.service.IAXBInterfaceService;
import com.cn.hjsj.util.HttpUtil;
import com.cn.hjsj.util.LogUtil;
//import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * 
 * axb模式接口测试
 * 
 * @author  jy
 * @version  [版本号, 2018-7-22]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
//@Component("IAXBInterfaceServiceImpl")
public class IAXBInterfaceServiceImpl implements IAXBInterfaceService
{
    //private Logger logger = Logger.getLogger(IAXBInterfaceService.class);//暂时不打印日志
    /**
     * AEP的appKey
     */
    private String appKey;
    /**
     * AEP的appSecret，使用AES128+BASE64（ECB）加密保存
     */
    private String appSecret;
    /**
     * AEP请求域名
     */
    private  String aepDomainName;
    /**
     *下载的文件存放的地址（服务器地址）
     */
    private static String path="http://121.46.26.224:8088/ability/download/record/";

    public IAXBInterfaceServiceImpl(String appKey, String appSecret, String aepDomainName)
    {
        this.appKey = appKey;
        this.appSecret = appSecret;
        this.aepDomainName = aepDomainName;
    }

    /**
     * 构建aep请求路径
     *
     * @param path
     * @return
     */
    private String buildAepUrl(String path)
    {
        return "http://" + aepDomainName + path;
    }

    /**
     * 交易小号AXB绑定
     */
    @Override
    public String axbBindNumber(Map<String,String> map)
    {
        LogUtil.info(" axbBindNumber Request is :" + map);
        //封装请求地址
        String url = "/axb/bindNumber/v1";
        String realUrl = buildAepUrl(url);
        
        //封装JOSN请求
        JSONObject json = new JSONObject();

        String aParty = map.get("aParty");
        String bParty = map.get("bParty");

        if(isEmpty(map,"virtualNumber")){
            //虚拟号码(选填):小号业务（AXB）场景，A和B绑定的虚拟号码
            json.put("virtualNumber", map.get("virtualNumber"));
        }
        if(isEmpty(map,"isRecord")){
            //是否录音(选填)
            json.put("isRecord", map.get("isRecord"));
        }
        if(isEmpty(map,"bindDirection")){
            //绑定描述(选填)
            json.put("bindDirection", map.get("bindDirection"));
        }
        //A方真实手机号(必填)
        json.put("aParty", aParty);
        
        //B方真实手机号(必填)
        json.put("bParty", bParty);

        //申明扩展信息json数组对象
        JSONArray extParasArr = new JSONArray();
        
        //小号平台自动分配的虚号码所属城市的区号
        if(isEmpty(map,"cityCode")){
            JSONObject cityCode = new JSONObject();
            cityCode.put("key", "cityCode");
            cityCode.put("value", map.get("cityCode"));
            extParasArr.add(cityCode);
        }

        
        //该绑定关系结束日期，UTC时间。
        if(isEmpty(map,"endTime")){
            JSONObject endTime = new JSONObject();
            endTime.put("key", "endTime");
            endTime.put("value", map.get("endTime"));
            extParasArr.add(endTime);
        }
        
        //其它扩展信息(Key-Value)列表
        json.put("extParas", extParasArr);
        
        String result = HttpUtil.sendPost(appKey, appSecret, realUrl, json.toString());
        LogUtil.info(" axbBindNumber Response is :" + result);
        return result;
    }
    
    /**
     * 交易小号AXB转绑
     */
    @Override
    public String axbModifyNumber(Map<String,String> map)
    {
        LogUtil.info(" axbUnbindNumber Request is :" + map);
        //封装请求地址
        String url = "/axb/modifyNumber/v1";
        String realUrl = buildAepUrl(url);
        
        //封装json请求
        JSONObject json = new JSONObject();

        String subscriptionId = map.get("subscriptionId");
        String bPartyNew = map.get("bPartyNew");

        //绑定关系ID(必填)
        json.put("subscriptionId", subscriptionId);
        
        //B方真实手机号(必填)
        json.put("bPartyNew", bPartyNew);
        
        String result = HttpUtil.sendPost(appKey, appSecret, realUrl, json.toString());
        LogUtil.info(" axbUnbindNumber Response is :" + result);
        return result;
    }
    
    /**
     *  交易小号AXB解绑
     */
    @Override
    public String axbUnbindNumber(Map<String,String> map)
    {
        LogUtil.info(" axbUnbindNumber Request is :" + map);
        //封装请求地址
        String url = "/axb/unbindNumber/v1";
        String realUrl = buildAepUrl(url);
        
        //封装JOSN请求
        JSONObject json = new JSONObject();

        if(isEmpty(map,"type")){
            //类型(可选)
            json.put("type", map.get("type"));
        }else{
            //不填写默认是虚拟号码
            json.put("type", "1");
        }
        //虚拟号码解绑对象(type =1时必填)
        if (json.getString("type").toString().equals("1"))
        {
            json.put("number", map.get("number"));
        }
        
        //绑定ID解绑对象(type =2时必填)
        if (json.getString("type").toString().equals("2"))
        {
            json.put("subscriptionId", map.get("subscriptionId"));
        }
        
        //申明保护信息(选填)
           JSONObject protectInfo = new JSONObject();

        if(isEmpty(map,"relationProtect")){
            //是否进入保护器
            protectInfo.put("relationProtect", map.get("relationProtect"));
        }
        if(isEmpty(map,"bindDirection")){
            //绑定描述
            protectInfo.put("bindDirection", map.get("bindDirection"));
        }else{
            protectInfo.put("bindDirection", "0");
        }
        if(isEmpty(protectInfo,"relationProtect") && protectInfo.get("relationProtect").toString().equals("1")){
            //该绑定关系结束日期，UTC时间
            protectInfo.put("endTime", map.get("endTime"));
        }
           json.put("ProtectInfo", protectInfo);
        
        String result = HttpUtil.sendPost(appKey, appSecret, realUrl, json.toString());
        LogUtil.info(" axbUnbindNumber Response is :" + result);
        return result;
    }
    
    /**
     * 查询虚号码详情
     */
    @Override
    public  String queryOrderedNumber(Map<String,String> map)
    {
        LogUtil.info(" queryOrderedNumber Request is :" + map);
        //接口请求地址
        String url = "/phonenumber/queryOrderedNumber/v1/virtualNumber/";
        String realUrl = buildAepUrl(url);
        
        //虚号码(必填)
        String virtualNumber = map.get("virtualNumber");
        
        String result = HttpUtil.sendGet(appKey, appSecret, realUrl, virtualNumber);
        LogUtil.info(" queryOrderedNumber Response is :" + result);
        return result;
    }
    
    /**
     * 查询录音列表
     */
    @Override
    public  String queryRecordList(Map<String,String> map)
    {
        LogUtil.info(" queryRecordList Request is :" + map);
        //封装请求地址
        String url = "/voice/queryRecordList/v1";
        String realUrl = buildAepUrl(url);
        
        //封装JOSN请求
        JSONObject json = new JSONObject();

        String startTime = map.get("startTime");
        String endTime = map.get("endTime");

        //查询条件的起始时间，含该时间点（UTC时间）(必填)
        json.put("startTime", startTime);
        
        //查询条件的结束时间，含该时间点（UTC时间）(必填)
        json.put("endTime", endTime);
        
        //号码绑定关系的绑定ID(可选)
        if(isEmpty(map,"subscriptionId")){
            json.put("subscriptionId", map.get("subscriptionId"));
        }

        //NGIN侧呼叫唯一标识(可选)
        if(isEmpty(map,"callIdentifier")){
            json.put("callIdentifier", map.get("callIdentifier"));
        }
        //录音列表当前页数(可选)
        if(isEmpty(map,"page")){
            json.put("page", map.get("page"));
        }
        //每个录音列表页面包含的数量
        if(isEmpty(map,"pageSize")){
            json.put("pageSize", map.get("pageSize"));
        }
        String result = HttpUtil.sendPost(appKey, appSecret, realUrl, json.toString());
        //logger.info("Response is :" + result);
        LogUtil.info(" queryRecordList Response is :" + result);
        return result;
    }
    
    /**
     * 下载录音
     */
    @Override
    public  Boolean downloadRecord(Map<String,String> map)
    {
        LogUtil.info(" downloadRecord Request is :" + map);
        //封装请求地址
        String url = "/voice/downloadRecord/v1/recordId/";
        String realUrl = buildAepUrl(url);
        
        //录音唯一标识(必填)
        String recordId = map.get("recordId");

        //把当前年月日时分秒的缩写作为录音文件的文件名
        String fielName = new SimpleDateFormat("YYYYMMddHHmmss").format(new Date());
        String urlFile = path + fielName + ".wav";

        Boolean result = HttpUtil.dowanGet(appKey, appSecret, realUrl, urlFile ,recordId);
        //logger.info("Response is :" + result);
        LogUtil.info(" downloadRecord Response is :" + result);
        return result;
    }
    
    /**
     * 删除小号平台上的录音
     */
    @Override
    public  String deleteRecord(Map<String,String> map)
    {
        LogUtil.info(" deleteRecord Request is :" + map);
        //封装请求地址
        String url = "/voice/deleteRecord/v1";
        String realUrl = buildAepUrl(url);
        
        //封装JOSN请求
        JSONObject json = new JSONObject();

        String recordId = map.get("recordId");

        //录音资源的唯一标识(必填)
        json.put("recordId", recordId);
        
        String result = HttpUtil.sendPost(appKey, appSecret, realUrl, json.toString());
        //logger.info("Response is :" + result);
        LogUtil.info(" deleteRecord Response is :" + result);
        return result;
    }
    private boolean isEmpty(Map map,String key){
        return map.containsKey(key);
    }
}
