package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SysMenu2 extends BaseBean {

    private Integer menu2Code;
    private String menu2Name;
    private String menuUrl;

    private Integer menuLevel2Code;

    public Integer getMenuLevel2Code() {
        return menuLevel2Code;
    }
    public void setMenuLevel2Code(Integer menuLevel2Code) {
        this.menuLevel2Code = menuLevel2Code;
    }

    public Integer getMenu2Code() {
        return menu2Code;
    }

    public void setMenu2Code(Integer menu2Code) {
        this.menu2Code = menu2Code;
    }

    public String getMenu2Name() {
        return menu2Name;
    }

    public void setMenu2Name(String menu2Name) {
        this.menu2Name = menu2Name;
    }

    public String getMenuUrl() {
        return menuUrl;
    }

    public void setMenuUrl(String menuUrl) {
        this.menuUrl = menuUrl;
    }
}
