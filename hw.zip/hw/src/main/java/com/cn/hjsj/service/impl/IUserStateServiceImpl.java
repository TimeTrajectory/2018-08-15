package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IUserStateDao;
import com.cn.hjsj.pojo.UserState;
import com.cn.hjsj.service.IUserStateService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("userStateService")
public class IUserStateServiceImpl implements IUserStateService {

    @Resource(name="IUserStateDao")
    private IUserStateDao iUserStateDao;

    public Integer insert(UserState userState){
        return iUserStateDao.insert(userState);
    }
    public Integer update(UserState userState,UserState userStateParmeter){
        return iUserStateDao.update(userState,userStateParmeter);
    }
    public List<UserState> getList(UserState userState){
        return iUserStateDao.getList(userState);
    }
    public Integer getListCount(UserState userState){
        return iUserStateDao.getListCount(userState);
    }


}
