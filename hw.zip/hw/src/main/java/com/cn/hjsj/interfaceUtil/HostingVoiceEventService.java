package com.cn.hjsj.interfaceUtil;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.pojo.ReceiveMessage;
import com.cn.hjsj.service.IConversationService;
import com.cn.hjsj.service.IReceiveMessageService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author jiazh
 *
 * 小号事件通知
 * 客户平台收到华为小号平台的呼叫事件或短信事件的接口通知
 */
@Controller
@RequestMapping(HostingVoiceEventService.Location)
public class HostingVoiceEventService {
    @Autowired
    private IReceiveMessageService iReceiveMessageService;

    @Autowired
    private IConversationService iConversationService;

    /**
     * Location
     * 小号平台访问的地址
     */
    public static final String Location = "/interface_hostingVoice";
    /**
     * AEP的appKey
     * 请联系华为运营经理申请应用KEY
     */
    private final static String AEPAPPKEY = "02c94f7a47cb471a8bcc339d3f7b4333";

    private static Logger logger = Logger.getLogger(HostingVoiceEventService.class);

    /**
     * 短信通知
     *
     * @param jsonBody 小号平台推送到客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    @ResponseBody
    @RequestMapping(value = "/onSmsEvent", method = RequestMethod.POST)
    @Permission("login")//验证通过标识
    public void onSmsEvent(@RequestBody String jsonBody) {

        //System.out.println(jsonBody);

        try{
        JSONObject json = JSON.parseObject(jsonBody);
        JSONObject res = new JSONObject();
        int result = 0;

        //小号业务平台分配给商户应用的AppKey(必填)
        String appKey = json.getString("appKey");
        if (!appKey.equals(AEPAPPKEY)) {
            logger.error("This is key error :" + appKey);
            res.put("code", "E000611");
            res.put("msg", "无效的AppKey");
            return;
        }
        //短信状态事件
        JSONObject smsEvent = json.getJSONObject("smsEvent");
        ReceiveMessage receiveMessage = new ReceiveMessage();

        //短信唯一标识
        String smsIdentifier = smsEvent.getString("smsIdentifier");
        receiveMessage.setSmsIdentifier(smsIdentifier);

        //真实主叫号码
        if (isEmpty(smsEvent, "calling")) {
            String calling = smsEvent.getString("calling");
            receiveMessage.setCalling(calling);
        }

        //真实被叫号码
        if (isEmpty(smsEvent, "called")) {
            String called = smsEvent.getString("called");
            receiveMessage.setCalled(called);
        }

        //虚拟号码
        if (isEmpty(smsEvent, "virtualNumber")) {
            String virtualNumber = smsEvent.getString("virtualNumber");
            receiveMessage.setVirtualNumber(virtualNumber);
        }
        //短信状态事件
        String event = smsEvent.getString("event");
        receiveMessage.setEvent(event);

        //呼叫事件发生的时间戳，UTC时间
        String timeStamp = smsEvent.getString("timeStamp");
        receiveMessage.setTimeStamp(getDate(timeStamp));

        // 通知模式
        String notificationMode = smsEvent.getString("notificationMode");
        receiveMessage.setNotificationMode(notificationMode);

        // 如果是Block模式，则要按接口文档进行回复响应
        if ("Block".equalsIgnoreCase(notificationMode)) {
            JSONObject resp = new JSONObject();
            JSONArray actions = new JSONArray();

            JSONObject action = new JSONObject();
            // 操作类型： NumberRoute-小号平台转发短信; DiscardMessage-小号平台不转发短信，将短信丢弃。
            action.put("operation", "vNumberRoute");
            actions.add(action);

            resp.put("actions", actions);
        }
        //数据的持久化
        result = iReceiveMessageService.insert(receiveMessage);
        if (result <= 0) {
            logger.error("短信通知接收失败");
            }
        }catch (Exception e){
            //e.printStackTrace();
            logger.error("短信通知接口出现异常，异常信息为："+e.getMessage());
        }
    }

    /**
     * 呼叫通知
     *
     * @param jsonBody 小号平台推送客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    @ResponseBody
    @RequestMapping(value = "/onCallEvent", method = RequestMethod.POST)
    @Permission("login")//验证通过标识
    public void onCallEvent(@RequestBody String jsonBody) {

        try {
            //封装JOSN请求
            JSONObject json = JSON.parseObject(jsonBody);
            int result = 0;

            JSONObject res = new JSONObject();
            //小号业务平台分配给商户应用的AppKey(验证)
            String appKey = json.getString("appKey");
            if (!appKey.equals(AEPAPPKEY)) {
                res.put("code", "E000611");
                res.put("msg", "无效的AppKey");
                logger.error("This is key error :" + res);
                return;
            }
            //获取呼叫状态事件对象
            JSONObject ceit = json.getJSONObject("callEvent");
            Conversation conversation = new Conversation();

            //呼叫唯一标识
            String callIdentifier = ceit.getString("callIdentifier");
            conversation.setCallIdentifier(callIdentifier);

            //通知模式
            //取值：Notify-商户不对呼叫进行控制， Block-商户可以指示小号业务平台做呼叫控制
            //注：推送消息中通知模式是Block模式，则商户需要给AEP响应，否则商户不回响应或者超时响应，则小号平台根据配置来放回铃音，然后释放呼叫。
            String notificationMode = ceit.getString("notificationMode");
            conversation.setNotificationMode(notificationMode);

            //真实主叫号码（参数校验）
            if (isEmpty(ceit, "calling")) {
                String calling = ceit.getString("calling");
                conversation.setCalling(calling);
            }
            //真实被叫号码
            //格式：国家码+手机号  示例：8613800000000
            if (isEmpty(ceit, "called")) {
                String called = ceit.getString("called");
                conversation.setCalled(called);
            }
            //虚拟号码
            //格式：国家码+手机号  示例：8613800000000
            if (isEmpty(ceit, "virtualNumber")) {
                String virtualNumber = ceit.getString("virtualNumber");
                conversation.setVirtualNumber(virtualNumber);
            }
            //呼叫状态事件
            //取值：IDP-呼叫开始, Answer-应答 , Release-释放, Exception-呼叫过程中发生的异常
            //注：个人小号AX模式支持上述所有事件。交易小号AXB模式，不支持Answer事件，并且IDP事件只有在请求是否录音时才会触发
            String event = ceit.getString("event");
            conversation.setEvent(event);

            //呼叫事件发生的时间戳
            //格式：YYYY-MM-DDThh:mm:ss.SSSZ  示例：2013-10-09T08:33:07.789Z
            //注：1.SSS表示毫秒，注意固定字符“T”、“Z”
            String timestamp = ceit.getString("timeStamp");
            conversation.setTimestamp(getDate(timestamp));

            //是否录音
            //注：1.只有在notify情况下的release事件，exception事件和answer事件推送isRecord字段
            if (notificationMode.equals("Notify")) {
                // 取值：1-录音    0-不录音
                String isRecord = ceit.getString("isRecord");
                if (isRecord.equals("1")) {
                    conversation.setIsDow("N");
                } else {
                    conversation.setIsDow("Y");
                }
            }

            //扩展呼叫事件信息对象
            JSONObject extInfo = ceit.getJSONObject("extInfo");

            //信令中的主叫号码
            //注：1.未进行号码规整，号码格式有可能不符合国际电信联盟定义的E.164标准
            if (isEmpty(extInfo, "rawCalling")) {
                String rawCalling = extInfo.getString("rawCalling");
                conversation.setRawCalling(rawCalling);
            }
            //信令中主叫号码的号码属性
            //取值：SUBSCRIBER, UNKNOWN, INTERNATIONAL, 其他
            if (isEmpty(extInfo, "rawCallingNOA")) {
                String rawCallingNOA = extInfo.getString("rawCallingNOA");
                conversation.setRawCallingNOA(rawCallingNOA);
            }
            //信令中的被叫号码
            if (isEmpty(extInfo, "rawCalled")) {
                String rawCalled = extInfo.getString("rawCalled");
                conversation.setRawCalled(rawCalled);
            }
            //信令中被叫号码的号码属性
            if (isEmpty(extInfo, "rawCalledNOA")) {
                String rawCalledNOA = extInfo.getString("rawCalledNOA");
                conversation.setRawCalledNOA(rawCalledNOA);
            }
            //获取扩展信息(Key-Value)列表
            JSONArray extParas = extInfo.getJSONArray("extParas");

            //注：当呼叫状态事件时Exception，扩展信息包含信息如下
            if (event.equals("Exception")) {
                for (int i = 0; i < extParas.size(); i++) {
                    JSONObject temp = extParas.getJSONObject(i);
                    String key = temp.getString("key");
                    String value = temp.getString("value");

                    //注:用于AXB场景
                    //标识消息的唯一ID
                    if ("UniqueId".equalsIgnoreCase(key)) {
                        String uniqueId = value;
                        conversation.setUniqueId(uniqueId);
                    }

                    //通话时长,单位：秒
                    if ("Duration".equalsIgnoreCase(key)) {
                        String duration = value;
                        conversation.setDuration(Integer.parseInt(duration));
                    }

                    //绑定关系ID
                    //注:用于AXB场景
                    if ("BindID".equalsIgnoreCase(key)) {
                        String bindID = value;
                        conversation.setBindID(bindID);
                    }

                    //呼叫开始的时间戳
                    //注:用于AXB场景
                    if ("StartTime".equalsIgnoreCase(key)) {
                        String startTime = value;
                        conversation.setStartTime(getDate(startTime));
                    }
                }
            }

            //注：当呼叫状态事件时Release，扩展信息包含信息如下
            if (event.equals("Release")) {
                //呼叫结束原因
                for (int i = 0; i < extParas.size(); i++) {
                    JSONObject temp = extParas.getJSONObject(i);
                    String key = temp.getString("key");
                    String value = temp.getString("value");
                    //标识消息的唯一ID
                    //注:用于AXB场景
                    if ("ReleaseReason".equalsIgnoreCase(key)) {
                        String releaseReason = value;
                        conversation.setReleaseReason(releaseReason);
                    }

                    //标识消息的唯一ID
                    //注:用于AXB场景
                    if ("UniqueId".equalsIgnoreCase(key)) {
                        String uniqueId = value;
                        conversation.setUniqueId(uniqueId);
                    }

                    //绑定关系ID
                    //注:用于AXB场景
                    if ("BindID".equalsIgnoreCase(key)) {
                        String bindID = value;
                        conversation.setBindID(bindID);
                    }

                    //呼叫开始的时间戳
                    //注:用于AXB场景
                    if ("StartTime".equalsIgnoreCase(key)) {
                        String startTime = value;
                        conversation.setStartTime(getDate(startTime));
                    }

                    //通话时长，单位为秒
                    if ("Duration".equalsIgnoreCase(key)) {
                        String duration = value;
                        conversation.setDuration(Integer.parseInt(duration));
                    }
                }
            }
            //验证完毕，数据的持久化操作
            result = iConversationService.insert(conversation);
            if (result <= 0) {
                logger.error("呼叫通知接收失败");
            }
        }catch (Exception e){
            //e.printStackTrace();
            logger.error("呼叫通知出现了异常，异常信息为："+e.getMessage());
        }
    }

    public boolean isEmpty(JSONObject json, String key) {
        return json.containsKey(key);
    }

    /**
     * 日期转换
     * @param sourceTime
     * @return
     */
    private static String getDate(String sourceTime){

            Date resDate = null;
            String time = "";
            try {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");//注意格式化的表达式
                sourceTime = sourceTime.replace("Z", " UTC");//注意是空格+UTC
                resDate = format.parse( sourceTime );
                time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(resDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return time;
        }
}
