package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.Test;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ITestDao")
public interface ITestDao {

	public Integer insert(Test test);
	public Integer update(@Param("test")Test test, @Param("testParmeter")Test testParmeter);
	public List<Test> getList(Test test);
	public Integer getListCount(Test test);

}
