package com.cn.hjsj.service;

import java.util.Map;

/**
 * axb模式接口
 * 
 * @author  jy
 * @version  [版本号, 2018-7-22]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public interface IAXBInterfaceService
{
    /**
     * 交易小号AXB绑定
     */
    String axbBindNumber(Map<String,String> map);

    /**
     * 交易小号AXB转绑
     */
    String axbModifyNumber(Map<String,String> map);

    /**
     *  交易小号AXB解绑
     */
    String axbUnbindNumber(Map<String,String> map);

    /**
     * 查询虚号码详情
     */
    String queryOrderedNumber(Map<String,String> map);

    /**
     * 查询录音列表
     */
    String queryRecordList(Map<String,String> map);

    /**
     * 下载录音
     */
    Boolean downloadRecord(Map<String,String> map);

    /**
     * 删除小号平台上的录音
     */
    String deleteRecord(Map<String,String> map);
}
