package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.SysMenu2;
import com.cn.hjsj.pojo.SysRolesMenu2;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISysMenu2Dao")
public interface ISysMenu2Dao {

    public List<SysMenu2> getList(SysMenu2 sysMenu2);
    public Integer update(@Param("sysMenu2") SysMenu2 sysMenu2, @Param("sysMenu2Parmeter") SysMenu2 sysMenu2Parmeter);
    public Integer insert(SysMenu2 sysMenu2);
    public Integer delete(SysMenu2 sysMenu2);


}
