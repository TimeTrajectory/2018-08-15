package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.SoundRecording;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISoundRecordingDao")
public interface ISoundRecordingDao {

    public Integer insert(SoundRecording soundrecording);
    public Integer update(@Param("soundrecording") SoundRecording soundrecording, @Param("soundrecordingParmeter") SoundRecording soundrecordingParmeter);
    public List<SoundRecording> getList(SoundRecording soundrecording);
    public Integer getListCount(SoundRecording soundrecording);

}
