package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.*;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.ISysUserRolesService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sysUserRolesService")
public class ISysUserRolesServiceImpl implements ISysUserRolesService {

    @Resource(name="ISysUserRolesDao")
    private ISysUserRolesDao iSysUserRolesDao;

    public Integer insert(SysUserRoles sysUserRoles){
        return  iSysUserRolesDao.insert(sysUserRoles);
    }
    public Integer update(SysUserRoles sysUserRoles,SysUserRoles sysUserRolesParmeter){
        return  iSysUserRolesDao.update(sysUserRoles,sysUserRolesParmeter);
    }
    public List<SysUserRoles> getList(SysUserRoles sysUserRoles){
        return iSysUserRolesDao.getList(sysUserRoles);
    }

}
