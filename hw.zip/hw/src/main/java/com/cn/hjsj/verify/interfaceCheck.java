package com.cn.hjsj.verify;

import com.cn.hjsj.base.cache.UserCache;
import com.cn.hjsj.util.Md5Util;
import net.sf.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class interfaceCheck {
    //判断jsonstring
    public static Map checkJson(String jsonstring, HttpServletRequest request) {
        Map<String, Object> map = new HashMap<String, Object>();
        String password = "";
        String key = "";

        //校验报文字段
        interfaceCheck ic = new interfaceCheck();
        map = ic.NonEmpty_jsonstring(jsonstring);

        if(Integer.parseInt(map.get("code").toString()) != 10000){
            return map;
        }

        //校验头部信息
        String username = request.getHeader("username");
        String pas = request.getHeader("password");

        boolean flag = UserCache.JudgeUser(username);
        if(flag){
            Map tempMap = (Map)UserCache.get(username);
            password = tempMap.get("password").toString();
            key = tempMap.get("key").toString();

//            System.out.println("password：" + password);
//            System.out.println("key：" + key);

            if(!pas.equals(password)){
                map.put("code", 21001);
                map.put("msg", "用户密码错误");
                return map;
            }
        }else{
            map.put("code", 21002);
            map.put("msg", "用户不存在");
            return map;
        }

        //校验签名
        JSONObject object = JSONObject.fromObject(jsonstring);
        String apiCode = object.get("apiCode").toString();
        String machine = object.get("machine").toString();
        String parameter = object.get("parameter").toString();
        String sign = object.get("sign").toString();

        String md5Sign = Md5Util.GetMD5Code(username + Md5Util.GetMD5Code(apiCode + parameter + machine) + key);
        System.out.println("正确签名：" + md5Sign);
        System.out.println("传入签名：" + sign);
        if (!sign.equals(md5Sign)) {
            map.put("code", 20000);
            map.put("msg", "签名错误");
            return map;
        }

        //校验是否有调用接口的权限
        boolean flag2 = false;
        Map tempMap2 = (Map)UserCache.get(username);
        Integer a[] = (Integer[])tempMap2.get("apiCodePower");

        if(a.length == 0){
            map.put("code", 30000);
            map.put("msg", "无权限访问本接口或接口不存在");
            return map;
        }

        for(int j=0; j<a.length; j++){
            if(a[j] == Integer.parseInt(apiCode)){
                flag2 = true;
                break;
            }
        }

        if(flag2){
            map.put("user",username);
            map.put("apiCode",apiCode);
            map.put("code", 10000);
            map.put("msg", "json初步校验通过");
        }else{
            map.put("code", 30000);
            map.put("msg", "无权限访问本接口或接口不存在");
        }

        return map;
    }


    public Map NonEmpty_jsonstring(String jsonstring) {
        Map<String, Object> map = new HashMap<String, Object>();
        JSONObject object;

        if ("".equals(jsonstring) || jsonstring == null) {
            map.put("code", 30000);
            map.put("msg", "无请求数据");
            return map;
        }

        try {
            object = JSONObject.fromObject(jsonstring);
        } catch (Exception ex) {
            map.put("code", 20001);
            map.put("msg", "json格式错误");
            return map;
        }

        if (!object.containsKey("apiCode")) {
            map.put("code", 20002);
            map.put("msg", "缺少apiCode参数");
            return map;
        }
        if (!object.containsKey("machine")) {
            map.put("code", 20003);
            map.put("msg", "缺少machine参数");
            return map;
        }
        if (!object.containsKey("parameter")) {
            map.put("code", 20004);
            map.put("msg", "缺少parameter参数");
            return map;
        }
        if (!object.containsKey("sign")) {
            map.put("code", 20005);
            map.put("msg", "缺少sign参数");
            return map;
        }

        map.put("code", 10000);
        map.put("msg", "json初步校验通过");

        return map;
    }

    public static boolean checkParameter(Map maps, ArrayList<String> arrayList) {
        boolean flag = false;

        for (String s : arrayList) {
            if (maps.containsKey(s) && (maps.get(s) != null && !"".equals(maps.get(s)))) {
                flag = true;
            } else {
                flag = false;
                break;
            }
        }
        if(arrayList.size()==0){
            flag = true;
        }

        return flag;
    }

}
