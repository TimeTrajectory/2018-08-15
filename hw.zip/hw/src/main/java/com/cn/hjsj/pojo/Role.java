package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class Role extends BaseBean {
    private String roleName;
    private String specification;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }
}
