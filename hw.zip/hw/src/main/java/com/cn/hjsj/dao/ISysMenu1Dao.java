package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.SysMenu1;
import com.cn.hjsj.pojo.SysMenu2;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISysMenu1Dao")
public interface ISysMenu1Dao {

    public List<SysMenu1> getList(SysMenu1 sysMenu1);
    public Integer update(@Param("sysMenu1") SysMenu1 sysMenu1, @Param("sysMenu1Parmeter") SysMenu1 sysMenu1Parmeter);
    public Integer insert(SysMenu1 sysMenu1);
    public Integer delete(SysMenu1 sysMenu1);


}
