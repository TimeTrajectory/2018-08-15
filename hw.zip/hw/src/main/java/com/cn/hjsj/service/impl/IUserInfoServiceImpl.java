package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IUserInfoDao;
import com.cn.hjsj.pojo.UserInfo;
import com.cn.hjsj.service.IUserInfoService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("userInfoService")
public class IUserInfoServiceImpl implements IUserInfoService {
    @Resource(name="IUserInfoDao")
    private IUserInfoDao iUserInfoDao;

    public Integer insert(UserInfo userInfo){
        return iUserInfoDao.insert(userInfo);
    }
    public Integer update(UserInfo userInfo,UserInfo userInfoParmeter){
        return iUserInfoDao.update(userInfo,userInfoParmeter);
    }
    public List<UserInfo> getList(UserInfo userInfo){
        return iUserInfoDao.getList(userInfo);
    }
    public Integer getListCount(UserInfo userInfo) {
        return iUserInfoDao.getListCount(userInfo);
    }
}
