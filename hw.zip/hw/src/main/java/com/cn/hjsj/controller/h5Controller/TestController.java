package com.cn.hjsj.controller.h5Controller;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.Test;
import com.cn.hjsj.service.ITestService;
import com.cn.hjsj.util.LogUtil;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.*;

@Controller
@RequestMapping("/testController")
public class TestController {
    @Resource(name="testService")
    private ITestService testService;


    @ResponseBody
    @RequestMapping("/test_insert")
    @Permission("login")
    public Object insert(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{
            //公共方法校验


            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);

            Test test = new Test();
            test.setT1(object.get("t1").toString());
            test.setT2(Integer.parseInt(object.get("t2").toString()));
            test.setT3(Double.parseDouble(object.get("t3").toString()));
            test.setCreateBy("ttt");
            test.setUpdateBy("ttt2");

            Integer i = testService.insert(test);
            System.out.println(i);

            if(i==1){
                map.put("code",10000);
                map.put("msg","插入成功");
            }else{
                map.put("code",20001);
                map.put("msg","插入失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

    @ResponseBody
    @RequestMapping("/test_update")
    @Permission("login")
    public Object update(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{
            //公共方法校验


            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);

            Test test = new Test();
            Test test2 = new Test();

            test.setId(Integer.parseInt(object.get("id").toString()));

            test2.setT2(Integer.parseInt(object.get("t2").toString()));
            test2.setCreateBy("ujn");

            testService.update(test2,test);

            map.put("code",10000);
            map.put("msg","修改成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }


    @ResponseBody
    @RequestMapping("/test_getList")
    @Permission("login")
    public Object getList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{
            //公共方法校验


            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            Integer id = Integer.parseInt(object.get("id").toString());

            Test test = new Test();
            test.setId(id);
            List<Test> list = testService.getList(test);

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("list",list);

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

    @ResponseBody
    @RequestMapping("/test_getListCount")
    @Permission("login")
    public Object getListCount(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{
            //公共方法校验
            /*----------校验示例  begin----------*/
            //将接口必输字段放入arraylist，
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("test");

             /*h5接口签名校验
            ** 成功报文：{"identifier":"admin","timeStamp":"2018-05-14 16:00:00","sign":"922CD80702C7E620DF3A43CEC251F393","parameter":{"test":"1"}}
            */
//            map = h5Check.checkJson(jsonstring, arraylist);

            /*web接口签名校验
            ** 测试报文：{"token":"ABCDE","machine":"test123","sign":"A7FAE9C3F8D3C831C84B81C315B54326","parameter":{"test":"1"}}
            */
//            map = webCheck.checkJson(jsonstring, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            /*----------校验示例  end----------*/


            //业务逻辑
            Test test = new Test();
            Integer i = testService.getListCount(test);

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("count",i);

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }


}

