package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

import java.util.Date;

public class Conversation extends BaseBean {

    private String callIdentifier;
    private String calling;
    private String called;
    private String virtualNumber;
    private String event;
    private String timestamp;
    private String rawCalling;
    private String rawCallingNOA;
    private String rawCalled;
    private String rawCalledNOA;
    private String releaseReason;
    private String uniqueId;
    private String bindID;
    private String StartTime;
    private Integer duration;
    private String notificationMode;
    private String isDow;
    private String startDate;
    private String endDate;
    private String startDateTwo;
    private String endDateTwo;

    public String getStartDateTwo() {
        return startDateTwo;
    }

    public void setStartDateTwo(String startDateTwo) {
        this.startDateTwo = startDateTwo;
    }

    public String getEndDateTwo() {
        return endDateTwo;
    }

    public void setEndDateTwo(String endDateTwo) {
        this.endDateTwo = endDateTwo;
    }

    public String getCallIdentifier() {
        return callIdentifier;
    }

    public void setCallIdentifier(String callIdentifier) {
        this.callIdentifier = callIdentifier;
    }

    public String getCalling() {
        return calling;
    }

    public void setCalling(String calling) {
        this.calling = calling;
    }

    public String getCalled() {
        return called;
    }

    public void setCalled(String called) {
        this.called = called;
    }

    public String getVirtualNumber() {
        return virtualNumber;
    }

    public void setVirtualNumber(String virtualNumber) {
        this.virtualNumber = virtualNumber;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getRawCalling() {
        return rawCalling;
    }

    public void setRawCalling(String rawCalling) {
        this.rawCalling = rawCalling;
    }

    public String getRawCallingNOA() {
        return rawCallingNOA;
    }

    public void setRawCallingNOA(String rawCallingNOA) {
        this.rawCallingNOA = rawCallingNOA;
    }

    public String getRawCalled() {
        return rawCalled;
    }

    public void setRawCalled(String rawCalled) {
        this.rawCalled = rawCalled;
    }

    public String getRawCalledNOA() {
        return rawCalledNOA;
    }

    public void setRawCalledNOA(String rawCalledNOA) {
        this.rawCalledNOA = rawCalledNOA;
    }

    public String getReleaseReason() {
        return releaseReason;
    }

    public void setReleaseReason(String releaseReason) {
        this.releaseReason = releaseReason;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getBindID() {
        return bindID;
    }

    public void setBindID(String bindID) {
        this.bindID = bindID;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getNotificationMode() {
        return notificationMode;
    }

    public void setNotificationMode(String notificationMode) {
        this.notificationMode = notificationMode;
    }

    public String getIsDow() {
        return isDow;
    }

    public void setIsDow(String isDow) {
        this.isDow = isDow;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setStartTime(String startTime) {
        StartTime = startTime;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {

        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
