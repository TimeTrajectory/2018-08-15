package com.cn.hjsj.retime;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cn.hjsj.interfaceUtil.InterfaceImpl.AXBInterfaceUtil;
import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.pojo.SoundRecording;
import com.cn.hjsj.service.IConversationService;
import com.cn.hjsj.service.ISoundRecordingService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jiazh
 *
 * 定时器下载录音文件
 */
@Component
public class TimeDownloadRecord {

    @Autowired
    private AXBInterfaceUtil axbInterfaceUtil;

    @Autowired
    private IConversationService iConversationService;

    @Autowired
    private ISoundRecordingService iSoundRecordingService;

    private static Logger logger = Logger.getLogger(TimeDownloadRecord.class);

    /**
     * 定时下载录音文件
     */
    @Scheduled(cron = "0 0 */4 * * ?")
    //@Scheduled(fixedRate = 1000*60*3)
    public void dowLoad(){
        Logger logger = Logger.getLogger(TimeDownloadRecord.class);

        System.out.println("现在开始启动定时器当前时间为："+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        //批量获取话单记录
        Conversation conversation = new Conversation();
        conversation.setIsDow("N");
        List<Conversation> converList = iConversationService.getList(conversation);
        //System.out.println(converList.size()+"------------>");

        //数据校验
        if(converList==null || converList.size()<1){
            //没有下载的录音
            return;
        }
        if(!isHttps()){
            //当前网络不通顺
            return;
        }
        for(int i = 0;i<converList.size();i++) {
            Boolean flag = false;

            Map<String, String> map = new HashMap<String, String>();
            Map<String, String> recordIdList = new HashMap<String, String>();

            String staetTime = converList.get(i).getTimestamp() + "";

            map.put("callIdentifier", converList.get(i).getCallIdentifier());
            map.put("startTime", TimeDownloadRecord.getDate(staetTime,"YYYY-MM-dd HH:mm:ss","YYYY-MM-DD'T'hh:mm:ss'Z'"));
            map.put("endTime", new SimpleDateFormat("YYYY-MM-DD'T'hh:mm:ss'Z'").format(new Date()));
            Map<String, Object> mapRecordList = axbInterfaceUtil.queryRecordList(map);
            //录音文件不存在
            if (mapRecordList.get("code").equals("E000612")) {
                logger.info("录音文件列表为空：timeDownloadRecord class Appear :---->" + mapRecordList.get("description"));
                continue;
            }
            if (mapRecordList.get("code").equals("000000")) {
                JSONObject jsonResult = (JSONObject) mapRecordList.get("result");

                JSONArray jsonRecord = (JSONArray) jsonResult.get("record");
                for (int j = 0; j < jsonRecord.size(); j++) {
                    JSONObject obj = (JSONObject) jsonRecord.get(j);
                    String recordId = obj.get("recordId").toString();
                    String time = obj.get("createTime").toString();
                    String createTime = TimeDownloadRecord.getDate(time,"YYYY-MM-DD'T'hh:mm:ss'Z'","YYYY-MM-dd HH:mm:ss");

                    recordIdList.put("recordId", recordId);
                    flag = axbInterfaceUtil.downloadRecord(recordIdList);
                    //这里单线程下载录音文件
                    if(flag){
                        //数据的持久化
                        SoundRecording recording = new SoundRecording();
                        recording.setRecordId(recordId);
                        recording.setCallIdentifier(converList.get(i).getCallIdentifier());
                        recording.setCalling(converList.get(i).getCalling());
                        recording.setCalled(converList.get(i).getCalled());
                        recording.setBindID(converList.get(i).getBindID());
                        recording.setDuration(converList.get(i).getDuration()+"");
                        recording.setCreateTime(createTime);
                        recording.setRecordUrl("https://ecommprotect.huaweiapi.com/voice/downloadRecord/v1/recordId/"+recordId);
                        recording.setCreateBy("admin");//这是创建者，由于字段不能为空,
                        recording.setUpdateBy("admin");//这是更新者，由于字段不能为空

                        int sun = iSoundRecordingService.insert(recording);
                        if(sun>0){
                            //录音资源下载成功，修改话单下载记录
                            Conversation conversationParmeter = new Conversation();
                            conversation.setIsDow("Y");
                            iConversationService.update(converList.get(i),conversationParmeter);
                        }
                    }
                }
            }else{
                //获取录音列表错误
                String code = (String) mapRecordList.get("code");
                String success =  (String) mapRecordList.get("success");
                String description = (String) mapRecordList.get("description");
                logger.error("获取录音列表错误:code="+code+",success="+success+",description="+description);
            }
        }
        System.out.println("现在结束启动定时器当前时间为："+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
    }
    /**
     * 测试网络状态
      */
    private static boolean isHttps() {
        URL url = null;
        try {
            url = new URL("https://www.baidu.com/");
            InputStream in = url.openStream();// 打开到此 URL 的连接并返回一个用于从该连接读入的
            in.close();// 关闭此输入流并释放与该流关联的所有系统资源。
        } catch (IOException e) {
            logger.error("网络错误:",e);
            return false;
        }
        return true;
    }

    /**
     * 日期转换
     * @param timeDate
     * @param InFmt
     * @param OutFmt
     * @return
     */
    private static String getDate(String timeDate,String InFmt,String OutFmt){

        String dateFmt = "";
        SimpleDateFormat format = new SimpleDateFormat(InFmt, Locale.ENGLISH);
        SimpleDateFormat dateFormat = new SimpleDateFormat(OutFmt);
        Date date = null;
        try {
            date = format.parse(timeDate);
            dateFmt = dateFormat.format(date);
        } catch (ParseException e) {
            logger.error("日期转换错误:",e);
        }
        return dateFmt;
    }
}
