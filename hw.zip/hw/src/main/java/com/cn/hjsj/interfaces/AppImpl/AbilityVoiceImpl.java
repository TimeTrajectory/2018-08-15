/**
 * FileName: AbilityVoiceImpl
 * Author:   duzenjie
 * Date:     2018/7/22 10:43
 */
package com.cn.hjsj.interfaces.AppImpl;


import java.util.Map;

public interface AbilityVoiceImpl {
    public Map getList(Map maps);
}
