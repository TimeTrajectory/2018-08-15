package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SysRolesMenu2 extends BaseBean {
    private Integer roleId;
    private Integer menu2Code;
    private Integer menu1Code;
    private Integer menuLevel2Code;


    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getMenu2Code() {
        return menu2Code;
    }

    public void setMenu2Code(Integer menu2Code) {
        this.menu2Code = menu2Code;
    }

    public Integer getMenu1Code() {
        return menu1Code;
    }

    public void setMenu1Code(Integer menu1Code) {
        this.menu1Code = menu1Code;
    }

    public Integer getMenuLevel2Code() {
        return menuLevel2Code;
    }

    public void setMenuLevel2Code(Integer menuLevel2Code) {
        this.menuLevel2Code = menuLevel2Code;
    }
}
