package com.cn.hjsj.interfaces.AppImpl;

import java.util.Map;


public interface AbilityTestImpl {

    public Map test(Map maps);

}
