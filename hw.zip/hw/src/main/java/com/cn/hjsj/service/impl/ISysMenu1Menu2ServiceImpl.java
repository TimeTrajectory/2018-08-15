package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ISessionTokenDao;
import com.cn.hjsj.dao.ISysMenu1Menu2Dao;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.ISysMenu1Menu2Service;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sysMenu1Menu2Service")
public class ISysMenu1Menu2ServiceImpl implements ISysMenu1Menu2Service {
    @Resource(name="ISysMenu1Menu2Dao")
    private ISysMenu1Menu2Dao iSysMenu1Menu2Dao;

    public List<SysMenu1Menu2> getList(SysMenu1Menu2 sysMenu1Menu2){
        return iSysMenu1Menu2Dao.getList(sysMenu1Menu2);
    }
    public Integer update(SysMenu1Menu2 sysMenu1Menu2, SysMenu1Menu2 sysMenu1Menu2Parmeter){
        return iSysMenu1Menu2Dao.update(sysMenu1Menu2,sysMenu1Menu2Parmeter);
    }
    public Integer insert(SysMenu1Menu2 sysMenu1Menu2){
        return  iSysMenu1Menu2Dao.insert(sysMenu1Menu2);
    }
    public Integer delete(SysMenu1Menu2 sysMenu1Menu2){
        return iSysMenu1Menu2Dao.delete(sysMenu1Menu2);
    }

}
