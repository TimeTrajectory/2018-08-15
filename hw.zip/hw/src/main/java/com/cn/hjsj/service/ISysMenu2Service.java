package com.cn.hjsj.service;

import com.cn.hjsj.pojo.*;

import java.util.List;

public interface ISysMenu2Service {

    public List<SysMenu2> getList(SysMenu2 sysMenu2);
    public Integer update(SysMenu2 sysMenu2,SysMenu2 sysMenu2Parmeter);
    public Integer insert(SysMenu2 sysMenu2);
    public Integer delete(SysMenu2 sysMenu2);

}
