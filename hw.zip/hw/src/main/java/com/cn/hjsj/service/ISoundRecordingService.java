package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SoundRecording;

import java.util.List;

public interface ISoundRecordingService {

    public Integer insert(SoundRecording soundRecording);
    public Integer update(SoundRecording soundRecording, SoundRecording soundRecordingParmeter);
    public List<SoundRecording> getList(SoundRecording soundRecording);
    public Integer getListCount(SoundRecording soundRecording);

}
