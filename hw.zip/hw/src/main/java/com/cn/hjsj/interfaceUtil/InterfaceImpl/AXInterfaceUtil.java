package com.cn.hjsj.interfaceUtil.InterfaceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.hjsj.interfaceUtil.AXInterface;
import com.cn.hjsj.service.IAXInterfaceService;
import com.cn.hjsj.service.impl.IAXInterfaceServiceImpl;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component("AXInterfaceUtil")
public class AXInterfaceUtil implements AXInterface{

    private IAXInterfaceService iaxInterfaceService;
    /**
     * AEP的appKey
     * 请联系华为运营经理申请应用KEY
     */
    private final static String AEPAPPKEY = "02c94f7a47cb471a8bcc339d3f7b4333";

    /**
     * AEP的appSecret，使用AES128+BASE64（ECB）加密保存
     */
    private final static String AEPAPPSECRET = "60df2e4c0d2448f6bc6e3683d42298f7";
    /**
     *AEP的域名
     */
    private  final  static String AEPDOMAINNAME = "ecommprotect.huaweiapi.com";

    {
        //构造代码块处理实例
        iaxInterfaceService = new IAXInterfaceServiceImpl(AEPAPPKEY, AEPAPPSECRET,AEPDOMAINNAME);
    }

    protected AXInterfaceUtil(){
        //iaxInterfaceService = new IAXInterfaceServiceImpl(AEPAPPKEY, AEPAPPSECRET,AEPDOMAINNAME);
    }
    /**
     * 个人小号AX绑定
     */
    @Override
    public Map<String,Object> axBindNumber(Map<String,String> map){
        String result = iaxInterfaceService.axBindNumber(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }
    /**
     * 个人小号AX解绑
     */
    @Override
    public Map<String,Object> axUnbindNumber(Map<String,String> map){
        String result = iaxInterfaceService.axUnbindNumber(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }
    /**
     * 个人小号AX逻辑开关机
     */
    @Override
    public Map<String,Object> axSetLogicPowerStatus(Map<String,String> map){
        String result = iaxInterfaceService.axSetLogicPowerStatus(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }
    /**
     * 查询虚号码详情
     */
    @Override
    public Map<String,Object> queryOrderedNumber(Map<String,String> map){
        String result = iaxInterfaceService.queryOrderedNumber(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }
    /**
     * 查询录音列表
     */
    @Override
    public Map<String,Object> queryRecordList(Map<String,String> map){
        String result = iaxInterfaceService.queryRecordList(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }
    /**
     * 下载录音
     */
    @Override
    public boolean downloadRecord(Map<String,String> map){
        Boolean result = iaxInterfaceService.downloadRecord(map);
        return result;
    }
    /**
     * 删除小号平台上的录音
     */
    @Override
    public Map<String,Object> deleteRecord(Map<String,String> map){
        String result = iaxInterfaceService.deleteRecord(map);
        Map<String,Object> mp = loadMap(result);
        return mp;
    }

    /**
     * 封装的转换成map方法
     */
    private Map<String,Object> loadMap(String result){
        //转换成map类型
        JSONObject res = JSON.parseObject(result);
        Map<String,Object> map = (Map<String,Object>)res;
        return map;
    }
}
