package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IApiDocDao;
import com.cn.hjsj.pojo.ApiDoc;
import com.cn.hjsj.service.IApiDocService;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;

@Component("apiDocService")
public class IApiDocServiceImpl implements IApiDocService {

    @Resource(name="IApiDocDao")
    private IApiDocDao iApiDocDao;

    public Integer insert(ApiDoc apiDoc){
        return iApiDocDao.insert(apiDoc);
    }
    public Integer update(ApiDoc apiDoc,ApiDoc apiDocParmeter){
        return iApiDocDao.update(apiDoc,apiDocParmeter);
    }
    public List<ApiDoc> getList(ApiDoc apiDoc){
        return iApiDocDao.getList(apiDoc);
    }
    public Integer getListCount(ApiDoc apiDoc){
        return iApiDocDao.getListCount(apiDoc);
    }
    public Integer delete(ApiDoc apiDoc){
        return iApiDocDao.delete(apiDoc);
    }



}
