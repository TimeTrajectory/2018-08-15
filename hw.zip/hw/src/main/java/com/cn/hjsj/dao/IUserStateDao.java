package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.UserState;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IUserStateDao")
public interface IUserStateDao {

    public Integer insert(UserState userState);
    public Integer update(@Param("userState") UserState userState, @Param("userStateParmeter") UserState userStateParmeter);
    public List<UserState> getList(UserState userState);
    public Integer getListCount(UserState userState);

}
