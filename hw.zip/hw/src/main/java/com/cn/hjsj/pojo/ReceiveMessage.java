package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

import java.util.Date;

public class ReceiveMessage extends BaseBean {

    private String smsIdentifier;
    private String calling;
    private String called;
    private String virtualNumber;
    private String notificationMode;
    private String event;
    private String timeStamp;

    public String getSmsIdentifier() {
        return smsIdentifier;
    }

    public void setSmsIdentifier(String smsIdentifier) {
        this.smsIdentifier = smsIdentifier;
    }

    public String getCalling() {
        return calling;
    }

    public void setCalling(String calling) {
        this.calling = calling;
    }

    public String getCalled() {
        return called;
    }

    public void setCalled(String called) {
        this.called = called;
    }

    public String getVirtualNumber() {
        return virtualNumber;
    }

    public void setVirtualNumber(String virtualNumber) {
        this.virtualNumber = virtualNumber;
    }

    public String getNotificationMode() {
        return notificationMode;
    }

    public void setNotificationMode(String notificationMode) {
        this.notificationMode = notificationMode;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }
}
