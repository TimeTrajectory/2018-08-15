package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ISysMenu2Dao;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.ISysMenu2Service;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sysMenu2Service")
public class ISysMenu2ServiceImpl implements ISysMenu2Service {

    @Resource(name="ISysMenu2Dao")
    private ISysMenu2Dao iSysMenu2Dao;

    public List<SysMenu2> getList(SysMenu2 sysMenu2){
        return iSysMenu2Dao.getList(sysMenu2);
    }
    public Integer update(SysMenu2 sysMenu2, SysMenu2 sysMenu2Parmeter){
        return iSysMenu2Dao.update(sysMenu2,sysMenu2Parmeter);
    }
    public Integer insert(SysMenu2 sysMenu2){
        return  iSysMenu2Dao.insert(sysMenu2);
    }
    public Integer delete(SysMenu2 sysMenu2){
        return iSysMenu2Dao.delete(sysMenu2);
    }

}
