package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ISoundRecordingDao;
import com.cn.hjsj.pojo.SoundRecording;
import com.cn.hjsj.service.ISoundRecordingService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("soundRecordingService")
public class ISoundRecordingServiceImpl implements ISoundRecordingService {

    @Resource(name="ISoundRecordingDao")
    private ISoundRecordingDao iSoundRecordingDao;

    @Override
    public Integer insert(SoundRecording soundRecording){
        return iSoundRecordingDao.insert(soundRecording);
    }

    @Override
    public Integer update(SoundRecording soundRecording, SoundRecording soundRecordingParmeter){
        return iSoundRecordingDao.update(soundRecording,soundRecordingParmeter);
    }

    @Override
    public List<SoundRecording> getList(SoundRecording soundRecording){
        return iSoundRecordingDao.getList(soundRecording);
    }

    @Override
    public Integer getListCount(SoundRecording soundRecording){
        return iSoundRecordingDao.getListCount(soundRecording);
    }
}
