package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IUserApiDao;
import com.cn.hjsj.pojo.UserApi;
import com.cn.hjsj.service.IUserApiService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("userApiService")
public class IUserApiServiceImpl implements IUserApiService {
    @Resource(name="IUserApiDao")
    private IUserApiDao iUserApiDao;

    public List<UserApi> getList(UserApi userApi){
        return iUserApiDao.getList(userApi);
    }
    public Integer insert(UserApi userApi){
        return iUserApiDao.insert(userApi);
    }
    public Integer update(UserApi userApi,UserApi userApiParmeter){
        return iUserApiDao.update(userApi,userApiParmeter);
    }
    public Integer getListCount(UserApi userApi){
        return iUserApiDao.getListCount(userApi);
    }

}
