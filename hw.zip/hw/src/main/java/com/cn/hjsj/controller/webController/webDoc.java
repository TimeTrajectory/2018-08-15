package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.Api;
import com.cn.hjsj.pojo.ApiDoc;
import com.cn.hjsj.pojo.SessionToken;
import com.cn.hjsj.service.IApiDocService;
import com.cn.hjsj.service.IApiService;
import com.cn.hjsj.service.IUserApiService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//接口API开发者文档模块接口--Created By WangFeng on 2018-07-17
@Controller
@RequestMapping("/webDoc")
public class webDoc {

    @Resource(name = "userApiService")
    private IUserApiService userApiService;
    @Resource(name = "apiService")
    private IApiService apiService;
    @Resource(name = "apiDocService")
    private IApiDocService apiDocService;

    @ResponseBody
    @RequestMapping("/getDocApiList")
    @Permission("login")
    public Map getDocApiList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Api api = new Api();
            List<Api> list = apiService.getList(api);
            List apiList = new ArrayList();
            for (int i= 0;i<list.size();i++){
                Map apiMap = new HashMap();
                Api tempApi = list.get(i);
                apiMap.put("id",tempApi.getId());
                apiMap.put("apiCode",tempApi.getApiCode());
                apiMap.put("apiName",tempApi.getApiName());
                apiList.add(apiMap);
            }
            Map<String,Object> map1 = new HashMap<String,Object>();
            map1.put("api",apiList);
            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

    @ResponseBody
    @RequestMapping("/getDocApi")
    @Permission("login")
    public Map getDocApi(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map4
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String apiCode = paramMap.get("apiCode").toString();
            Api api = new Api();
            api.setApiCode(Integer.valueOf(apiCode));
            List<Api> list = apiService.getList(api);
            Map<String,Object> map1 = new HashMap<String,Object>();
            //根据apiCode在api表中查出相应数据
            Api apiTemp = list.get(0);
            map1.put("apiCode",apiTemp.getApiCode());
            map1.put("apiName",apiTemp.getApiName());
            map1.put("apiDescribe",apiTemp.getApiDescribe());
            //输出参数InputData
            ApiDoc apiDoc1 = new ApiDoc();
            apiDoc1.setApiCode(Integer.valueOf(apiCode));
            apiDoc1.setDataType(1);//设置数据类型为输入参数：1
            List<ApiDoc> docList1 = apiDocService.getList(apiDoc1);
            List apiDocList1 = new ArrayList();
            for (int i=0;i<docList1.size();i++){
                Map docMap = new HashMap();
                ApiDoc apiDocTemp = docList1.get(i);
                docMap.put("id",apiDocTemp.getId());
                docMap.put("parameter",apiDocTemp.getParameter());
                docMap.put("type",apiDocTemp.getType());
                docMap.put("must",apiDocTemp.getMust());
                docMap.put("maxLength",apiDocTemp.getMaxLength());
                docMap.put("describes",apiDocTemp.getDescribes());
                docMap.put("examples",apiDocTemp.getExamples());
                docMap.put("dataKey",apiDocTemp.getDataKey());
                apiDocList1.add(docMap);
            }
            map1.put("inputData",apiDocList1);
            //输出参数outData
            ApiDoc apiDoc2 = new ApiDoc();
            apiDoc2.setApiCode(Integer.valueOf(apiCode));
            apiDoc2.setDataType(2);//设置数据类型为输出参数：2
            List<ApiDoc> docList2 = apiDocService.getList(apiDoc2);
            List apiDocList2 = new ArrayList();
            for (int i=0;i<docList2.size();i++){
                Map docMap = new HashMap();
                ApiDoc apiDocTemp = docList2.get(i);
                docMap.put("id",apiDocTemp.getId());
                docMap.put("parameter",apiDocTemp.getParameter());
                docMap.put("type",apiDocTemp.getType());
                docMap.put("must",apiDocTemp.getMust());
                docMap.put("maxLength",apiDocTemp.getMaxLength());
                docMap.put("describes",apiDocTemp.getDescribes());
                docMap.put("examples",apiDocTemp.getExamples());
                docMap.put("dataKey",apiDocTemp.getDataKey());
                apiDocList2.add(docMap);
            }
            map1.put("outData",apiDocList2);
            //发送示例sendJSON
            ApiDoc sendApi = new ApiDoc();
            sendApi.setApiCode(Integer.valueOf(apiCode));
            sendApi.setDataType(3);//设置参数类型 发送示例：3
            ApiDoc sendApiDoc = apiDocService.getList(sendApi).get(0);
            if (sendApiDoc != null){
                Map sendMap = new HashMap();
                sendMap.put("id",sendApiDoc.getId());
                if (sendApiDoc.getParameter() !=null){
                    sendMap.put("parameter",sendApiDoc.getParameter());
                }
                if (sendApiDoc.getType() !=null){
                    sendMap.put("type",sendApiDoc.getType());
                }
                if (sendApiDoc.getMust() !=null){
                    sendMap.put("must",sendApiDoc.getMust());
                }
                if (sendApiDoc.getMaxLength() !=null){
                    sendMap.put("maxLength",sendApiDoc.getMaxLength());
                }
                if (sendApiDoc.getDescribes() !=null){
                    sendMap.put("describes",sendApiDoc.getDescribes());
                }
                if (sendApiDoc.getExamples() !=null){
                    sendMap.put("examples",sendApiDoc.getExamples());
                }
                if (sendApiDoc.getDataKey() !=null){
                    sendMap.put("dataKey",sendApiDoc.getDataKey());
                }
                if (sendApiDoc.getType() !=null){
                    sendMap.put("dataType",sendApiDoc.getDataType());
                }
                if (sendApiDoc.getSend() !=null) {
                    sendMap.put("send", sendApiDoc.getSend());
                }
                    sendMap.put("apiCode",sendApiDoc.getApiCode());
                map1.put("sendJSON",sendMap);
            }else {
                map.put("msg","该接口服务编号无发送示例信息！");
            }

            //返回示例returnJSON
            ApiDoc returnApi = new ApiDoc();
            returnApi.setApiCode(Integer.valueOf(apiCode));
            returnApi.setDataType(4);//设置参数类型 返回示例：4
            ApiDoc returnApiDoc = apiDocService.getList(returnApi).get(0);
            if (sendApiDoc != null){
                Map returnMap = new HashMap();
                returnMap.put("id",returnApiDoc.getId());
                if (returnApiDoc.getParameter() !=null){
                    returnMap.put("parameter",returnApiDoc.getParameter());
                }
                if (returnApiDoc.getType() !=null){
                    returnMap.put("type",returnApiDoc.getType());
                }
                if (returnApiDoc.getMust() !=null){
                    returnMap.put("must",returnApiDoc.getMust());
                }
                if (returnApiDoc.getMaxLength() !=null){
                    returnMap.put("maxLength",returnApiDoc.getMaxLength());
                }
                if (returnApiDoc.getDescribes() !=null){
                    returnMap.put("describes",returnApiDoc.getDescribes());
                }
                if (returnApiDoc.getExamples() !=null){
                    returnMap.put("examples",returnApiDoc.getExamples());
                }
                if (returnApiDoc.getDataKey() !=null){
                    returnMap.put("dataKey",returnApiDoc.getDataKey());
                }
                if (returnApiDoc.getType() !=null){
                    returnMap.put("dataType",returnApiDoc.getDataType());
                }
                if (returnApiDoc.getDemoReturn() !=null) {
                    returnMap.put("demoReturn", returnApiDoc.getDemoReturn());
                }
                returnMap.put("apiCode",returnApiDoc.getApiCode());

                map1.put("returnJSON",returnMap);
            }else {
                map.put("msg","该接口服务编号无返回示例信息！");
            }

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

    @ResponseBody
    @RequestMapping("/upDocApi")
    @Permission("login")
    public Map upDocApi(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            arraylist.add("inputData");
            arraylist.add("outData");
            arraylist.add("sendJSON");
            arraylist.add("returnJSON");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String apiCode = paramMap.get("apiCode").toString();//接口服务编号做条件不做修改
            Api apiParameter = new Api();
            apiParameter.setApiCode(Integer.valueOf(apiCode));
            JSONObject object1 = JSONObject.fromObject(object.get("parameter").toString());
            if (object1.containsKey("apiDescribe")) {
                String apiDescribe = paramMap.get("apiDescribe").toString();
                Api api = new Api();//非必输参数：接口服务说明
                api.setApiDescribe(apiDescribe);
                int upCount = apiService.update(api, apiParameter);
                if (upCount == 1) {
                    map.put("code", 10000);
                    map.put("msg", "修改成功");
                } else {
                    map.put("code", 10003);
                    map.put("msg", "修改失败");
                }
            }
            //接口变更：直接根据apiCode删除原本文档里的所有的参数数据 再根据输入参数新增数据
            ApiDoc delApiDoc = new ApiDoc();
            delApiDoc.setApiCode(Integer.parseInt(apiCode));
            int delCount = apiDocService.delete(delApiDoc);//删除该apiCode原本数据库的所有数据
            if (delCount > 0) { //删除成功过开始新增数据
                //封装输入参数inputData[]
                List inputData = (List) paramMap.get("inputData");
                JSONArray arrayInput = JSONArray.fromObject(inputData);
                if (arrayInput.size() > 0) {
                    List<ApiDoc> lists = (List) JSONArray.toCollection(arrayInput, ApiDoc.class);
                    for (ApiDoc x : lists) {
                        ApiDoc apiDoc = new ApiDoc();
                        apiDoc.setParameter(x.getParameter());
                        apiDoc.setMust(x.getMust());
                        apiDoc.setMaxLength(x.getMaxLength());
                        apiDoc.setDescribes(x.getDescribes());
                        apiDoc.setExamples(x.getExamples());
                        apiDoc.setDataKey(x.getDataKey());
                        apiDoc.setType("3");//类型为数组 3
                        apiDoc.setDataType(1);//数据类型为输入参数：1
                        int docAddCount = apiDocService.insert(apiDoc);
                        if (docAddCount == 1) {
                            map.put("code", 10000);
                            map.put("msg", "修改成功");
                        } else {
                            map.put("code", 10003);
                            map.put("msg", "修改失败");
                        }
                    }

                }
                //封装输入参数outData[]
                List outData = (List) paramMap.get("outData");
                JSONArray arrayOut = JSONArray.fromObject(outData);
                if (arrayOut.size() > 0) {
                    List<ApiDoc> lists = (List) JSONArray.toCollection(arrayOut, ApiDoc.class);
                    for (ApiDoc x : lists) {
                        ApiDoc apiDoc = new ApiDoc();
                        apiDoc.setParameter(x.getParameter());
                        apiDoc.setMust(x.getMust());
                        apiDoc.setMaxLength(x.getMaxLength());
                        apiDoc.setDescribes(x.getDescribes());
                        apiDoc.setExamples(x.getExamples());
                        apiDoc.setDataKey(x.getDataKey());
                        apiDoc.setType("3");//类型为数组 3
                        apiDoc.setDataType(2);//数据类型为输出参数：2
                        int docAddCount = apiDocService.insert(apiDoc);
                        if (docAddCount == 1) {
                            map.put("code", 10000);
                            map.put("msg", "修改成功");
                        } else {
                            map.put("code", 10003);
                            map.put("msg", "修改失败");
                        }

                    }
                }
                //封装输入参数sendJSON
                JSONObject parameter = object.getJSONObject("parameter");
                JSONObject sendJSON = parameter.getJSONObject("sendJSON");
                Map paramMapSend = (Map) JSONObject.toBean(JSONObject.fromObject(sendJSON.toString()), Map.class);
                for (Object o : paramMapSend.keySet()) {
                    ApiDoc apiDoc = new ApiDoc();
                    apiDoc.setSend(paramMapSend.get("send").toString());
                    apiDoc.setApiCode(Integer.parseInt(apiCode));
                    apiDoc.setDataType(3);//数据类型为：发送示例3
                    int upCount = apiDocService.insert(apiDoc);
                    if (upCount == 1) {
                        map.put("code", 10000);
                        map.put("msg", "修改成功");
                    } else {
                        map.put("code", 10003);
                        map.put("msg", "修改失败");
                    }
                }
                //封装输入参数json对象：returnJSON
                JSONObject returnJSON = parameter.getJSONObject("returnJSON");
                Map paramMapReturn = (Map) JSONObject.toBean(JSONObject.fromObject(returnJSON.toString()), Map.class);
                for (Object o : paramMapReturn.keySet()) {
                    ApiDoc apiDoc = new ApiDoc();
                    apiDoc.setDemoReturn(paramMapReturn.get("demoReturn").toString());
                    apiDoc.setApiCode(Integer.parseInt(apiCode));
                    apiDoc.setDataType(4);//数据类型为：返回实例 4
                    int upCount = apiDocService.insert(apiDoc);
                    if (upCount == 1) {
                        map.put("code", 10000);
                        map.put("msg", "修改成功");
                    } else {
                        map.put("code", 10003);
                        map.put("msg", "修改失败");
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }


    @ResponseBody
    @RequestMapping("/addDocApi")
    @Permission("login")
    public Map addDocApi(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            arraylist.add("apiName");
            arraylist.add("apiDescribe");
            arraylist.add("inputData");
            arraylist.add("outData");
            arraylist.add("sendJSON");
            arraylist.add("returnJSON");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String apiCode = paramMap.get("apiCode").toString();
            String apiName = paramMap.get("apiName").toString();
            String apiDescribe = paramMap.get("apiDescribe").toString();
            Api api = new Api();
            api.setApiCode(Integer.valueOf(apiCode));
            api.setApiName(apiName);
            api.setApiDescribe(apiDescribe);
            api.setApiState("Y");//接口服务状态默认 可用状态
            api.setCreateBy(((SessionToken)mapToken.get("data")).getUser());//创建者和更新者默认插入登录账号
            api.setUpdateBy(((SessionToken)mapToken.get("data")).getUser());
            int addCount = apiService.insert(api);
            if (addCount == 1){
                map.put("code",10000);
                map.put("msg","新增成功");
            }else{
                map.put("code",10003);
                map.put("msg","新增失败");
            }
            //接受输入参数inputData[]
            List inputData = (List)paramMap.get("inputData");
            JSONArray arrayInput = JSONArray.fromObject(inputData);
            if (arrayInput.size()>0){
                List<ApiDoc> lists = (List)JSONArray.toCollection(arrayInput, ApiDoc.class);
                for (ApiDoc x  :lists){
                    ApiDoc apiDoc = new ApiDoc();
                    apiDoc.setApiCode(Integer.valueOf(apiCode));
                    apiDoc.setParameter(x.getParameter());
                    apiDoc.setType(x.getType());
                    apiDoc.setMust(x.getMust());
                    apiDoc.setMaxLength(x.getMaxLength());
                    apiDoc.setDescribes(x.getDescribes());
                    apiDoc.setExamples(x.getExamples());
                    apiDoc.setDataKey(x.getDataKey());
                    apiDoc.setDataType(1);//数据类型为输入参数：1
                    int docAddCount = apiDocService.insert(apiDoc);
                    if (docAddCount == 1){
                        map.put("code",10000);
                        map.put("msg","新增成功");
                    }else{
                        map.put("code",10003);
                        map.put("msg","新增失败");
                    }
                }
            }
            //接受输入参数outData[]
            List outData = (List)paramMap.get("outData");
            JSONArray arrayOut = JSONArray.fromObject(outData);
            if (arrayOut.size()>0){
                List<ApiDoc> lists = (List)JSONArray.toCollection(arrayOut, ApiDoc.class);
                for (ApiDoc x  :lists){
                    ApiDoc apiDoc = new ApiDoc();
                    apiDoc.setApiCode(Integer.valueOf(apiCode));
                    apiDoc.setParameter(x.getParameter());
                    apiDoc.setType(x.getType());
                    apiDoc.setMust(x.getMust());
                    apiDoc.setMaxLength(x.getMaxLength());
                    apiDoc.setDescribes(x.getDescribes());
                    apiDoc.setExamples(x.getExamples());
                    apiDoc.setDataKey(x.getDataKey());
                    apiDoc.setDataType(2);//数据类型为输出参数：2
                    int docAddCount = apiDocService.insert(apiDoc);
                    if (docAddCount == 1){
                        map.put("code",10000);
                        map.put("msg","新增成功");
                    }else{
                        map.put("code",10003);
                        map.put("msg","新增失败");
                    }
                }
            }
            //封装输入参数sendJSON
//            String sendJSON = paramMap.get("sendJSON").toString();
//            ApiDoc apiDoc = new ApiDoc();
//            apiDoc.setApiCode(Integer.valueOf(apiCode));
//            apiDoc.setSend(sendJSON);
//            apiDoc.setDataType(3);//数据类型为发送实列：3
//            int sendAddCount = apiDocService.insert(apiDoc);
//            if (sendAddCount == 1){
//                map.put("code",10000);
//                map.put("msg","新增成功");
//            }else{
//                map.put("code",10003);
//                map.put("msg","新增失败");
//            }
//            //封装输入参数returnJSON
//            String returnJSON = paramMap.get("returnJSON").toString();
//            ApiDoc returnApiDoc = new ApiDoc();
//            returnApiDoc.setApiCode(Integer.valueOf(apiCode));
//            returnApiDoc.setDemoReturn(returnJSON);
//            returnApiDoc.setDataType(4);//数据类型为返回参数：4
//            int returnAddCount = apiDocService.insert(returnApiDoc);
//            if (returnAddCount == 1){
//                map.put("code",10000);
//                map.put("msg","新增成功");
//            }else{
//                map.put("code",10003);
//                map.put("msg","新增失败");
//            }
            //封装输入参数sendJSON
            JSONObject parameter = object.getJSONObject("parameter");
            JSONObject sendJSON = parameter.getJSONObject("sendJSON");
            //Map paramMapSend = (Map) JSONObject.toBean(JSONObject.fromObject(sendJSON.toString()), Map.class);
            //for (Object o:paramMapSend.keySet()){
                ApiDoc apiDoc1 = new ApiDoc();
                apiDoc1.setApiCode(Integer.valueOf(apiCode));
                apiDoc1.setSend(sendJSON.toString());
                apiDoc1.setDataType(3);//数据类型为发送实列：3
                int sendAddCount = apiDocService.insert(apiDoc1);
                if (sendAddCount == 1){
                    map.put("code",10000);
                    map.put("msg","新增成功");
                }else{
                    map.put("code",10003);
                    map.put("msg","新增失败");
                }
            //}
            //封装输入参数json对象：returnJSON
            JSONObject returnJSON = parameter.getJSONObject("returnJSON");
            //Map paramMapReturn = (Map) JSONObject.toBean(JSONObject.fromObject(returnJSON.toString()), Map.class);
            //for (Object o:paramMapReturn.keySet()){
                ApiDoc apiDoc2 = new ApiDoc();
                apiDoc2.setApiCode(Integer.valueOf(apiCode));
                apiDoc2.setDemoReturn(returnJSON.toString());
                apiDoc2.setDataType(4);//数据类型为返回参数：4
                int returnAddCount = apiDocService.insert(apiDoc2);
                if (returnAddCount == 1){
                    map.put("code",10000);
                    map.put("msg","新增成功");
                }else{
                    map.put("code",10003);
                    map.put("msg","新增失败");
                }
            //}
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

    @ResponseBody
    @RequestMapping("/delDocApi")
    @Permission("login")
    public Map delDocApi(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            arraylist.add("id");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String apiCode = paramMap.get("apiCode").toString();
            List ids = (List) paramMap.get("id");//解析数组id
            for (int i=0;i<ids.size();i++){
                Integer idParemer = Integer.parseInt(ids.get(i).toString());
                ApiDoc apiDoc = new ApiDoc();
                apiDoc.setApiCode(Integer.valueOf(apiCode));
                apiDoc.setId(idParemer);
                int delCount = apiDocService.delete(apiDoc);
                if (delCount == 1){
                    map.put("code",10000);
                    map.put("msg","删除成功");
                }else{
                    map.put("code",10003);
                    map.put("msg","删除失败");
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

}