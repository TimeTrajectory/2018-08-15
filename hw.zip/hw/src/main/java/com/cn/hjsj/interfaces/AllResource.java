package com.cn.hjsj.interfaces;

import com.cn.hjsj.interfaces.AppImpl.*;

import javax.annotation.Resource;

public class AllResource {

    @Resource(name = "abilityTestImpl")
    public AbilityTestImpl abilityTestImpl;

    @Resource(name = "abilityAXBImpl")
    public AbilityAXBImpl abilityAXBImpl;

    @Resource(name = "abilityQueryOrderedNumber")
    public AbilityQueryOrderedNumber abilityQueryOrderedNumber;

    @Resource(name = "abilityAXImpl")
    public AbilityAXImpl abilityAXImpl;


    @Resource(name = "abilityVoiceImpl")
    public AbilityVoiceImpl abilityVoiceImpl;

    @Resource(name = "abilityConversation")
    public AbilityConversationImpl abilityConversationImpl;


}
