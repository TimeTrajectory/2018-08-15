package com.cn.hjsj.pojo;

import com.cn.hjsj.pojo.base.BaseBean;

public class SysUserRoles extends BaseBean {
    private String userCode;
    private Integer roleId;

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
}
