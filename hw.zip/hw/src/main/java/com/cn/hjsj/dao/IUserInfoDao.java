package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.UserInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IUserInfoDao")
public interface IUserInfoDao {

    public Integer insert(UserInfo userInfo);
    public Integer update(@Param("userInfo") UserInfo userInfo, @Param("userInfoParmeter") UserInfo userInfoParmeter);
    public List<UserInfo> getList(UserInfo userInfo);
    public Integer getListCount(UserInfo userInfo);


}
