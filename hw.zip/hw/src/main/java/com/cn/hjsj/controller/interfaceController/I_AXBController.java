/**
 * FileName: I_BindNumberController
 * Author:   duzenjie
 * Date:     2018/7/21 15:26
 */
package com.cn.hjsj.controller.interfaceController;

import com.cn.hjsj.interfaceUtil.AXBInterface;
import com.cn.hjsj.interfaces.AppImpl.AbilityAXBImpl;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * 交易小号AXB
 */
@Component("abilityAXBImpl")
public class I_AXBController implements AbilityAXBImpl {


    @Resource(name = "AXBInterfaceUtil")
    private AXBInterface aXBInterface;

    @Override
    public Map bindNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            // 获取接口返回的数据
            Map data = new HashMap();
            System.out.println("bindNumber:" + maps);
            data = aXBInterface.axbBindNumber(maps);

            // 测试数据
            /*
            data.put("code","100000");
            data.put("description","Success");
            Map resultCishi = new HashMap();
            resultCishi.put("subscriptionId","sub00001");
            data.put("result",resultCishi);
            */

            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AXB绑定失败:" + data.get("description"));
                return map;
            }

            //返回
            map.put("code", 10000);
            map.put("msg", "成功");
            map.put("data", data.get("result"));
        } catch (Exception e) {
            LogUtil.error("/I_AXBController/bindNumber--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    @Override
    public Map unbindNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {

            // 获取接口返回的数据
            Map data = new HashMap();
            // 获取protectInfo
            if (maps.get("protectInfo") != null) {
                Map<String, String> mapProtectInfo = new HashMap<String, String>();
                mapProtectInfo = (Map<String, String>) maps.get("protectInfo");
                if (mapProtectInfo.get("relationProtect") != null) {
                    maps.put("relationProtect", mapProtectInfo.get("relationProtect").toString());
                }
                if (mapProtectInfo.get("bindDirection") != null) {
                    maps.put("bindDirection", mapProtectInfo.get("bindDirection").toString());
                }
                maps.remove("protectInfo");
            }
            System.out.println("maps2:" + maps);
            data = aXBInterface.axbUnbindNumber(maps);
            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AXB解绑失败:" + data.get("description"));
                return map;
            }
            map.put("code", 10000);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_AXBController/unbindNumber--内部错误：" + e.getMessage());
            e.printStackTrace();
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    @Override
    public Map modifyNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            System.out.println("axb_modifyNumber:" + maps);
            // 获取接口返回的数据
            Map data = new HashMap();
            data = aXBInterface.axbModifyNumber(maps);
            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AXB转绑失败:" + data.get("description"));
                return map;
            }
            //返回
            map.put("code", 10000);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_AXBController/modifyNumber--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }
}
