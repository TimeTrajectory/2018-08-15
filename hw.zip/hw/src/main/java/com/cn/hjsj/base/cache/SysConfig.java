package com.cn.hjsj.base.cache;

/**
 * Created by zsj on 2018/5/21.
 * 系统级公共参数配置
 */
public class SysConfig {
    private static String ip = "http://121.46.26.224:8088";

    private static String filePath1 = "D:/apache-tomcat-ability/webapps/ability/";//存放活动模板照片、二维码
    //C:/Users/Administrator/Desktop/apache-tomcat-7.0.70/webapps/store/
    private static String filePath2 = "D:/payQRCodeTemp/";//存放活动模板照片、二维码

//    private static String filePath1 = "E:/tomcat1/webapps/Flow/";//存放活动模板照片、二维码
//    private static String filePath2 = "G:/payQRCodeTemp/";//存放活动模板照片、二维码

//充值接口
//    private static String hjsj_cz_ip = "http://122.224.205.197:808/cplat/jk";//充值接口ip地址(正式环境)
//    private static String hjsj_cz_appkey = "Temp";//充值接口appkey(正式环境)
//    private static String hjsj_cz_password = "6D69B2E8DAFAAD47";//充值接口password(正式环境)
    private static String hjsj_cz_ip = "";
    private static String hjsj_cz_appkey = "";
    private static String hjsj_cz_password = "";

    //支付宝
    private static String alipay_appid = "2018052460224208";
    private static String alipay_seller_id = "2088901906075272";
    private static String alipay_callback = "http://www.baidu.com";//H5流量
    private static String alipay_callback2 = "http://www.baidu.com";//WEB流量
    private static String alipay_callback3 = "http://www.baidu.com";//H5话费
    private static String alipay_notify_verify = "http://121.46.26.224:8088/flow/alipayControl/alipay_callback";
    private static String alipay_private_key = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCE+6PvP1SpS/dOqsVkvP6yPHXgRpXi2+6MA/lmKN6ejxx83ieZ4Zi+96bV0qPTggveheoZ9dRwgcwEw3z9PTTNDSRNh11TmBGah/1VDX4/aXuZKQsxvAglRnOCpW67jcdfFCkw70SwEqzOc/MRlyFW1yCFPGyInODQNUxBAsQk79TctN6KdRiSLqeATbgZwloej5GmRaNDyMyfhA9St69Ou5qOd4Jh25qjb+sI34kr8DIJ31kvwKzC3Nda8bJIw7NrYeJ/0Vht3IeVL7PbMfau5K9josBkeJh1JCt+hRFZEajQOd7mU3/Q5yIBc5mRQ+MqZ4eJm2bcQkPSbt5Gnnv7AgMBAAECggEAGdbDTbNigdqu3Ow1mpNWcc9poABXE1NkkHQdO4ppZymrgV+xFidNhJ2eHyHkjy5PnBctG4o2kv3FZI+Pc6022zjYeu/4ZEvB7+LIiIQsqamXSHU/JZTBiGyd+R6n22169bB3KHj1Qbj/NsY0zpAs/DCksv7An/LLg+k3PdKJxhtDYvEbUgZ/zf6u7GrE7hfKayBR19JB5793B/e+NZMT46lxRHa76P8GN5x73Qsxt+GPeEmgP1efnqIWfnP7kMwMTR0hYnqHSq9NYzuFvUbZ8goLrJUvH73v+xxYSGB17h2qf2vAWaNJmdycBg1SW4C2rketth3ln98CfHwVuhfc4QKBgQDQxTMOhomD04sOdV8sPupnqGGNuFyJg2Y7HTmlqDryC8LoYiNggdECgwtFZjpQ82uWOKH1gJ166HMREYD4f+GTRW3r9r5uUmSsBRGEKLGVUMo0YE2GbvGZyV+EUY5MYfb/S5qLgpzpDM4EuDd0pRDdq0XzHU3YDn+VpUDXkrp9IwKBgQCjEUPZCgkOcTrrchHciJrm8aQ+3tSuRvi6ITby6EKR8YZeLpSJdGM6G+qB+x7U2MyDLF4lyR0vPArc1RIeFhbQtyctWIufGKRJCWe0uitROf9YqdBtcjBahgwSy87gqBCOzG15KA2ITvhOuk+i9L3vHxGT0vXKWv778pYUFpFPSQKBgGjBmuX+AkDAxHUD1jbIdyx+ZD0NtnlWEtU0y/lg2fschbe/jsrdOPiOsvgm3LpD+sdNMY+T8vF6dEqrQtDusk0IuKh/jnyjIVrjzC9JkBpBiMURUbVUNC0by68EkWeofJ0L3ceFSaDzSOk7WrBQJ49jYt0j5iy00bZQTqIdQTCLAoGAK9G45LrgoiPlTF2z1QpUbdjjZQ2mI0rpDcNdK7skIGnBzM9BlQpUm8nio5kiuNmlY15p0keP8yB0XtFW9ATFjsKY4YOYyWDqzMGdP6CDgWlPZ7kCTFbSDZFV7zsbVZ10DZt7k4Ii2M03xpgkTEruOzKjG5EmAYGgYX3XvIAv/hkCgYBQBajT1Me54Bne/u7fpiyXx94uc2hTSyywq3TUAqIJC9SlkgL5M7zuhpHXMbLknaeXmRLWsI2yZnUSmopBxfobfuBnP/qARc91ZzAW0N5j3YUwN1dAVrBZwg4Y2X9Z/OAM+v6pV/SCxw7a8lmuM22qd9pH7T1JCGIc7r5R23F1kA==";
    private static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhaKy7Q7GzyiNBVvYOdqBwlWIq5S8R5mfFzGI5l2NGSo635ErGZSoBOr+ehMM6CHUPLTP+pEhWspwZeLHrHCBZxM7IUv0faLRFmk8OnuVwlCAwX/iHx8cWonptSp7HLXKB3GU0tJqu/hp0M/Ragt0DaqtFonfQ/gdOvEAcEGzrSwZIXUHn9G30q/BWbF7uzbTG47Ethge1RRGJIG6oJ2Lc1WDwzDqb9nZIiNQI7B15GUOzk+qoA69/lCGrbUum68F0J2vEqD8n2B8cTk0cAix1EOt/+ROAPXScGha0j036NgI0rhbYvavR1cy9QEEf+F5vLkatdIlVXExmUuzX4JYJQIDAQAB";
    //微信
    private static String wx_certPath = "/path/to/apiclient_cert.p12";
    private static String wx_appid = "";
    private static String wx_mch_id = "";
    private static String wx_key = "";
    private static String wx_notify_verify = "http://121.46.26.224:8088/flow/wxControl/wx_callback";


    public static String getIp() {
        return ip;
    }

    public static String getFilePath1() {
        return filePath1;
    }

    public static String getFilePath2() {
        return filePath2;
    }

    public static String getHjsj_cz_ip() {
        return hjsj_cz_ip;
    }

    public static String getHjsj_cz_appkey() {
        return hjsj_cz_appkey;
    }

    public static String getHjsj_cz_password() {
        return hjsj_cz_password;
    }

    public static String getAlipay_appid() {
        return alipay_appid;
    }

    public static String getAlipay_seller_id() {
        return alipay_seller_id;
    }

    public static String getAlipay_callback() {
        return alipay_callback;
    }

    public static String getAlipay_callback2() {
        return alipay_callback2;
    }

    public static String getAlipay_callback3() {
        return alipay_callback3;
    }

    public static String getAlipay_notify_verify() {
        return alipay_notify_verify;
    }

    public static String getAlipay_private_key() {
        return alipay_private_key;
    }

    public static String getAlipay_public_key() {
        return alipay_public_key;
    }

    public static String getWx_certPath() {
        return wx_certPath;
    }

    public static String getWx_appid() {
        return wx_appid;
    }

    public static String getWx_mch_id() {
        return wx_mch_id;
    }

    public static String getWx_key() {
        return wx_key;
    }

    public static String getWx_notify_verify() {
        return wx_notify_verify;
    }
}
