package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.SessionToken;
import com.cn.hjsj.pojo.User;
import com.cn.hjsj.service.ISessionTokenService;
import com.cn.hjsj.service.IUserService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.Md5Util;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;

import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.*;


/**
 * Created by zhyuj on 2018/7/23.
 */
@Controller
@RequestMapping("/webLogin")
public class webLogin {

    @Resource
    private IUserService userService;
    @Resource
    private ISessionTokenService sessionTokenService;

    //1
//登录 create by wangfeng on 2018-08-07
    @ResponseBody
    @RequestMapping("/login")
    @Permission("login")
    public Map login(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            Map<String, Object> dataMap = new HashMap<String, Object>();
            arraylist.add("userName");
            arraylist.add("password");

            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String userName = paramMap.get("userName").toString();
            String password = paramMap.get("password").toString();
            //业务逻辑
            User user = new User();
            user.setUser(userName);
            List<User> listUser = userService.getList(user);
            //获取企业名称 以便插入sessionToken表时的userName字段
            String enterpriseName = listUser.get(0).getEnterpriseName();
            if (listUser == null || listUser.size() == 0){
                //用户不存在user表中
                map.put("code", 10003);
                map.put("msg", "用户不存在");
                return map;
            }
            if(!listUser.get(0).getPassword().equals(password)){
                //账号存在user表中 则密码不对
                map.put("code", 10003);
                map.put("msg", "密码不正确");
                return map;
            }
            //存在于user表中时 再判断该用户是否存在token表中
            String userCode = listUser.get(0).getUserCode();
            SessionToken sessionToken = new SessionToken();
            sessionToken.setUser(userName);
            List<SessionToken> sessionToken1 = sessionTokenService.getList(sessionToken);
            if (sessionToken1 == null || sessionToken1.size() ==0){
                //该用户在token表中还没有记录 则新增一条数据
                String uuid = UUID.randomUUID().toString();
                String uuidMd5 = Md5Util.GetMD5_16Code(uuid);
                sessionToken.setSessionToken(uuidMd5);
                sessionToken.setUserCode(userCode);
                sessionToken.setUser(user.getUser());
                sessionToken.setUserName(enterpriseName);
                sessionToken.setLoginTime(TimeUtil.getNowStr());
                sessionToken.setInvalidTime(TimeUtil.getNowStr());
                Integer i = sessionTokenService.insert(sessionToken);
                if (i == 1) {
                    dataMap.put("userName", userName);
                    dataMap.put("token", uuidMd5);
                    map.put("code", 10000);
                    map.put("msg", "登录成功");
                    map.put("data", dataMap);
                } else {
                    map.put("code", 10003);
                    map.put("msg", "登入失败");
                }
            }else{
                //如果账号存在于Token表中则直接获取sessionToken登录成功
                SessionToken sessionTokenUser = sessionToken1.get(0);
                dataMap.put("token", sessionTokenUser.getSessionToken());
                dataMap.put("userName", userName);
                map.put("code", 10000);
                map.put("msg", "登录成功");
                map.put("data", dataMap);
            }
        } catch (Exception e) {
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

//2
    /**
     * zhuyj
     * 注销
     */
    @ResponseBody
    @RequestMapping("/cancel")
    @Permission("login")
    public Object cancel(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{
            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }

            SessionToken sessionToken = new SessionToken();
            sessionToken.setUser(((SessionToken)mapToken.get("data")).getUser());//登入的账号
            Integer del = sessionTokenService.delete(sessionToken);
            if (del > 0){
                map.put("code",10000);
                map.put("msg","注销成功");
            }else {
                map.put("code", 10003);
                map.put("msg", "注销失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("mag","系统异常，请稍后重试");
        }

        return map;
    }



}
