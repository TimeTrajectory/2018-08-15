package com.cn.hjsj.service;

import com.cn.hjsj.pojo.ApiDoc;
import java.util.List;

public interface IApiDocService {

    public Integer insert(ApiDoc apiDoc);
    public Integer update(ApiDoc apiDoc,ApiDoc apiDocParmeter);
    public List<ApiDoc> getList(ApiDoc apiDoc);
    public Integer getListCount(ApiDoc apiDoc);
    public Integer delete(ApiDoc apiDoc);


}
