package com.cn.hjsj.retime;

import com.cn.hjsj.util.LogUtil;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class timerListener  implements ServletContextListener {
	private timerSet ts=new timerSet();
	//关闭定时器
	public void contextDestroyed(ServletContextEvent arg0) {
		LogUtil.info("关闭定时器");
		ts.timerStop();
	}

	//启动定时器
	public void contextInitialized(ServletContextEvent arg0) {
		LogUtil.info("启动定时器");
		ts.timerStart();
	}
}
