package com.cn.hjsj.base.load;

import com.cn.hjsj.base.cache.UserCache;
import com.cn.hjsj.util.ClassUtil;

public class HelperLoader {
    public static void init() {
        Class<?>[] classList = {
                UserCache.class
        };
        for (Class<?> cls : classList) {
            ClassUtil.loadClass(cls.getName());
        }
    }
}
