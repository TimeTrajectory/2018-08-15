package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.*;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.ISysRolesMenu2Service;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sysRolesMenu2Service")
public class ISysRolesMenu2ServiceImpl implements ISysRolesMenu2Service {
    @Resource(name="ISysRolesMenu2Dao")
    private ISysRolesMenu2Dao iSysRolesMenu2Dao;

    public Integer insert(SysRolesMenu2 sysRolesMenu2){
        return  iSysRolesMenu2Dao.insert(sysRolesMenu2);
    }
    public Integer update(SysRolesMenu2 sysRolesMenu2,SysRolesMenu2 sysRolesMenu2Parmeter){
        return  iSysRolesMenu2Dao.update(sysRolesMenu2,sysRolesMenu2Parmeter);
    }
    public List<SysRolesMenu2> getList(SysRolesMenu2 sysRolesMenu2){
        return iSysRolesMenu2Dao.getList(sysRolesMenu2);
    }

    public Integer delete(SysRolesMenu2 sysRolesMenu2){
        return iSysRolesMenu2Dao.delete(sysRolesMenu2);
    }
}
