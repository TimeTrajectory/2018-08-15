package com.cn.hjsj.service;

import com.cn.hjsj.pojo.Role;

import java.util.List;

public interface IRoleService {

    public Integer insert(Role role);
    public Integer update(Role role,Role roleParmeter);
    public List<Role> getList(Role role);
    public Integer getListCount(Role role);
}
