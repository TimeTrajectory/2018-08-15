package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.cache.SysConfig;
import com.cn.hjsj.util.SpringUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.*;

//上传文件--Created By WangFeng on 2018-07-25
@Controller
@RequestMapping("/webFile")
public class webFile {

    @ResponseBody
    @RequestMapping("/upFile")
    public static Object upFile(@RequestParam MultipartFile file, String par) {
        //System.out.println("================"+file.getSize());
        Map<String, Object> map = new HashMap<String, Object>();
        //上传文件的原名(即上传前的文件名字)
        String originalFilename = null;
        //上传文件的类型
        String prefix = null;

        try{
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("file");

            map = webCheck.checkJson(par, arraylist);

            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            if (file.isEmpty()) {
                map.put("code", 31001);
                map.put("msg", "没有选择文件");
                return map;
            }
            originalFilename = file.getOriginalFilename(); //随机生成文件名
            prefix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);//通过图片名获取图片后缀得到图片类型

            //业务逻辑
            JSONObject object = JSONObject.fromObject(par);
            JSONObject parameter =JSONObject.fromObject(object.get("parameter").toString());
            String token = object.get("token").toString();
            int fileType = parameter.getInt("file");

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            //设置上传文件的地址
            String url = SysConfig.getFilePath1() + "img/";

            String pictureName = String.valueOf(UUID.randomUUID()) + "." + prefix;
            //关闭文件流

            FileUtils.copyInputStreamToFile(file.getInputStream(), new File(url, pictureName));

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("fileType", pictureName);

            map.put("data", map1);
            map.put("code", 10000);
            map.put("msg", "上传成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }

}