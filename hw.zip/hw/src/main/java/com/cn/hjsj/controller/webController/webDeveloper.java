package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.*;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//企业开发者模块--Created By WangFeng on 2018-08-08
@Controller
@RequestMapping("/webDeveloper")
public class webDeveloper {

    @Resource(name = "apiService")
    private IApiService apiService;
    @Resource(name = "userApiService")
    private IUserApiService userApiService;
    @Resource(name = "apiDocService")
    private IApiDocService apiDocService;
    @Resource(name = "userApiStateService")
    private IUserApiStateService userApiStateService;
    @Resource(name = "userService")
    private IUserService userService;

    @ResponseBody
    @RequestMapping("/getDocDeveloperList")
    @Permission("login")
    public Map getDocDeveloperList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Api api = new Api();
            api.setApiState("Y");//服务接口状态为 可签约
            List<Api> list = apiService.getList(api);
            List apiList = new ArrayList();
            for (int i=0;i<list.size();i++){
                Map apiMap = new HashMap();
                Api tempApi = list.get(i);
                apiMap.put("apiCode",tempApi.getApiCode());
                apiMap.put("apiName",tempApi.getApiName());
                apiMap.put("apiDescribe",tempApi.getApiDescribe());
                apiList.add(apiMap);
            }
            Map<String,Object> map1 = new HashMap<String,Object>();
            map1.put("api",apiList);
            UserApiState userApiState1 = new UserApiState();
            userApiState1.setApiState(2);//签约状态：已签约
            List<UserApiState> List1 = userApiStateService.getList(userApiState1);
            List apiList1 = new ArrayList();
            for (int i=0;i<List1.size();i++){
                Map apiMap1 = new HashMap();
                UserApiState tempApi1 = List1.get(i);
                apiMap1.put("apiCode",tempApi1.getApiCode());
                apiList1.add(apiMap1);
            }
            map1.put("api1",apiList1);

            UserApiState userApiState2 = new UserApiState();
            userApiState2.setApiState(1);//签约状态：待签约
            List<UserApiState> List2 = userApiStateService.getList(userApiState2);
            List apiList2 = new ArrayList();
            for (int i=0;i<List2.size();i++){
                Map apiMap2 = new HashMap();
                UserApiState tempApi2 = List2.get(i);
                apiMap2.put("apiCode",tempApi2.getApiCode());
                apiList2.add(apiMap2);
            }
            map1.put("api2",apiList2);

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }



    @ResponseBody
    @RequestMapping("/APIApplication")
    @Permission("login")
    public Map APIApplication(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            arraylist.add("apiName");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map4
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            //接受输入参数
            String apiCode = paramMap.get("apiCode").toString();
            String apiName = paramMap.get("apiName").toString();
            //设置添加对象
            UserApiState userApiState = new UserApiState();
            userApiState.setApiCode(Integer.parseInt(apiCode));
            userApiState.setApiName(apiName);
            userApiState.setApiState(1);//签约状态：待签约
            userApiState.setApiStateName("待签约");//签约状态名称：待签约
            userApiState.setCreateBy(((SessionToken)mapToken.get("data")).getUser());//登入的账号
            userApiState.setCreateDate(TimeUtil.getNowStr());
            userApiState.setUpdateBy(((SessionToken)mapToken.get("data")).getUser());//登入的账号
            userApiState.setUpdateDate(TimeUtil.getNowStr());
            userApiState.setUserCode(((SessionToken)mapToken.get("data")).getUserCode());
            //根据userCode获取在对象UserInfo中enterpriseName插入表user_api_state
            User user = new User();
            user.setUserCode(((SessionToken)mapToken.get("data")).getUserCode());
            String enterpriseName = userService.getList(user).get(0).getEnterpriseName();
            userApiState.setEnterpriseName(enterpriseName);
            Integer addCount = userApiStateService.insert(userApiState);
            if (addCount == 1){
                map.put("code",10000);
                map.put("msg","申请签约成功");
            }else {
                map.put("code", 10003);
                map.put("msg", "申请签约失败");
            }
//            Api api = new Api();
//            api.setApiCode(Integer.valueOf(apiCode));
//            api.setApiName(apiName);
//            List<Api> apiList = apiService.getList(api);
//            if (apiList.size() > 0){
//                String apiState = apiList.get(0).getApiState();
//                if ("Y".equals(apiState)){
//                    //获取可签约数据
//                    UserApiState userApiStateParemer = new UserApiState();//作为条件的封装对象
//                    userApiStateParemer.setApiCode(Integer.valueOf(apiCode));
//                    userApiStateParemer.setApiName(apiName);
//                    UserApiState userApiState = new UserApiState();//要修改参数的封装对象
//                    userApiState.setApiState(2);//签约状态:（1：已签约）
//                    userApiState.setApiStateName("已签约");
//                    int upCount = userApiStateService.update(userApiState,userApiStateParemer);
//                    if (upCount == 1){
//                        map.put("code",10000);
//                        map.put("msg","签约成功");
//                    }else {
//                        map.put("code", 10003);
//                        map.put("msg", "签约失败");
//                    }
//                }else {
//                    //状态为不可签约时直接退出
//                    map.put("code",10003);
//                    map.put("msg","该接口不可签约！");
//                    return map;
//                }
//            }else {
//                map.put("code",10003);
//                map.put("msg","该接口不可签约！");
//                return map;
//            }

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }


    @ResponseBody
    @RequestMapping("/getAPIApplicationList")
    @Permission("login")
    public Map getAPIApplicationList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            map = webCheck.checkJson(jsonstring, arraylist);
//            返回码不为10000，直接返回map4
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            UserApiState userApiState = new UserApiState();
            userApiState.setApiState(2);//设置签约状态为已签约
            //userApiState.setApiStateName("已签约");
            List<UserApiState> list = userApiStateService.getList(userApiState);
            List userApiStateList = new ArrayList();
            for (int i=0;i<list.size();i++){
                Map userApiStateMap = new HashMap();
                UserApiState tempUserApiState = list.get(i);
                userApiStateMap.put("apiCode",tempUserApiState.getApiCode());
                userApiStateMap.put("apiName",tempUserApiState.getApiName());
                userApiStateList.add(userApiStateMap);
            }
            Map<String,Object> map1 = new HashMap<String,Object>();
            map1.put("user_api",userApiStateList);
            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

    @ResponseBody
    @RequestMapping("/getAPIApplication")
    @Permission("login")
    public Map getAPIApplication(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("apiCode");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map4
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            String apiCode = paramMap.get("apiCode").toString();
            Api api = new Api();
            api.setApiCode(Integer.valueOf(apiCode));
            List<Api> list = apiService.getList(api);
            Map<String,Object> map1 = new HashMap<String,Object>();
            //根据apiCode在api表中查出相应数据
            Api apiTemp = list.get(0);
            map1.put("apiCode",apiTemp.getApiCode());
            map1.put("apiName",apiTemp.getApiName());
            map1.put("apiDescribe",apiTemp.getApiDescribe());
            //输出参数inputData
            ApiDoc apiDoc1 = new ApiDoc();
            apiDoc1.setApiCode(Integer.valueOf(apiCode));
            apiDoc1.setDataType(1);//设置数据类型为输入参数：1
            List<ApiDoc> docList1 = apiDocService.getList(apiDoc1);
            List apiDocList1 = new ArrayList();
            for (int i=0;i<docList1.size();i++){
                Map docMap = new HashMap();
                ApiDoc apiDocTemp = docList1.get(i);
                docMap.put("id",apiDocTemp.getId());
                docMap.put("parameter",apiDocTemp.getParameter());
                docMap.put("type",apiDocTemp.getType());
                docMap.put("must",apiDocTemp.getMust());
                docMap.put("maxLength",apiDocTemp.getMaxLength());
                docMap.put("describe",apiDocTemp.getDescribes());
                docMap.put("examples",apiDocTemp.getExamples());
                docMap.put("dataKey",apiDocTemp.getDataKey());
                apiDocList1.add(docMap);
            }
            map1.put("inputData",apiDocList1);
            //输出参数outData
            ApiDoc apiDoc2 = new ApiDoc();
            apiDoc2.setApiCode(Integer.valueOf(apiCode));
            apiDoc2.setDataType(2);//设置数据类型为输出参数：2
            List<ApiDoc> docList2 = apiDocService.getList(apiDoc2);
            List apiDocList2 = new ArrayList();
            for (int i=0;i<docList2.size();i++){
                Map docMap = new HashMap();
                ApiDoc apiDocTemp = docList2.get(i);
                docMap.put("id",apiDocTemp.getId());
                docMap.put("parameter",apiDocTemp.getParameter());
                docMap.put("type",apiDocTemp.getType());
                docMap.put("must",apiDocTemp.getMust());
                docMap.put("maxLength",apiDocTemp.getMaxLength());
                docMap.put("describe",apiDocTemp.getDescribes());
                docMap.put("examples",apiDocTemp.getExamples());
                docMap.put("dataKey",apiDocTemp.getDataKey());
                apiDocList2.add(docMap);
            }
            map1.put("outData",apiDocList2);
            //发送示例sendJSON
            ApiDoc sendApi = new ApiDoc();
            sendApi.setApiCode(Integer.valueOf(apiCode));
            sendApi.setDataType(3);//设置参数类型 发送示例：3
            List<ApiDoc> list1 = apiDocService.getList(sendApi);
            if (list1.size() > 0){
                map1.put("sendJSON",list1.get(0).getSend());
            }else{
                map.put("msg","该接口服务编号无发送示例信息");
            }
            //返回示例returnJSON
            ApiDoc returnApi = new ApiDoc();
            returnApi.setApiCode(Integer.valueOf(apiCode));
            returnApi.setDataType(4);//设置参数类型 返回示例：4
            List<ApiDoc> list2 = apiDocService.getList(returnApi);
            if (list2.size() > 0){
                map1.put("returnJSON",list2.get(0).getDemoReturn());
            }else{
                map.put("msg","该接口服务编号无返回示例信息");
            }

            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }

}