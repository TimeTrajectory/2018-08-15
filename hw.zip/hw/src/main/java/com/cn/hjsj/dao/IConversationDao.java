package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.Conversation;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("IConversationDao")
public interface IConversationDao {

    public Integer insert(Conversation conversation);
    public List<Conversation> getList(Conversation conversation);
    public Integer update(@Param("conversation")Conversation conversation, @Param("conversationParmeter")Conversation conversationParmeter);

    public Integer getListCount(Conversation conversation);

}
