package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.*;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.IRoleService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("roleService")
public class IRoleServiceImpl implements IRoleService {
    @Resource(name="IRoleDao")
    private IRoleDao iRoleDao;

    public Integer insert(Role role){
        return  iRoleDao.insert(role);
    }
    public Integer update(Role role,Role roleParmeter){
        return  iRoleDao.update(role,roleParmeter);
    }
    public List<Role> getList(Role role){
        return iRoleDao.getList(role);
    }
    public Integer getListCount(Role role){
        return iRoleDao.getListCount(role);
    }

}
