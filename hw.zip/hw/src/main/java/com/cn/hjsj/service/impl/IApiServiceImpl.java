package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IApiDao;
import com.cn.hjsj.pojo.Api;
import com.cn.hjsj.service.IApiService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("apiService")
public class IApiServiceImpl implements IApiService {

    @Resource(name="IApiDao")
    private IApiDao iApiDao;
    public Integer insert(Api api){
        return iApiDao.insert(api);
    }
    public Integer update(Api api,Api apiParmeter){
        return iApiDao.update(api,apiParmeter);
    }
    public List<Api> getList(Api api){
        return iApiDao.getList(api);
    }
    public Integer getListCount(Api api){
        return iApiDao.getListCount(api);
    }


}
