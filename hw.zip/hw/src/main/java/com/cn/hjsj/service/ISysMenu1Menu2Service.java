package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SysMenu1Menu2;
import com.cn.hjsj.pojo.SysRolesMenu2;

import java.util.List;

public interface ISysMenu1Menu2Service {

    public List<SysMenu1Menu2> getList(SysMenu1Menu2 sysMenu1Menu2);
    public Integer update(SysMenu1Menu2 sysMenu1Menu2, SysMenu1Menu2 sysMenu1Menu2Parmeter);
    public Integer insert(SysMenu1Menu2 sysMenu1Menu2);
    public Integer delete(SysMenu1Menu2 sysMenu1Menu2);

}
