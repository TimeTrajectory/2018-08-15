package com.cn.hjsj.base.setting;

/**
 * Created by Administrator on 2016/3/21.
 */
public class MediaType {
    public static final String APPLICATION_JSON="application/json";
    public static final String APPLICATION_XML="application/xml";
}
