package com.cn.hjsj.service;

import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.pojo.Test;

import java.util.List;

public interface IConversationService {

    public Integer insert(Conversation conversation);
    public List<Conversation> getList(Conversation conversation);
    public Integer update(Conversation conversation, Conversation conversationParmeter);

    public Integer getListCount(Conversation conversation);
}
