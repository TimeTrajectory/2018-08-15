/**
 * FileName: I_AXController
 * Author:   duzenjie
 * Date:     2018/7/22 10:31
 */
package com.cn.hjsj.controller.interfaceController;

import com.cn.hjsj.interfaceUtil.AXInterface;
import com.cn.hjsj.interfaces.AppImpl.AbilityAXImpl;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Component("abilityAXImpl")
public class I_AXController implements AbilityAXImpl {

    @Resource(name = "AXInterfaceUtil")
    private AXInterface aXInterface;

    @Override
    public Map bindNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            // 获取接口返回的数据
            Map data = new HashMap();
            System.out.println(maps);
            data = aXInterface.axBindNumber(maps);

            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AX绑定失败:"+data.get("description"));
                return map;
            }

            //返回
            map.put("code", 10000);
            map.put("data",data.get("result"));
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_AXController/bindNumber--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    @Override
    public Map unbindNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            System.out.println(maps);

            // 获取接口返回的数据
            Map data = new HashMap();
            data = aXInterface.axUnbindNumber(maps);

            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AX解绑失败:"+data.get("description"));
                return map;
            }
            //返回
            map.put("code", 10000);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_AXController/unbindNumber--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }

    @Override
    public Map setLogicPowerStatus(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            System.out.println(maps);

            // 获取接口返回的数据
            Map data = new HashMap();
            data = aXInterface.axSetLogicPowerStatus(maps);

            // 接口返回数据检验
            if (!"000000".equals(data.get("code"))) {
                map.put("code", 30001);
                map.put("msg", "交易小号AX逻辑开关机失败:"+data.get("description"));
                return map;
            }

            //返回
            map.put("code", 10000);
            map.put("msg", "成功");
        } catch (Exception e) {
            LogUtil.error("/I_AXController/setLogicPowerStatus--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }
}
