package com.cn.hjsj.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cn.hjsj.service.IHostingVoiceEventService;

import java.util.Map;

/**
 * 小号事件通知
 * 客户平台收到华为小号平台的呼叫事件或短信事件的接口通知
 * 
 * Created by l00194296 on 2017/3/25.
 */
public class IHostingVoiceEventServiceImpl implements IHostingVoiceEventService
{
    /**
     * 短信通知
     * @param jsonBody 小号平台推送到客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    @Override
    public String onSmsEvent(String jsonBody)
    {
        JSONObject json = JSON.parseObject(jsonBody);
        
        //小号业务平台分配给商户应用的AppKey(必填)
        String appKey = json.getString("appKey");
        
        //短信状态事件
        JSONObject smsEvent = json.getJSONObject("smsEvent");
        
        //短信唯一标识
        //注：如果是长短信则合并为一条。
        String smsIdentifier = smsEvent.getString("smsIdentifier");
        
        //真实主叫号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(smsEvent,"calling")) {
            String calling = smsEvent.getString("calling");
        }
        //真实被叫号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(smsEvent,"called")) {
            String called = smsEvent.getString("called");
        }
        //虚拟号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(smsEvent,"virtualNumber")) {
            String virtualNumber = smsEvent.getString("virtualNumber");
        }
        //短信状态事件
        //取值：TextSMS-文本短信
        String event = smsEvent.getString("event");
        
        //呼叫事件发生的时间戳，UTC时间
        //格式：YYYY-MM-DDThh:mm:ss.SSSZ  示例：2013-10-09T08:33:07.789Z
        String timeStamp = smsEvent.getString("timeStamp");
        
        // 通知模式
        // 取值：Notify-商户不能做短信事件控制, Block-商户可以指示能力开发平台做短信事件控制
        // 如果notificationMode是Block模式，响应必须携带消息体，返回对短信事件的处理操作,详细内容见接口文档说明
        String notificationMode = smsEvent.getString("notificationMode");
        
        // 如果是Block模式，则要按接口文档进行回复响应
        if ("Block".equalsIgnoreCase(notificationMode))
        {
            JSONObject resp = new JSONObject();
            JSONArray actions = new JSONArray();
            
            JSONObject action = new JSONObject();
            // 操作类型： NumberRoute-小号平台转发短信; DiscardMessage-小号平台不转发短信，将短信丢弃。
            action.put("operation", "vNumberRoute");
            actions.add(action);
            
            resp.put("actions", actions);
        }
        //数据的持久化

        return "";
    }
    
    /**
     * 呼叫通知
     * @param jsonBody 小号平台推送客户系统的json body
     * @breif 详细内容以接口文档为准
     */
    @Override
    public String onCallEvent(String jsonBody)
    {
        //封装JOSN请求
        JSONObject json = JSON.parseObject(jsonBody);
        
        //小号业务平台分配给商户应用的AppKey
        String appKey = json.getString("appKey");
        
        //获取呼叫状态事件对象
        JSONObject ceit = json.getJSONObject("callEvent");
        
        //呼叫唯一标识
        String callIdentifier = ceit.getString("callIdentifier");
        
        //通知模式
        //取值：Notify-商户不对呼叫进行控制， Block-商户可以指示小号业务平台做呼叫控制
        //注：推送消息中通知模式是Block模式，则商户需要给AEP响应，否则商户不回响应或者超时响应，则小号平台根据配置来放回铃音，然后释放呼叫。
        String notificationMode = ceit.getString("notificationMode");
        
        //真实主叫号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(ceit,"calling")) {
            String calling = ceit.getString("calling");
        }
        //真实被叫号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(ceit,"called")) {
            String called = ceit.getString("called");
        }
        //虚拟号码
        //格式：国家码+手机号  示例：8613800000000
        if(isEmpty(ceit,"virtualNumber")) {
            String virtualNumber = ceit.getString("virtualNumber");
        }
        //呼叫状态事件
        //取值：IDP-呼叫开始, Answer-应答 , Release-释放, Exception-呼叫过程中发生的异常
        //注：个人小号AX模式支持上述所有事件。交易小号AXB模式，不支持Answer事件，并且IDP事件只有在请求是否录音时才会触发
        String event = ceit.getString("event");
        
        //呼叫事件发生的时间戳
        //格式：YYYY-MM-DDThh:mm:ss.SSSZ  示例：2013-10-09T08:33:07.789Z
        //注：1.SSS表示毫秒，注意固定字符“T”、“Z”
        String timestamp = ceit.getString("timestamp");
        
        //是否录音
        //注：1.只有在notify情况下的release事件，exception事件和answer事件推送isRecord字段
        if (notificationMode.equals("Notify"))
        {
            // 取值：1-录音    0-不录音
            String isRecord = ceit.getString("isRecord");
        }
        
        //扩展呼叫事件信息对象
        if(isEmpty(ceit,"extInfo")) {
            JSONObject extInfo = ceit.getJSONObject("extInfo");

            //信令中的主叫号码
            //注：1.未进行号码规整，号码格式有可能不符合国际电信联盟定义的E.164标准
            if(isEmpty(extInfo,"rawCalling")) {
                String rawCalling = extInfo.getString("rawCalling");
            }
            //信令中主叫号码的号码属性
            //取值：SUBSCRIBER, UNKNOWN, INTERNATIONAL, 其他
            if(isEmpty(extInfo,"rawCallingNOA")) {
                String rawCallingNOA = extInfo.getString("rawCallingNOA");
            }
            //信令中的被叫号码
            if(isEmpty(extInfo,"rawCalled")) {
                String rawCalled = extInfo.getString("rawCalled");
            }
            //信令中被叫号码的号码属性
            //取值：SUBSCRIBE, UNKNOWN, INTERNATIONAL, 其他
            if(isEmpty(extInfo,"rawCalledNOA")) {
                String rawCalledNOA = extInfo.getString("rawCalledNOA");
            }

            //获取扩展信息(Key-Value)列表
            if(isEmpty(extInfo,"extParas")) {
                JSONArray extParas = extInfo.getJSONArray("extParas");

                //注：当呼叫状态事件时Exception，扩展信息包含信息如下
                if (event.equals("Exception")) {
                    for (int i = 0; i < extParas.size(); i++) {
                        JSONObject temp = extParas.getJSONObject(i);
                        String key = temp.getString("key");
                        String value = temp.getString("value");

                        //注:用于AXB场景
                        //标识消息的唯一ID
                        if ("UniqueId".equalsIgnoreCase(key)) {
                            String uniqueId = value;
                        }

                        //通话时长,单位：秒
                        if ("Duration".equalsIgnoreCase(key)) {
                            String duration = value;
                        }

                        //绑定关系ID
                        //注:用于AXB场景
                        if ("BindID".equalsIgnoreCase(key)) {
                            String bindID = value;
                        }

                        //呼叫开始的时间戳
                        //注:用于AXB场景
                        //格式：YYYY-MM-DDThh:mm:ss.SSSZ  示例：2013-10-09T08:33:07.789Z
                        if ("StartTime".equalsIgnoreCase(key)) {
                            String startTime = value;
                        }
                    }
                }


                //注：当呼叫状态事件时Release，扩展信息包含信息如下
                if (event.equals("Release")) {
                    //呼叫结束原因
                    //取值：Caller Hang up-主叫挂机, Called Hang up-被叫挂机,
                    //    Not Reachable-被叫不可达, Route Failure-路由被叫失败,
                    //    No Answer-被叫无应答, Abandon-主叫放弃,
                    //    Call Terminated-呼叫被终止（当绑定关系查询不到，会推送该事件）,
                    //    Call Forbidden-呼叫被禁止，比如被叫位于黑名单中
                    //    Busy-被叫忙
                    for (int i = 0; i < extParas.size(); i++) {
                        JSONObject temp = extParas.getJSONObject(i);
                        String key = temp.getString("key");
                        String value = temp.getString("value");
                        //标识消息的唯一ID
                        //注:用于AXB场景
                        if ("ReleaseReason".equalsIgnoreCase(key)) {
                            String releaseReason = value;
                        }

                        //标识消息的唯一ID
                        //注:用于AXB场景
                        if ("UniqueId".equalsIgnoreCase(key)) {
                            String uniqueId = value;
                        }

                        //绑定关系ID
                        //注:用于AXB场景
                        if ("BindID".equalsIgnoreCase(key)) {
                            String bindID = value;
                        }

                        //呼叫开始的时间戳
                        //注:用于AXB场景
                        //格式：YYYY-MM-DDThh:mm:ss.SSSZ  示例：2013-10-09T08:33:07.789Z
                        if ("StartTime".equalsIgnoreCase(key)) {
                            String startTime = value;
                        }

                        //通话时长，单位为秒
                        if ("Duration".equalsIgnoreCase(key)) {
                            String duration = value;
                        }
                    }
                }


                // 如果是Block模式，则要按接口文档进行回复响应
                if ("Block".equalsIgnoreCase(notificationMode)) {
                    JSONObject resp = new JSONObject();
                    JSONArray actions = new JSONArray();

                    JSONObject action1 = new JSONObject();
                    //操作类型录音
                    action1.put("operation", "Record");
                    actions.add(action1);

                    JSONObject action2 = new JSONObject();
                    //修改被叫或主叫号码
                    action2.put("operation", "vNumberRoute");
                    //被叫号码
                    //注：个人小号（AX模式）呼出场景必返回响应被叫号码。
                    action2.put("routingAddress", "8613800010002");

                    //来显号码
                    //仅用于X模式，并且来显号码只能为主叫真实号码，或者在小号平台注册过的虚拟号码。
                    //如果需要录音，则来显号码只支持在小号平台注册过的虚拟号码
                    //AX/AXB模式无效，不填写虚拟号码，则无法呼叫。
                    action2.put("callingAddress", "8613800010002");
                    actions.add(action2);

                    resp.put("actions", actions);
                }
            }
        }
        return "";
    }
    public boolean isEmpty(JSONObject obj, String key){
        return obj.containsKey(key);
    }
}
