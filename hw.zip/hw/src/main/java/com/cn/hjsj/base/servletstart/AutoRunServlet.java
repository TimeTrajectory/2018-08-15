package com.cn.hjsj.base.servletstart;

import com.cn.hjsj.base.load.HelperLoader;
import com.cn.hjsj.util.LogUtil;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class AutoRunServlet extends HttpServlet {
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        LogUtil.info("初始化缓存");
        HelperLoader.init();
    }
}
