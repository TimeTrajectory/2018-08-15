package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IUserDao;
import com.cn.hjsj.pojo.User;
import com.cn.hjsj.service.IUserService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("userService")
public class IUserServiceImpl implements IUserService {
    @Resource(name="IUserDao")
    private IUserDao iUserDao;

    public List<User> getUserCacheList(User user){
        return iUserDao.getUserCacheList(user);
    }
    public List<User> getList(User user){
        return iUserDao.getList(user);
    }
    public Integer insert(User user){
        return iUserDao.insert(user);
    }
    public Integer update(User user,User userParmeter){
        return iUserDao.update(user,userParmeter);
    }
    public Integer getListCount(User user){
        return iUserDao.getListCount(user);
    }


}
