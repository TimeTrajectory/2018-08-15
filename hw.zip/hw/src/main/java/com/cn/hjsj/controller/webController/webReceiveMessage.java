package com.cn.hjsj.controller.webController;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.*;
import com.cn.hjsj.service.*;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhyuj on 2018/8/24.
 * 短信通知
 */
@Controller
@RequestMapping("/webReceiveMessage")
public class webReceiveMessage {

    @Resource(name="receiveMessageService")
    private IReceiveMessageService receiveMessageService;

    //批量查询
    @ResponseBody
    @RequestMapping("/getReceiveMessageList")
    @Permission("login")
    public Object getReceiveMessageList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();

        try{//公共方法校验
            ArrayList<String> arraylist = new ArrayList<String>();  //将接口必输字段放入arraylist
            arraylist.add("pagesize");
            arraylist.add("pageNo");

            map = webCheck.checkJson(jsonstring, arraylist);
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            //业务逻辑
            JSONObject object = JSONObject.fromObject(jsonstring);
            String token = object.get("token").toString();
            JSONObject objectParameter = parseParameter(jsonstring);

            //校验token
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }


            Integer pagesize = Integer.parseInt(objectParameter.get("pagesize").toString());//每页显示条数
            Integer pageNo = Integer.parseInt(objectParameter.get("pageNo").toString());//当前页数

            int startRow = (pageNo - 1) * pagesize;
            ReceiveMessage receiveMessage = new ReceiveMessage();
            receiveMessage.setPageSize(pagesize);
            receiveMessage.setStartRow(startRow);

            // 按条件查询的总数
            int count = receiveMessageService.getListCount(receiveMessage);

            // 寻找符合条件的集合
            List<ReceiveMessage> receiveMessagesList = receiveMessageService.getList(receiveMessage);

            List receiveMessagesList1 = new ArrayList();
            for (int i=0;i<receiveMessagesList.size();i++) {
                Map mapTemp = new HashMap();
                ReceiveMessage receiveMessageBean = receiveMessagesList.get(i);
                mapTemp.put("id",receiveMessageBean.getId());//id
                mapTemp.put("smsIdentifier",receiveMessageBean.getSmsIdentifier());//短信唯一标识
                mapTemp.put("calling",receiveMessageBean.getCalling());//主叫号码
                mapTemp.put("called",receiveMessageBean.getCalled());//被叫号码
                mapTemp.put("virtualNumber",receiveMessageBean.getVirtualNumber());//虚拟号码
                mapTemp.put("notificationMode",receiveMessageBean.getNotificationMode());//通知模式
                mapTemp.put("event",receiveMessageBean.getEvent());//短信状态事件
                mapTemp.put("timeStamp",receiveMessageBean.getTimeStamp());//短信事件发生的时间戳
                mapTemp.put("createDate",receiveMessageBean.getCreateDate());//创建时间
                receiveMessagesList1.add(mapTemp);

            }

            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("userState",receiveMessagesList1);
            map1.put("count",count);
            map1.put("pageNo",pageNo);
            map.put("data",map1);

            map.put("code",10000);
            map.put("msg", "查询成功");


        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }

        return map;
    }
    //解析parameter中数据
    public static JSONObject parseParameter(String json) {
        JSONObject fromObject = JSONObject.fromObject(json);
        Object object = fromObject.get("parameter");
        JSONObject object1 = JSONObject.fromObject(object);
        return object1;
    }

}

