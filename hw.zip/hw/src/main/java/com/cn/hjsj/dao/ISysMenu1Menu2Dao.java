package com.cn.hjsj.dao;

import com.cn.hjsj.pojo.Role;
import com.cn.hjsj.pojo.SysMenu1Menu2;
import com.cn.hjsj.pojo.SysMenu2;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ISysMenu1Menu2Dao")
public interface ISysMenu1Menu2Dao {

    public List<SysMenu1Menu2> getList(SysMenu1Menu2 sysMenu1Menu2);
    public Integer update(@Param("sysMenu1Menu2") SysMenu1Menu2 sysMenu1Menu2, @Param("sysMenu1Menu2Parmeter") SysMenu1Menu2 sysMenu1Menu2Parmeter);
    public Integer insert(SysMenu1Menu2 sysMenu1Menu2);
    public Integer delete(SysMenu1Menu2 sysMenu1Menu2);
}
