package com.cn.hjsj.interfaces;

import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.verify.interfaceCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/AbilityInterface")
public class AbilityInterface extends AllResource {
    @RequestMapping(value = "/v1")
    @ResponseBody
    @Permission("login")
    public Object ability(@RequestBody String jsonstring, HttpServletRequest request) {
        LogUtil.info("/ability>>>" + jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            /* 校验账号密码、json系统级参数、签名
             * 注意：此方法未校验每个接口的必输参数
             */
            map = interfaceCheck.checkJson(jsonstring, request);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }

            int x = Integer.parseInt(map.get("apiCode").toString());
            switch (x) {
                case -1:
                    map = ability_test(map, jsonstring);
                    break;//测试
                case 1001:
                    map = ability_axbbindNumber(map, jsonstring);//AXB模式绑定
                    break;
                case 1002:
                    map = ability_axbunbindNumber(map, jsonstring);
                    break;
                case 1003:
                    map = ability_axbmodifyNumber(map, jsonstring);
                    break;
                case 2001:
                    map = ability_queryOrderedNumber(map, jsonstring);
                    break;
                case 3001:
                    map = ability_axbindNumber(map, jsonstring);
                    break;
                case 3002:
                    map = ability_axunbindNumber(map, jsonstring);
                    break;
                case 3003:
                    map = ability_axsetLogicPowerStatus(map, jsonstring);
                    break;
                case 4001:
                    map = ability_queryRecordList(map, jsonstring);
                    break;
                case 5001:
                    map = ability_queryConversationList(map, jsonstring);
                    break;
                default: {
                    map = new HashMap<String, Object>();
                    map.put("code", 21000);
                    map.put("msg", "接口编码错误");
                }
            }

        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", "内部错误，请联系管理员");
        }

        return map;
    }


    /*--------------------------------------此处开始为各个接口调用方法-------------------------------------------*/
    public Map ability_test(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_test>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("number");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }

            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());

            map = abilityTestImpl.test(paramMap);
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 交易小号AXB绑定
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axbbindNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_bindNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            // json串中含有json数组 json数组含有map类型
            String extParasString = object.get("parameter").toString();
            Map listMap = JSONObject.fromObject(extParasString);
            if (listMap.get("extParas") instanceof List) {
                for (Object objectTemp : (List) listMap.get("extParas")) {
                    Map tempMap0 = (Map) objectTemp;
                    paramMap.put(tempMap0.get("key").toString(), tempMap0.get("value"));
                }
                paramMap.remove("extParas");
            }
            //必传参数
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("aParty");
            arraylist.add("bParty");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityAXBImpl.bindNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            e.printStackTrace();
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 交易小号AXB解绑
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axbunbindNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_unbindNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            if (paramMap.get("type") != null && paramMap.get("type").toString().equals("2")) {
                arraylist.add("subscriptionId");
            } else {
                arraylist.add("number");
            }
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            if (paramMap.get("protectInfo") != null) {
                JSONObject parameter = object.getJSONObject("parameter");
                String s = parameter.get("protectInfo").toString();
                Map protectInfoMap = (Map) JSONObject.toBean(JSONObject.fromObject(s), Map.class);
                //System.out.println(protectInfoMap);
                paramMap.put("protectInfo", protectInfoMap);
            }
            map = abilityAXBImpl.unbindNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 交易小号AXB转绑
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axbmodifyNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_modifyNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("bPartyNew");
            arraylist.add("subscriptionId");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityAXBImpl.modifyNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 查询虚拟号码接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_queryOrderedNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_queryOrderedNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("virtualNumber");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityQueryOrderedNumber.QueryOrderedNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 个人小号AX绑定接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axbindNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_axbindNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            // json串中含有json数组 json数组含有map类型
            String extParasString = object.get("parameter").toString();
            Map listMap = JSONObject.fromObject(extParasString);
            if (listMap.get("extParas") instanceof List) {
                for (Object objectTemp : (List) listMap.get("extParas")) {
                    Map tempMap0 = (Map) objectTemp;
                    paramMap.put(tempMap0.get("key").toString(), tempMap0.get("value"));
                }
                paramMap.remove("extParas");
            }
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("aParty");
            arraylist.add("virtualNumber");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityAXImpl.bindNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 个人小号AX解绑接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axunbindNumber(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_axunbindNumber>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            if (paramMap.get("type") != null && paramMap.get("type").toString().equals("2")) {
                arraylist.add("subscriptionId");
            } else {
                arraylist.add("number");

            }
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityAXImpl.unbindNumber(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 个人小号 AX 逻辑开关机接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_axsetLogicPowerStatus(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_axsetLogicPowerStatus>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            arraylist.add("virtualNumber");
            arraylist.add("status");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityAXImpl.setLogicPowerStatus(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 查询录音列表接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_queryRecordList(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_queryRecordList>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            if (paramMap.get("calling") == null && paramMap.get("called") == null) {
                arraylist.add("subscriptionId");
            }
            if (paramMap.get("calling") == null && paramMap.get("subscriptionId") == null) {
                arraylist.add("called");
            }
            if (paramMap.get("subscriptionId") == null && paramMap.get("called") == null) {
                arraylist.add("calling");
            }
            arraylist.add("startTime");
            arraylist.add("endTime");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityVoiceImpl.getList(paramMap);
            return map;
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


    /**
     * 查询話單列表接口
     *
     * @param tempMap
     * @param jsonstring
     * @return
     */
    public Map ability_queryConversationList(Map tempMap, String jsonstring) {
        LogUtil.info("/ability_queryConversationList>>>" + jsonstring);
        Map<String, Object> paramMap = null, map = new HashMap<String, Object>();
        Map mapTemp = new HashMap();
        try {
            JSONObject object = JSONObject.fromObject(jsonstring);
            paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            ArrayList<String> arraylist = new ArrayList<String>();
            if (paramMap.get("calling") == null && paramMap.get("called") == null) {
                arraylist.add("virtualNumber");
            }
            if (paramMap.get("calling") == null && paramMap.get("virtualNumber") == null) {
                arraylist.add("called");
            }
            if (paramMap.get("virtualNumber") == null && paramMap.get("called") == null) {
                arraylist.add("calling");
            }
            arraylist.add("startTime");
            arraylist.add("endTime");
            boolean flag = interfaceCheck.checkParameter(paramMap, arraylist);
            if (!flag) {
                LogUtil.error("参数输入错误");
                map.put("code", 30001);
                map.put("msg", "参数输入错误");
                return map;
            }
            //将账号放入paramMap
            paramMap.put("user", tempMap.get("user").toString());
            map = abilityConversationImpl.QueryConversation(paramMap);
        } catch (Exception e) {
            LogUtil.error(e.getMessage());
            map.put("code", 30000);
            map.put("msg", e.getMessage());
        }
        return map;
    }


}
