package com.cn.hjsj.retime;

import com.cn.hjsj.retime.task.reloadUser;
import com.cn.hjsj.util.LogUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

public class timerSet {
    public Timer timer = null;

    public void timerStart() {
        timer = new Timer();

        LogUtil.info("定时器开始");
        timer.schedule(new reloadUser(), getRuntTime(), 86400000);//项目启动次日凌晨0点开始刷新内存中的编码表数据，每隔一天跑一次

    }

    private Date getRuntTime(){
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public void timerStop() {
        if (timer != null) timer.cancel();
        LogUtil.info("定时器关闭");
    }

}
