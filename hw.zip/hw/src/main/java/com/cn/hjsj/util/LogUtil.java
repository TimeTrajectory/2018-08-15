package com.cn.hjsj.util;

import org.apache.log4j.Logger;

/**
 * Created by zsj on 2018/4/13.
 */
public class LogUtil {
    private static Logger log = Logger.getLogger("Ability");

    public static void Debug(String Message) {
        log.debug(Message);
    }

    public static void info(String Message) {
        log.info(Message);
    }

    public static void warn(String Message) {
        log.warn(Message);
    }

    public static void error(String Message) {
        log.error(Message);
    }

    public static void fatal(String Message) {
        log.fatal(Message);
    }

}
