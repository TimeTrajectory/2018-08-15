package com.cn.hjsj.controller.interfaceController;


import com.cn.hjsj.interfaces.AppImpl.AbilityConversationImpl;
import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.service.IConversationService;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author duzj
 * @create 2018-09-10 16:11
 */
@Component("abilityConversation")
public class I_ConversationController implements AbilityConversationImpl {

    @Resource(name = "conversationService")
    private IConversationService conversationService;

    @Override
    public Map QueryConversation(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            System.out.println("abilityConversation:" + maps);
            Conversation conversation = new Conversation();
            if (maps.get("called") != null) {
                conversation.setCalled(maps.get("called").toString());
            }

            if (maps.get("calling") != null) {
                conversation.setCalling(maps.get("calling").toString());
            }

            if (maps.get("virtualNumber") != null) {
                conversation.setVirtualNumber(maps.get("virtualNumber").toString());
            }
            String startTime = maps.get("startTime").toString();
            String endTime = maps.get("endTime").toString();
            conversation.setStartDateTwo(startTime);
            conversation.setEndDateTwo(endTime);
            Integer listCount = conversationService.getListCount(conversation);

            conversation.setOrderColName("timeStamp");
            conversation.setOrderType("desc");

            Integer page = 1;
            Integer pageSize = 10;

            // 每页显示
            if (maps.get("pageSize") != null && Integer.parseInt(maps.get("pageSize").toString()) > 0) {
                pageSize = Integer.parseInt(maps.get("pageSize").toString());
                if (pageSize > 100) {
                    pageSize = 100;
                }
                conversation.setPageSize(pageSize);
            } else {
                conversation.setPageSize(pageSize);
            }

            // 第几页
            if (maps.get("page") != null && (Integer.parseInt(maps.get("page").toString()) - 1) > 0) {
                page = (Integer.parseInt(maps.get("page").toString()) - 1) * (conversation.getPageSize());
                conversation.setStartRow(page);
            } else {
                conversation.setStartRow((page - 1) * pageSize);
            }

            List<Conversation> resultList = conversationService.getList(conversation);


            List<Map<String, Object>> conversationDates = new ArrayList<Map<String, Object>>();
            if (resultList != null && resultList.size() > 0) {
                for (int i = 0; i < resultList.size(); i++) {
                    Map temp = new HashMap();
                    Conversation tempListOne = resultList.get(i);
                    temp.put("called",tempListOne.getCalled());
                    temp.put("callIdentifier",tempListOne.getCallIdentifier());
                    temp.put("calling",tempListOne.getCalling());
                    temp.put("virtualNumber",tempListOne.getVirtualNumber());
                    temp.put("event",tempListOne.getEvent());
                    temp.put("timestamp",tempListOne.getTimestamp());
                    temp.put("rawCalling",tempListOne.getRawCalling());
                    temp.put("rawCallingNOA",tempListOne.getRawCalledNOA());
                    temp.put("rawCalled",tempListOne.getRawCalled());
                    temp.put("rawCalledNOA",tempListOne.getRawCalledNOA());
                    temp.put("releaseReason",tempListOne.getReleaseReason());
                    temp.put("uniqueId",tempListOne.getUniqueId());
                    temp.put("bindID",tempListOne.getBindID());
                    temp.put("StartTime",tempListOne.getStartTime());
                    temp.put("duration",tempListOne.getDuration());
                    temp.put("notificationMode",tempListOne.getNotificationMode());
                    temp.put("isDow",tempListOne.getIsDow());
                    conversationDates.add(temp);
                }
            }
            Map data = new HashMap();
            data.put("result", conversationDates);
            data.put("count", listCount);
            data.put("pageNo", page);

            map.put("code", 10000);
            map.put("data", data);
            map.put("msg", "成功");
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.error("/I_ReceiveMessageController/QueryReceiveMessage--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }
        return map;
    }
}
