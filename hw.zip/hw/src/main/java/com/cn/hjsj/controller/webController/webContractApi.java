package com.cn.hjsj.controller.webController;


import com.cn.hjsj.base.annotation.Permission;
import com.cn.hjsj.pojo.UserApi;
import com.cn.hjsj.pojo.UserApiState;
import com.cn.hjsj.pojo.UserState;
import com.cn.hjsj.service.IUserApiService;
import com.cn.hjsj.service.IUserApiStateService;
import com.cn.hjsj.service.IUserStateService;
import com.cn.hjsj.util.LogUtil;
import com.cn.hjsj.util.TimeUtil;
import com.cn.hjsj.verify.webCheck;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Created by WangFeng on 2018-07-25
@Controller
@RequestMapping("/webContractApi")
public class webContractApi {

    @Resource
    private IUserApiStateService userApiStateService;
    @Resource
    private IUserApiService userApiService;

    @ResponseBody
    @RequestMapping("/getApiList")
    @Permission("login")
    public Map getApiList(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            //Map<String, Object> dataMap = new HashMap<String, Object>();
            arraylist.add("con_apiState");
            arraylist.add("pagesize");
            arraylist.add("pageNo");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);

            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            Integer con_apiState = Integer.valueOf(paramMap.get("con_apiState").toString());
            UserApiState userApiState = new UserApiState();
            userApiState.setApiState(con_apiState);
            Integer count = userApiStateService.getListCount(userApiState);
            Integer pagesize = Integer.valueOf(paramMap.get("pagesize").toString());
            Integer pageNo = Integer.valueOf(paramMap.get("pageNo").toString());
            int startRow = (pageNo - 1)*pagesize;
            userApiState.setPageSize(pagesize);
            userApiState.setStartRow(startRow);
            List<UserApiState> list = userApiStateService.getList(userApiState);
            //取出查询结果数量
            List userApiStateList =new ArrayList();
            //设置输出参数
            for (int i=0;i<list.size();i++) {
                Map apiStateMap = new HashMap();
                UserApiState tempApiState = list.get(i);
                apiStateMap.put("id",tempApiState.getId());//编号
                apiStateMap.put("userCode",tempApiState.getUserCode());//账号编号
                apiStateMap.put("enterpriseName",tempApiState.getEnterpriseName());//企业名称
                apiStateMap.put("apiCode",tempApiState.getApiCode());//签约服务编号
                apiStateMap.put("apiName",tempApiState.getApiName());//服务名称
                userApiStateList.add(apiStateMap);
            }
            Map<String,Object> map1 = new HashMap<String,Object>();
            map1.put("user_api_state",userApiStateList);
            map1.put("count",count);
            map1.put("pageNo",pageNo);
            map.put("data",map1);
            map.put("code",10000);
            map.put("msg","查询成功");

        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }


    @ResponseBody
    @RequestMapping("/conApi")
    @Permission("login")
    public Map conApi(@RequestBody String jsonstring) {
        LogUtil.info(jsonstring);
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<String> arraylist = new ArrayList<String>();
            //Map<String, Object> dataMap = new HashMap<String, Object>();
            arraylist.add("id");
            arraylist.add("examineState");
            map = webCheck.checkJson(jsonstring, arraylist);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(map.get("code").toString()) != 10000) {
                return map;
            }
            JSONObject object = JSONObject.fromObject(jsonstring);
            //校验token
            String token = object.get("token").toString();
            Map<String, Object> mapToken = webCheck.checkToken(token);
            //返回码不为10000，直接返回map
            if (Integer.parseInt(mapToken.get("code").toString()) != 10000) {
                return mapToken;
            }
            Map<String, Object> paramMap = (Map) JSONObject.toBean(JSONObject.fromObject(object.get("parameter").toString()), Map.class);
            UserApiState userApiStateParmeter = new UserApiState();//设置条件参数对象
            Integer id = Integer.parseInt(paramMap.get("id").toString());
            userApiStateParmeter.setId(id);
            UserApiState userApiState = new UserApiState();//设置要修改的参数对象
            Integer examineState = Integer.parseInt(paramMap.get("examineState").toString());
            userApiState.setApiState(examineState); //这里的审核状态实际是签约状态
            //根据不同的审核状态更改相应审核状态名称
            if (examineState == 2){//审核成功==签约成功
                userApiState.setApiStateName("已签约");
                //如果该数据签约通过则在已签约表user_api中新增一条记录
                UserApiState userApiState1 = userApiStateService.getList(userApiStateParmeter).get(0);
                //根据输入的id在user_api_state表中获取新增user_api表所需的新增数据
                String userCode = userApiState1.getUserCode();
                Integer apiCode = userApiState1.getApiCode();
                String apiName = userApiState1.getApiName();
                UserApi userApi = new UserApi();
                userApi.setUserCode(userCode);
                userApi.setApiCode(apiCode);
                userApi.setApiName(apiName);
                userApi.setState("Y");//默认新增数据为 是
                userApi.setCreateDate(TimeUtil.getNowStr());
                userApi.setUpdateDate(TimeUtil.getNowStr());
                int upCount = userApiStateService.update(userApiState,userApiStateParmeter);
                if (upCount == 1){//先判断是否更新成功
                    int addCount = userApiService.insert(userApi);
                    if (addCount == 1){//更新成功之后再判断新增是否成功
                        map.put("code",10000);
                        map.put("msg","审核成功");
                    }else {
                        map.put("code", 10003);
                        map.put("msg", "审核异常，请联系管理员");
                    }
                }else {
                    map.put("code", 10003);
                    map.put("msg", "审核失败");
                }

            }else if (examineState == 3){//审核失败==签约失败
                userApiState.setApiStateName("签约失败");
                JSONObject object1=JSONObject.fromObject(object.get("parameter").toString());
                //验证非必输参数
                if (object1.containsKey("reason")){
                    String reason = paramMap.get("reason").toString();
                    userApiState.setReason(reason);
                }
                int upCount = userApiStateService.update(userApiState,userApiStateParmeter);
                if (upCount == 1){
                    map.put("code",10000);
                    map.put("msg","审核成功");
                }else {
                    map.put("code", 10003);
                    map.put("msg", "审核失败");
                }
            }else{
                map.put("code", 10003);
                map.put("msg", "审核失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            map.put("code",30001);
            map.put("msg","系统异常，请稍后重试");
        }
        return map;
    }


}