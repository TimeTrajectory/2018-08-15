package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SysMenu1;
import com.cn.hjsj.pojo.SysRolesMenu2;

import java.util.List;

public interface ISysMenu1Service {

    public List<SysMenu1> getList(SysMenu1 sysMenu1);
    public Integer update(SysMenu1 sysMenu1,SysMenu1 sysMenu1Parmeter);

    public Integer insert(SysMenu1 sysMenu1);
    public Integer delete(SysMenu1 sysMenu1);
}
