package com.cn.hjsj.service;

import com.cn.hjsj.pojo.SysRolesMenu2;

import java.util.List;

public interface ISysRolesMenu2Service {

    public Integer insert(SysRolesMenu2 sysRolesMenu2);
    public Integer update(SysRolesMenu2 sysRolesMenu2,SysRolesMenu2 sysRolesMenu2Parmeter);
    public List<SysRolesMenu2> getList(SysRolesMenu2 sysRolesMenu2);
    public Integer delete(SysRolesMenu2 sysRolesMenu2);

}
