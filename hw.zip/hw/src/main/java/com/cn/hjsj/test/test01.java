package com.cn.hjsj.test;

import com.cn.hjsj.pojo.Conversation;
import com.cn.hjsj.service.IConversationService;
import com.cn.hjsj.service.impl.IConversationServiceImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class test01 {
    private static String DATE_FORMAT_UTC = "";
    public static void main(String[] args) throws ParseException {
        /*IConversationService iConversationService = new IConversationServiceImpl();
        Conversation conversation = new Conversation();

        List<Conversation> list = iConversationService.getList(conversation);
        System.out.println(list.size());*/
        //test01.getDate("2013-10-09T08:33:07.789Z","YYYY-MM-dd HH:mm:ss");
        String time = convertTimeFormat("2013-10-09T08:33:07.789Z");
        System.out.println(time);

        String date  = "2018-08-07";
        String[] st = date.split("-");
        for (int i=0;i<st.length;i++){
            System.out.println(st[i]);
        }
    }

    /**
     * UTC时间转换  yyyy-MM-dd'T'HH:mm:ss.SSSSSSZ eg 2016-10-26T08:20:53.131252Z:
     * @return Date
     * @throws ParseException
     * @author WANGZY25
     * @date 2016年10月26日 下午4:38:41
     * */

    public static String convertTimeFormat(String sourceTime) {

        Date resDate = null;
        String time = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");//注意格式化的表达式
            sourceTime = sourceTime.replace("Z", " UTC");//注意是空格+UTC
            resDate = format.parse( sourceTime );
            time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(resDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
            return time;
    }

    /**
     * 日期转换
     */
    private static String getDate(String timeDate,String fmt) throws ParseException {

        SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-DD'T'hh:mm:ss:SSS'Z", Locale.ENGLISH);
        SimpleDateFormat dateFormat = new SimpleDateFormat(fmt);
        Date date = format.parse(timeDate);
        String dateFmt = dateFormat.format(date);
        System.out.println(dateFmt);
        return dateFmt;
    }

}
