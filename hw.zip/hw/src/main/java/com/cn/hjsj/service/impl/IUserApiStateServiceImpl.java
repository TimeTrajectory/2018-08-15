package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.IUserApiStateDao;
import com.cn.hjsj.pojo.UserApiState;
import com.cn.hjsj.service.IUserApiStateService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("userApiStateService")
public class IUserApiStateServiceImpl implements IUserApiStateService {

    @Resource(name="IUserApiStateDao")
    private IUserApiStateDao iUserApiStateDao;

    public Integer insert(UserApiState userApiState){
        return iUserApiStateDao.insert(userApiState);
    }
    public Integer update(UserApiState userApiState,UserApiState userApiStateParmeter){
        return iUserApiStateDao.update(userApiState,userApiStateParmeter);
    }
    public List<UserApiState> getList(UserApiState userApiState){
        return iUserApiStateDao.getList(userApiState);
    }
    public Integer getListCount(UserApiState userApiState){
        return iUserApiStateDao.getListCount(userApiState);
    }

}
