/**
 * FileName: AbilityQueryOrderedNumber
 * Author:   duzenjie
 * Date:     2018/7/22 10:19
 */
package com.cn.hjsj.interfaces.AppImpl;

import java.util.Map;

public interface AbilityQueryOrderedNumber {
    public Map QueryOrderedNumber(Map maps);
}
