/**
 * FileName: AbilityBindNumberImpl
 * Author:   duzenjie
 * Date:     2018/7/21 15:25
 */
package com.cn.hjsj.interfaces.AppImpl;

import java.util.Map;

/**
 * 交易小号AXB
 */
public interface AbilityAXBImpl {
    public Map  bindNumber(Map maps);//绑定
    public Map  unbindNumber(Map maps);//解绑
    public Map  modifyNumber(Map maps);//转绑
}
