package com.cn.hjsj.service.impl;

import com.cn.hjsj.dao.ISessionTokenDao;
import com.cn.hjsj.pojo.SessionToken;
import com.cn.hjsj.service.ISessionTokenService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component("sessionTokenService")
public class ISessionTokenServiceImpl implements ISessionTokenService {
    @Resource(name="ISessionTokenDao")
    private ISessionTokenDao iSessionTokenDao;

    public List<SessionToken> getList(SessionToken sessionToken){
        return iSessionTokenDao.getList(sessionToken);
    }
    public Integer insert(SessionToken sessionToken){
        return iSessionTokenDao.insert(sessionToken);
    }
    public Integer update(SessionToken sessionToken,SessionToken sessionTokenParmeter){
        return iSessionTokenDao.update(sessionToken,sessionTokenParmeter);
    }
    public Integer getListCount(SessionToken sessionToken){
        return iSessionTokenDao.getListCount(sessionToken);
    }

    public Integer delete(SessionToken sessionToken){
        return iSessionTokenDao.delete(sessionToken);
    }//用于注销
}
