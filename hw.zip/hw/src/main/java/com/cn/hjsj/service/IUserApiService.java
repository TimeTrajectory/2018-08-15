package com.cn.hjsj.service;

import com.cn.hjsj.pojo.UserApi;
import java.util.List;

public interface IUserApiService {

    public List<UserApi> getList(UserApi userApi);
    public Integer insert(UserApi userApi);
    public Integer update(UserApi userApi,UserApi userApiParmeter);
    public Integer getListCount(UserApi userApi);
}
