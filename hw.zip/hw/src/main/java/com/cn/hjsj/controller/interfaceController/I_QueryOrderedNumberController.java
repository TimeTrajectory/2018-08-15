/**
 * FileName: I_QueryOrderedNumberController
 * Author:   duzenjie
 * Date:     2018/7/22 10:22
 */
package com.cn.hjsj.controller.interfaceController;

import com.cn.hjsj.interfaceUtil.AXBInterface;
import com.cn.hjsj.interfaces.AppImpl.AbilityQueryOrderedNumber;
import com.cn.hjsj.util.LogUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Component("abilityQueryOrderedNumber")
public class I_QueryOrderedNumberController implements AbilityQueryOrderedNumber {

    @Resource(name = "AXBInterfaceUtil")
    private AXBInterface aXBInterface;

    @Override
    public Map QueryOrderedNumber(Map maps) {
        Map<String, Object> map = new HashMap<String, Object>();

        try {
            System.out.println("abilityQueryOrderedNumber:" + maps);
            // 获取接口返回的数据
            Map data = new HashMap();
            Map result = new HashMap();
            data = aXBInterface.queryOrderedNumber(maps);
            // 接口返回数据检验
            if(!"000000".equals(data.get("code"))){
                map.put("code", 30001);
                map.put("msg", "查询虚拟号码失败");
                return map;
            }
            result = (Map) data.get("result");
            //返回
            Map resultMap = new HashMap();
            resultMap.put("result",result);
            map.put("code", 10000);
            map.put("data", resultMap);
            map.put("msg", "成功");
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.error("/I_QueryOrderedNumberController/QueryOrderedNumber--内部错误：" + e.getMessage());
            map.put("code", 39998);
            map.put("msg", "系统异常，请稍后重试");
        }

        return map;
    }
}
