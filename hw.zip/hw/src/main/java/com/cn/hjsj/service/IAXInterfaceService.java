package com.cn.hjsj.service;

import java.util.Map;

/**
 * ax模式接口
 * 
 * @author  jy
 * @version  [版本号, 2018-7-22]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public interface IAXInterfaceService
{
    /**
     * 个人小号AX绑定
     */
    String axBindNumber(Map<String,String> map);
    
    /**
     * 个人小号AX解绑
     */
    String axUnbindNumber(Map<String,String> map);
    
    /**
     * 个人小号AX逻辑开关机
     */
    String axSetLogicPowerStatus(Map<String,String> map);
    
    /**
     * 查询虚号码详情
     */
    String queryOrderedNumber(Map<String,String> map);
    
    /**
     * 查询录音列表
     */
    String queryRecordList(Map<String,String> map);
    
    /**
     * 下载录音
     */
    Boolean downloadRecord(Map<String,String> map);
    
    /**
     * 删除小号平台上的录音
     */
    String deleteRecord(Map<String,String> map);
}
