﻿// JavaScript Document
var url;
$(function(){
	url=readXML("url")+"web_login";
	HJSJ.button();
});

$(document).keyup(function(event){
  if(event.keyCode ==13){
    login();
  }
});

function login(){
	if(! HJSJ.formCheck("form1","endform1")){return false}
	var parameter=HJSJ.getEntity("form1","endform1");
		
	var machine=HJSJ.getMachine();
	//这里是用来加密的
	var sign=HJSJ.sign("login",machine,JSON.stringify(parameter));
	var sign = parameter;
	var data={};
	data["token"]="login";
	data["machine"]=machine;
	data["sign"]=sign;
	data["parameter"]=parameter;

	var requestDate=HJSJ.ajax(url+"/login",JSON.stringify(data));

	if(requestDate["code"]==10000){
		request(requestDate);
	}else if(requestDate["code"]==10004){
		
		HJSJ.prompts("error",requestDate["msg"]);
	}else if(requestDate["code"]==10003){
		HJSJ.prompts("error",requestDate["msg"]);//异常产生
	}else if(requestDate["code"]==10002){
		HJSJ.prompts("error",requestDate["msg"]);
	}else{
		
	}
}

function request(requestDate){
	if(requestDate["code"]==10000){
		
		var json=requestDate;
		HJSJ.setCookie("relt",json["data"]);
		HJSJ.setCookie("token",json["token"]);
		HJSJ.setCookie("userName",json["userName"]);
		
		$(location).attr("href", "index.html");
	}else{
		HJSJ.prompts("warning",requestDate["msg"]);	
	}
}