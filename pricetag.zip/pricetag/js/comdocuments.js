var url;
var indexUrl;
	$(function(){
		
		url=readXML("url")+"web_file";
		if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html";
			return;
			}
		HJSJ.button();
	});
//条件的赋值
function condition(s1,s2,s3,s4,s5){
	
	if(null == s1 || "undefined" == typeof(s1) || "" == s1){
	}else{//赋值
		$("#beginTime").val(s1);
	}
	if(null == s2 || "undefined" == typeof(s2) || "" == s2){
	}else{
		$("#endTime").val(s2);
	}
	if(null == s3 || "undefined" == typeof(s3) || "" == s3){
	}else{
		var select = document.getElementById("slow");
		if(s3=="1"){
			select.options[1].selected = true;  
		}else if(s3=="2"){
			select.options[2].selected = true;
		}
		
	}if(null == s4 || "undefined" == typeof(s4) || "" == s4){
	}else{
		$("#fileName").val(s4);
	}if(null == s5 || "undefined" == typeof(s5) || "" == s5){
	}else{
		$("#siteCode").val(s5);
	}
}
//绑定查询数据
function requestOrder(upfiles){
	$("#order_table").html("");
	
	
	var str='';
	var tr='';

		var str = upfiles;
		var xqo = eval('(' + str + ')');
		for(var i in xqo){
		
			HJSJ.createEle(xqo[i]);
		}
}
//遍历得到数据列表
HJSJ.createEle=function(data){
	var st='';
	var tr='';
	tr+="<td><div class='layui-unselect layui-form-checkbox selInfo' lay-skin='primary' id='"+data.id+"' onclick='synFile(this);'><i class='layui-icon'>&#xe605;</i></div></td>"
						tr+="<td>"+data.fileNo+"</td>"
						tr+="<td>"+data.fileName+"</td>"
						tr+="<td>"+data.siteCode+"</td>"
						tr+="<td>"+data.fileStateName+"</td>"
						tr+="<td>"+data.memo1+"</td>"
						tr+="<td>"+data.createBy+"</td>"
						tr+="<td><a title='下载' class='download' href='"+data.memo2+"'><i class='layui-icon'>&#xe601;</i></a>&nbsp;<a title='同步' class='download' href='javascript:void(0);' rel='"+data.id+"' onclick='synFileTo(this);'><i class='layui-icon'>&#xe609;</i></a></td>"
						st += '<tr>'+tr+'</tr>';
					var tu=$("#order_table").html();
					tu+=st;
					$("#order_table").html(tu);
}
//数字翻页
function numberChange(page){
			if(!HJSJ.formCheck("form1","endform1")){return false;}
			var parameter=HJSJ.getEntityPage("form1","endform1",5,page);
			var requestDate=HJSJ.ajax(url+"/getFileList",JSON.stringify(parameter));
			if(requestDate["code"]==10000){
				//这里进行数据的覆盖
				var json=requestDate;
				redy(json);
				
			}else{
				window.parent.alertWarning(requestDate["msg"]);
			}
		}

//条件的查询
function checkI(){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
			var cal = $("#slow").val();
			$("#state").val(cal);
			var pagesize='5';
			var pageNo='1';

			var parameter=HJSJ.getEntityPage("form1","endform1",pagesize,pageNo);
			
				var _reTimeReg = /^(?:19|20)[0-9][0-9]-(?:(?:0[1-9])|(?:1[0-2]))-(?:(?:[0-2][1-9])|(?:[1-3][0-1])) (?:(?:[0-2][0-3])|(?:[0-1][0-9])):[0-5][0-9]:[0-5][0-9]$/;
				var beginTime=parameter["beginTime"];
				var endTime=parameter["endTime"];
			//验证开始时间和结束时间必填满，否则不填
			if(null == parameter["beginTime"] || "undefined" == typeof(parameter["beginTime"]) || "" == parameter["beginTime"]){
				}else{//赋值
					if(null == parameter["endTime"] || "undefined" == typeof(parameter["endTime"]) || "" == parameter["endTime"]){
						
						window.parent.alertWarning('请选择结束时间');
						return;
					}else if(!_reTimeReg.test(beginTime)){
							window.parent.alertWarning("开始时间格式应为yyyy-MM-dd HH:mm:ss");
							//alert("开始时间格式应为yyyy-MM-dd HH:mm:ss");
							$("#beginTime").val("");
							return;
						}
				}if(null == parameter["endTime"] || "undefined" == typeof(parameter["endTime"]) || "" == parameter["endTime"]){
				}else{//赋值
					if(null == parameter["beginTime"] || "undefined" == typeof(parameter["beginTime"]) || "" == parameter["beginTime"]){
						window.parent.alertWarning('请选择开始时间');
						return;
					}else if(!_reTimeReg.test(endTime)){
							window.parent.alertWarning("结束时间格式应为yyyy-MM-dd HH:mm:ss");
							//alert("开始时间格式应为yyyy-MM-dd HH:mm:ss");
							$("#endTime").val("");
							return;
							} 
				}
				
				var startTime = new Date(Date.parse(parameter["beginTime"]));
				var endTime = new Date(Date.parse(parameter["endTime"]));
				if(startTime.getTime()>endTime.getTime()){
					
					window.parent.alertWarning('请正确选择结束时间');
					return;
				}
				//这里把条件放入cookie中防止丢失
					HJSJ.setCookie("beginTime",parameter["beginTime"]);
					HJSJ.setCookie("endTime",parameter["endTime"]);
					HJSJ.setCookie("state",parameter["state"]);
					HJSJ.setCookie("fileName",parameter["fileName"]);
					HJSJ.setCookie("siteCode",parameter["siteCode"]);
				var requestDate=HJSJ.ajax(url+"/getFileList",JSON.stringify(parameter));
				if(requestDate["code"]==10000){
					redy(requestDate);
					location.reload();
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertError(requestDate["msg"]);//异常产生
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					
				}
		}
//这里用于页面加载之前执行
function redy(json){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
			
		var count = json["count"];
		var pageNo = json["pageNo"];
		var upfiles = json["data"];
		
		$(".x-right").html("共有数据："+count+" 条");
		requestOrder(upfiles);
		
		//这里我们把存在cookie中的条件取出来
			var beginTime = HJSJ.getCookie("beginTime");
			var endTime = HJSJ.getCookie("endTime");
			var state = HJSJ.getCookie("state");
			var fileName = HJSJ.getCookie("fileName");
			var siteCode = HJSJ.getCookie("siteCode");
			condition(beginTime,endTime,state,fileName,siteCode);
			
			HJSJ.notifys("success","查询成功"+":共"+count+"条数据");
			HJSJ.paging("page",count,pageNo);
}
function FileMgt(){
	indexUrl=readXML("url")+"web_file";
		if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
	var parameter={};
	parameter["pagesize"]='5';
	parameter["pageNo"]='1';
	if(HJSJ.getCookie("beginTime")==null){
		parameter["beginTime"]="";
	}else{
		parameter["beginTime"]=HJSJ.getCookie("beginTime");
	}
	if(HJSJ.getCookie("endTime")==null){
		parameter["endTime"]="";
	}else{
		parameter["endTime"]=HJSJ.getCookie("endTime");
	}
	if(HJSJ.getCookie("state")==null){
		parameter["state"]="";
	}else{
		parameter["state"]=HJSJ.getCookie("state");
	}
	if(HJSJ.getCookie("fileName")==null){
		parameter["fileName"]="";
	}else{
		parameter["fileName"]=HJSJ.getCookie("fileName");
	}
	if(HJSJ.getCookie("siteCode")==null){
		parameter["siteCode"]="";
	}else{
		parameter["siteCode"]=HJSJ.getCookie("siteCode");
	}
	var data=JSON.stringify(parameter);
	
	var requestDate=HJSJ.ajax(indexUrl+"/getFileList",data);
	if(requestDate["code"]==10000){
		
		request(requestDate);
	}else{
		window.parent.alertError(requestDate["msg"]);
	}
	
function request(requestDate){
	if(requestDate["code"]==10000){
		var json=requestDate;
		
		redy(json);
	}else{
		window.parent.alertWarning(requestDate["msg"]);
		}
	}
}