var url;
var fileUrl;

	$(function(){
		if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html";
			return;
			}
		url=readXML("url")+"web_commodity";
		HJSJ.button();
	});
//数字翻页
function numberChange(page){
			if(!HJSJ.formCheck("form1","endform1")){return false;}
			var parameter=HJSJ.getEntityPages("form1","endform1",5,page);
			//var data=HJSJ.getData(parameter);
			var requestDate=HJSJ.ajax(url+"/getCommodityList",JSON.stringify(parameter));
			if(requestDate["code"]==10000){
				//这里进行数据的覆盖
				var json=requestDate;
				readyIn(json);
				
			}else{
				window.parent.alertWarning(requestDate["msg"]);
			}
		}
//条件的赋值
function condition(s1,s2,s3,s4){
	if(null == s1 || "undefined" == typeof(s1) || "" == s1){
	}else{//赋值
		$("#sku").val(s1);
	}if(null == s2 || "undefined" == typeof(s2) || "" == s2){
	}else{
		$("#siteCodeIn").val(s2);
	}if(null == s3 || "undefined" == typeof(s3) || "" == s3){
	}else{
		$("#itemName").val(s3);
	}if(null == s4 || "undefined" == typeof(s4) || "" == s4){
	}else{
		$("#fileNo").val(s4);
	}
}

//绑定查询数据
function requestOrder(upfiles){
	$("#order_table").html("");
	
	var str='';
	var tr='';

		var str = upfiles;
		var xqo = eval('(' + str + ')');
		for(var i in xqo){
		
			HJSJ.createEle(xqo[i]);
		}
}	
//遍历得到数据列表
HJSJ.createEle=function(data){

	var st='';
	var tr='';
	
	//tr+="<td><div class='layui-unselect layui-form-checkbox selInfo' lay-skin='primary' id='"+data.id+"' onclick='synFile(this);'><i class='layui-icon'>&#xe605;</i></div></td>"
						tr+="<td>"+data.sku+"</td>"
						tr+="<td>"+data.itemName+"</td>"
						tr+="<td>"+data.price1+"</td>"
						tr+="<td>"+data.siteCode+"</td>"
						if(data.fileAddress.trim()!=""){
							tr+="<td><a title='下载' class='download' href='"+data.fileAddress+"'><span>"+data.fileNo+"</span>&nbsp;&nbsp;&nbsp;<i class='layui-icon'>&#xe601;</i></a></td>"
						}else{
							tr+="<td><a title='下载' class='download' href='#'><span>文件未上传</span>&nbsp;&nbsp;&nbsp;<i class='layui-icon'>&#xe601;</i></a></td>"
						}						
						st += '<tr>'+tr+'</tr>';
					var tu=$("#order_table").html();
					tu+=st;
					$("#order_table").html(tu);
}
//这里要进行数据的展示
function readyIn(json){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
	
		var count = json["count"];
		var pageNo = json["pageNo"];
		var upfiles = json["data"];
		requestOrder(upfiles);
		if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
		//这里我们把存在cookie中的条件取出来
			var sku = HJSJ.getCookie("sku");
			var siteCodeIn = HJSJ.getCookie("siteCodeIn");
			var itemName = HJSJ.getCookie("itemName");
			var fileNo = HJSJ.getCookie("fileNo");
			
			condition(sku,siteCodeIn,itemName,fileNo);
			HJSJ.notifys("success","查询成功"+":共"+count+"条数据");
			HJSJ.paging("page",count,pageNo);
}
//条件的查询
function checkI(){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
	
	var pagesize='5';
	var pageNo='1';
				
			var parameter=HJSJ.getEntityPages("form1","endform1",pagesize,pageNo);
			//这里把条件放入cookie中防止丢失
			
			HJSJ.setCookie("sku",parameter["sku"]);
			HJSJ.setCookie("siteCodeIn",parameter["siteCodeIn"]);
			HJSJ.setCookie("itemName",parameter["itemName"]);
			HJSJ.setCookie("fileNo",parameter["fileNo"]);			

				var requestDate=HJSJ.ajax(url+"/getCommodityList",JSON.stringify(parameter));
				if(requestDate["code"]==10000){
					request(requestDate);
					
					location.reload();
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertError(requestDate["msg"]);//异常产生
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					
				}
}
function request(requestDate){
	if(requestDate["code"]==10000){
		var json=requestDate;
		readyIn(json);
		
	}else{
		window.parent.alertWarning(requestDate["msg"]);	
	}
}
//商品条目管理
function enClick(){
	fileUrl=readXML("url")+"web_commodity";
	if(HJSJ.getCookie("token")==null){
		parent.location.href="login.html";
			return;
	}
	var parameter={};
	parameter["pagesizeIn"]='5';
	parameter["pageNoIn"]='1';
	
	if(HJSJ.getCookie("sku")==null){
		parameter["sku"]="";
	}else{
		parameter["sku"]=HJSJ.getCookie("sku");
	}
	if(HJSJ.getCookie("siteCodeIn")==null){
		parameter["siteCodeIn"]="";
	}else{
		parameter["siteCodeIn"]=HJSJ.getCookie("siteCodeIn");
	}
	if(HJSJ.getCookie("itemName")==null){
		parameter["itemName"]="";
	}else{
		parameter["itemName"]=HJSJ.getCookie("itemName");
	}
	if(HJSJ.getCookie("fileNo")==null){
		parameter["fileNo"]="";
	}else{
		parameter["fileNo"]=HJSJ.getCookie("fileNo");
	}
	
	var data=JSON.stringify(parameter);
	
	var requestDate=HJSJ.ajax(fileUrl+"/getCommodityList",data);
	if(requestDate["code"]==10000){
		
		requestIn(requestDate);
	}else{
		window.parent.alertError(requestDate["msg"]);
	}
	
function requestIn(requestDate){
	if(requestDate["code"]==10000){
		var json=requestDate;
		
		readyIn(json);
	}else{
		window.parent.alertWarning(requestDate["msg"]);	
		}
	}
}