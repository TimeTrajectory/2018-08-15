﻿//注销登录
var returnUrl;
$(".returnLogin").click(function(){
	indexUrl=readXML("url")+"web_login";
	if(HJSJ.getCookie("token")==null){
			$(location).attr("href", "login.html");
			return;
			}
			
			var parameter = {}
			parameter["token"]=HJSJ.getCookie("token");
			var data=JSON.stringify(parameter);
		//清楚服务器端的信息
		var requestDate=HJSJ.ajax(indexUrl+"/cancel",data);
		
		//清除所有用户操做的客户端的信息
		HJSJ.destroyCookie("token");
		HJSJ.destroyCookie("userName");
		HJSJ.destroyCookie("upfiles");
		HJSJ.destroyCookie("count");
		HJSJ.destroyCookie("pageNo");
		
		HJSJ.req(requestDate);
})