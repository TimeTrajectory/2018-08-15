﻿var returnUrl;

//注销登录
function reLogin(){
	indexUrl=readXML("url")+"web_login";
	if(HJSJ.getCookie("token")==null){
			$(location).attr("href", "login.html");
			return;
			}
			
			var parameter = {}
			parameter["token"]=HJSJ.getCookie("token");
			var data=JSON.stringify(parameter);
		//清楚服务器端的信息
		var requestDate=HJSJ.ajax(indexUrl+"/cancel",data);
		
		//清除所有用户操做的客户端的信息
		HJSJ.destroyCookie("token");
		HJSJ.destroyCookie("userName");
		HJSJ.destroyCookie("upfiles");
		HJSJ.destroyCookie("count");
		HJSJ.destroyCookie("pageNo");
		HJSJ.destroyCookie("beginTime");
		HJSJ.destroyCookie("endTime");
		HJSJ.destroyCookie("state");
		HJSJ.destroyCookie("fileName");
		HJSJ.destroyCookie("siteCode");
		HJSJ.destroyCookie("pagesizeIn");
		HJSJ.destroyCookie("pageNoIn");
		HJSJ.destroyCookie("sku");
		HJSJ.destroyCookie("siteCodeInfo");
		HJSJ.destroyCookie("itemName");
		HJSJ.destroyCookie("fileNo");
		HJSJ.destroyCookie("relt");
		
		HJSJ.req(requestDate);
}
HJSJ.req = function(requestDate){
	if(requestDate["code"]==10000){
		$(".returnLogin").attr("href", "login.html");
	}else if(requestDate["code"]==10002){
		$(".returnLogin").attr("href", "login.html");
	}else{
		HJSJ.prompts("warning",requestDate["msg"]);
	}
}
//获取当前时间
function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
    return currentdate;
} 
function getTime(){
	var dateTime = getNowFormatDate();
	$(".copyright").html("Electronic price tag "+dateTime);
}