//数据同步
var url;
var a=0;
	$(function(){
			if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html";
			return;
			}
			url=readXML("url")+"web_file";
			HJSJ.button();
		});
	function delAll () {
        var data=[];
		var choose = document.getElementsByClassName("layui-form-checked");
		if(choose.length>0){
		 for ( var i = 0; i <choose.length; i++){
			if($(choose[i]).attr("id")=="a"){
				}else{
					var id = $(choose[i]).attr("id");
					data.push(id);
					}
				}	 
        }else{
			window.parent.alertWarning('你没有选中要同步的数据');	
			return;
		}
		//进行数据上传
		var requestDate=HJSJ.ajax(url+"/synchroList",JSON.stringify(data));
		if(requestDate["code"]==10000){
					
					//request(requestDate);
					location.reload();
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertWarning(requestDate["msg"]);
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					window.parent.alertWarning(requestDate["msg"]);	
				}
    }
	  
	//单个复选框选中
	function synFile (node) {
		  
		a=a+1;
		if (node.getAttribute('class')) { // 存在class属性

			if (node.getAttribute('class').indexOf('header') > -1 && node.getAttribute('class').indexOf('layui-form-checked') > -1) {
				if(a%2==1){
					
				}else{
					var id  = $("#a");
					id.removeClass("layui-form-checked");
					removeClass(node,"header");
					removeClass(node,"layui-form-checked");
				}
			}else{
				if(node.getAttribute('class').indexOf('layui-form-checked') > -1){
					var id  = $("#a");
					id.removeClass("layui-form-checked");
					removeClass(node,"layui-form-checked");
					
				}else{
				node.className += ' header';
				node.className += ' layui-form-checked';
				var classList = document.getElementsByClassName("layui-form-checked");
					if(classList.length==5){
						var id  = $("#a");
						id.addClass("layui-form-checked");
					}
				}
			}
		}
	 }	
	//删除class
	function removeClass( elements,cName ){  
		if( hasClass( elements,cName ) ){  
			elements.className = elements.className.replace( new RegExp( "(\\s|^)" + cName + "(\\s|$)" )," " ); // replace方法是替换  
		};  
	}; 
	//判断元素是否有某个class
	function hasClass( elements,cName ){  
		return !!elements.className.match( new RegExp( "(\\s|^)" + cName + "(\\s|$)") ); // ( \\s|^ ) 判断前面是否有空格 （\\s | $ ）判断后面是否有空格 两个感叹号为转换为布尔值 以方便做判断  
	}; 
	 
	  //单个同步
	function synFileTo(syso){
		var fileId = syso.rel;
			//这里做单个文件的同步
			var data={};
			data["fileId"]=fileId;
			var requestDate=HJSJ.ajax(url+"/synchro",JSON.stringify(data));
			if(requestDate["code"]==10000){
				
					//request(requestDate);
					location.reload();
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertWarning(requestDate["msg"]);
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					window.parent.alertWarning(requestDate["msg"]);	
			}
}
