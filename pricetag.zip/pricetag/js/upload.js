﻿//加载url
var urlFile;
var url;
var urlUpload
$(function(){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html";
			return;
			}
	urlFile=readXML("fileAddress");
	urlUpload=readXML("url")+"UploadController/upload";
	HJSJ.button();
});
//用于间接刷新页面
function refresh(){
		location.reload();
}
//上传按钮
$(function(){
	$("#upfile").click(function(){
		$("#file").click();
	});
});
//上传文件控件id,上传文件功能类型
function up(id,typ){
	
	

	HJSJ.upload(id,typ,urlUpload,urlFile);
	window.setTimeout("refresh()",5000);
	
}

//上传返回
function uploadResults(){
	if(fileRequestData==""){
		return false;
	}else{
		clearInterval(timer);
	}
	if(fileRequestData["code"]==200){
	//上传成功索要进行的操作,按钮内容清空
		var file = $("#file");
		file.after(file.clone().val(""));      
		file.remove(); 
		//parent.location.reload();
	}else if(fileRequestData["code"]==301){
		window.parent.alertWarning(fileRequestData["msg"]);
	}else if(fileRequestData["code"]==301){
		window.parent.alertWarning(fileRequestData["msg"]);
	}else{
		window.parent.alertWarning(fileRequestData["msg"]);
	}
	fileRequestData="";
}
	//开始时间  
		layui.use('laydate', function(){
        var laydate = layui.laydate;
        var endDate= laydate.render({
            elem: '#endTime',//选择器结束时间
            type: 'datetime',
            min:"1970-1-1",//设置min默认最小值
            done: function(value,date){
                startDate.config.max={
                    year:date.year,
                    month:date.month-1,//关键
                    date: date.date,
                    hours: 0,
                    minutes: 0,
                    seconds : 0
                }
            }
        });
        //日期范围
        var startDate=laydate.render({
            elem: '#beginTime',
            type: 'datetime',
            max:"2099-12-31",//设置一个默认最大值
            done: function(value, date){
                endDate.config.min ={
                    year:date.year,
                    month:date.month-1, //关键
                    date: date.date,
                    hours: 0,
                    minutes: 0,
                    seconds : 0
                };
            }
        });

    });