﻿var HJSJ=new Object();
var percent=0;//上传进度数据
var fileRequestData="";//上传文件返回信息
var timer;//全局定时器

//面板配色
HJSJ.panelStyle=function(id,panel){
	var data=panel["panel"];
	var divA="<div class='row-fluid' style='padding-left:1%;width:98%;'>{0}</div>";
	var a="<a href='#' id={0} onClick='destroy1(this.id)'><div class='col-xs-3' style='background:#{1};height:40px;'></div></a>";
	var panelA="";
	var i=0;
	var html="";
	for(var x in data){
		panelA=panelA+String.format(a,data[x]["name"],data[x]["colour"]);
		if(i%4==0 && i!=0){
			html=html+String.format(divA,panelA);
			panelA="";
		}
		i++;
	}
	$("#"+id).append(html);
}

//导航
HJSJ.tree=function(id,dataTree){
	var menusLev1=dataTree["menuLevel1"];
	var strLev1="<li><a href={0} class='nav-header collapsed' data-toggle='collapse'><span class='glyphicon glyphicon-phone'></span> {1}<span class='pull-right glyphicon glyphicon-chevron-down'></span></a><ul id={2} class='nav nav-list collapse secondmenu'></ul></li>";
	var html;
	for(var x in menusLev1){
		html=String.format(strLev1,"#index_"+menusLev1[x]["menuLevel1Code"],menusLev1[x]["name"],"index_"+menusLev1[x]["menuLevel1Code"]);		
		$("#"+id).append(html);
	}
	
	var menusLev2=dataTree["menuLevel2"];
	var strLev2="<li><a href='#' id={0} onClick='on(this.id)'>{1}</a></li>";
	for(var x in menusLev2){
		html=String.format(strLev2,menusLev2[x]["menuUrl"],menusLev2[x]["name"]);
		$("#index_"+menusLev2[x]["menuLevel1Code"]).append(html);
	}
};

//下拉框绑定(指定元素id，数据解析对象 entityName，数据源 json)
HJSJ.drop=function(id,entityName,json){
	$("#"+id).empty();
	var html="<li><a href='#' id='"+id+"' name=-1 onClick='HJSJ.setDropValue(this.id,this.name,this.text)'>请选择</a></li>";
	var dropLi="<li><a href='#' id={0} name={1} onClick='HJSJ.setDropValue(this.id,this.name,this.text)'>{2}</a></li>";
	var data=json[entityName];
	for(var x in data){
		html=html+String.format(dropLi,id,data[x]["code"],data[x]["name"]);
	}
	$("#"+id).append(html);
};

//下拉框绑定--附带选择事件(指定元素id，数据解析对象 entityName，数据源 json 事件函数名 functionName)
HJSJ.dropFunction=function(id,entityName,json,functionName){
	$("#"+id).empty();
	var html="<li><a href='#' id='"+id+"' name=-1 onClick='HJSJ.setDropValue(this.id,this.name,this.text);"+functionName+"(this.id)'>请选择</a></li>";
	var dropLi="<li><a href='#' id={0} name={1} onClick='HJSJ.setDropValue(this.id,this.name,this.text);{3}(this.id)'>{2}</a></li>";
	var data=json[entityName];
	for(var x in data){
		html=html+String.format(dropLi,id,data[x]["code"],data[x]["name"],functionName);
	}
	$("#"+id).append(html);
};


//选择下拉框数据选择(指定元素id,下拉数据编号name,下拉数据名称text)
HJSJ.setDropValue=function(id,name,text){
	if($("."+id).length!=2){
		HJSJ.prompts("warning","下拉元素命名超出范围");
		return;
	}
	if(name==-1){
		$("."+id).eq(0).val("");
		$("."+id).eq(1).val("");
		return;
	}
	if($("."+id).eq(0).attr("type")=="text"){
		$("."+id).eq(0).val(text);
	}else{
		$("."+id).eq(0).val(name);
	}
	
	if($("."+id).eq(1).attr("type")=="text"){
		$("."+id).eq(1).val(text);
	}else{
		$("."+id).eq(1).val(name);
	}
	//clickDrop(id);
};


//初始化按钮单击事件
HJSJ.button=function(){
	$(".initial").unbind("click");
	$(".initial").click(function(){
       	eval(this.id+"()");
    });	
};


//分页显示(指定元素id,共多少页pageTotal,当前第页数page)
HJSJ.paging=function(id,pageTotal,page){
	if(page==0){
		page=1;
	}
	pageTotal=Math.ceil(pageTotal/5);//向上取整
	$("#"+id).empty("");
	var html="<div class='row-fluid'><div class='col-xs-9'><nav aria-label='Page navigation'><ul class='pagination pull-right'>{0}</ul></nav></div></div>";
	var v0="<li><span>共<span id='user_pageTotal'>{0}</span>页：当前第<span id='user_pageNo'>{1}</span>页</span></li>{2}";
	var v1="<li class='previous'><a href='#' name={0} aria-hidden='true' onClick=pageFlip(this.name,'backward')><span class='glyphicon glyphicon-step-backward'>首页</span></a></li>";
	var v2="<li class='previous'><a href='#' name={0} aria-hidden='true' onClick=pageFlip(this.name,'left')><span class='glyphicon glyphicon-triangle-left'>上一页</span></a></li>";
	var v3="<li><a href='#' onClick=numberFlip(this.text)>{0}</a></li><li><a href='#' onClick=numberFlip(this.text)>{1}</a></li><li><a href='#' onClick=numberFlip(this.text)>{2}</a></li><li><a href='#' onClick=numberFlip(this.text)>{3}</a></li><li><a href='#' onClick=numberFlip(this.text)>{4}</a></li>";
	var v4="<li class='previous'><a href='#' name={0} aria-hidden='true' onClick=pageFlip(this.name,'right')><span class='glyphicon glyphicon-triangle-right'>下一页</span></a></li>";
	var v5="<li class='previous'><a href='#' name={0} aria-hidden='true' onClick=pageFlip(this.name,'forward')><span class='glyphicon glyphicon-step-forward'>尾页</span></a></li>";
	var sum=Math.floor((page+5) / 5)==(page+5) / 5 ? Math.floor((page+5) / 5)-1:Math.floor((page+5) / 5);
	v3=String.format(v3,sum*5-4,sum*5-3,sum*5-2,sum*5-1,sum*5);
	v1=String.format(v1,id);
	v2=String.format(v2,id);
	v4=String.format(v4,id);
	v5=String.format(v5,id);
	v0=String.format(v0,pageTotal,page,v1+v2+v3+v4+v5);
	html=String.format(html,v0);
	$("#"+id).append(html);
};

//翻页（指定元素id,按钮名称name）
function pageFlip(id,name){
	var page=1;
	if(name=="backward"){
		if($("#user_pageNo").text()==1){
			HJSJ.prompts("warning","已在首页");
			return;
		}else{
			page=1;
		}	
	}
	if(name=="left"){
		if($("#user_pageNo").text()==1){
			HJSJ.prompts("warning","已在首页");
			return;
		}else{
			page=parseInt($("#user_pageNo").text())-1;
		}
	}
	if(name=="right"){
		if($("#user_pageNo").text()==$("#user_pageTotal").text()){
			HJSJ.prompts("warning","已在尾页");
			return;
		}else{
			page=parseInt($("#user_pageNo").text())+1;
		}
	}
	if(name=="forward"){
		if($("#user_pageNo").text()==$("#user_pageTotal").text()){
			HJSJ.prompts("warning","已在尾页");
			return;
		}else{
			page=parseInt($("#user_pageTotal").text());
		}
	}
	numberChange(page);
};

//数字翻页(当前页数page)
function numberFlip(page){
	if(page<1){
		HJSJ.prompts("warning","已在首页");	
		return;
	}
	if(page>parseInt($("#user_pageTotal").text()))
	{
		HJSJ.prompts("warning","共"+$("#user_pageTotal").text()+"页，当前翻页无数据。");
		return;
	}
	$("#user_pageNo").text(page);
	numberChange(page);
};

//提示信息(提示框类型type["error","success","warning","info"],提示框内容message)
HJSJ.prompts=function(type,message){
	Lobibox.alert(type, {
   		msg: message
	});
};

//提示信息【提示完后自动退出的提示框】(type["error","success","warning","info"],提示框内容message)
HJSJ.notifys=function(type,message){
	Lobibox.notify(type, {
       icon: false,
       msg: message
    });
}

//表数据绑定(元素id,数据源json,绑定对象entity,模态框id modalId)
HJSJ.bindingTable=function(id,json,entity,modalId){
	//清空表数据
	$("."+id+"Class").remove();
	var tdLen=$("#"+id+" td").length;
	var tr="<tr class='{0}' >{1}</tr>";
	var tdList="";
	var html="";
	var td;
	var data=json[entity];
	var text="";
	for(var x in data){
		for(var i=1;i<tdLen;i++){
			if(i==1){
				if(modalId==""){
					td="<Td>{0}</Td>";
				}else{
					td="<Td><a href='#' class='tableDate_Class'   name={0} data-toggle='modal'  data-target={1}>{2}</a></Td>";
				}
				if(data[x][$("#"+id+" td").eq(i).attr("id")]==undefined){
					text="";
				}else{
					text=data[x][$("#"+id+" td").eq(i).attr("id")];
				}
				if(modalId==""){
					tdList=tdList+String.format(td,text);
				}else{
					tdList=tdList+String.format(td,data[x][$("#"+id+" td").eq(0).attr("id")],"#"+modalId,text);
				}
			}else{
				td="<Td style='overflow: hidden; white-space: nowrap; text-overflow: ellipsis;' title='{0}'>{1}</Td>";
				if(data[x][$("#"+id+" td").eq(i).attr("id")]==undefined){
					text="";
				}else{
					text=data[x][$("#"+id+" td").eq(i).attr("id")];
				}
				tdList=tdList+String.format(td,text,text);
			}
		}
		html=html+String.format(tr,id+"Class",tdList);
		tdList="";
	}
	$("#"+id).append(html);
	detailButton();
};

//初始化表数据单击事件
function detailButton(){
	$(".tableDate_Class").unbind("click");
	$(".tableDate_Class").click(function(){
       	detail(this.name);
    });	
};

//重置元素集的值（表单元素的起始位置start,验证表单元素结束位置end）
HJSJ.resets=function(start,end){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要重置表单的范围");return;}
	for(var i=subStart;i<=subEnd;i++){
		if($(".json-element").eq(i).get(0).tagName=="INPUT"){
			$(".json-element").eq(i).val("");
		}else if($(".json-element").eq(i).get(0).tagName=="IMG"){
			$(".json-element").eq(i).attr("src","");
		}else if($(".json-element").eq(i).get(0).tagName=="TEXTAREA"){
			$(".json-element").eq(i).val("");
		}else{
			$(".json-element").eq(i).text("");
		}
	}
};

//重置单个元素的值（表单元素的起始位置start,验证表单元素结束位置end,元素id）
HJSJ.resetsOne=function(start,end,id){
	//获取元素下标开始位
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要绑定表单数据的范围");return;}
	var element;
	for (var i=subStart;i<=subEnd;i++){
		element=$(".json-element").eq(i);
		if(element.attr("id")==id){
			if(element.get(0).tagName=="INPUT"){
				element.val("");
			}else if(element.get(0).tagName=="IMG"){
				element.attr("src","");
			}else{
				element.text("");
			}
		}
	}
};

//初始化日期元素
HJSJ.initialDate=function(){
	 $('.dateClass').datetimepicker({  
        language:  'zh-CN',
    	format: 'yyyy-mm-dd',
		minView: "month", //选择日期后，不会再跳转去选择时分秒
		todayBtn:  1,
    	autoclose: 1,
    });	
};
//Aajx请求
HJSJ.ajax=function(url,json){
	var requestDate="";
	$.ajax({  
			url: url,
			type:"post",
			contentType: "application/json",
			data:json, 
			cache:false, 
			async:false,//同步 false  异步 true
			success:function(data){
				requestDate=data;
			},  
			error:function(jqXHR, textStatus, errorThrown){
				var da={};
				da["code"]=10010;
				da["msg"]=jqXHR.status+":"+jqXHR.statusText;
				requestDate=da;
				//HJSJ.prompts("error",'未知错误');
			}
	});
	return requestDate;
};

//禁用按钮（元素id）
HJSJ.disButt=function(id){
	//$("#"+id).addClass("disabled");
	$("#"+id).attr('disabled',"true");
	if(undefined!=$("#"+id).attr("data-target")){
		$("#"+id).removeAttr("data-toggle");
	}
};

//启用按钮（元素id）
HJSJ.enaButt=function(id){
	$("#"+id).removeAttr("disabled");
	if(undefined!=$("#"+id).attr("data-target")){
		$("#"+id).attr("data-toggle","modal");
	}
};

//表单校验（表单元素的起始位置start,验证表单元素结束位置end）
HJSJ.formCheck=function(start,end){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要验证表单的范围");return false;}
	//遍历需要需要验证的表单
	var element;
	for(var i=subStart;i<=subEnd;i++){
		
		element=$(".json-element").eq(i);
		//非空（页面需要添加.nonEmpty）
		if(element.is(".nonEmpty")){
			if($.trim(element.val())==""){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：不能为空");
				return false;
			}
        }
		
		//数字,字母，下划线
		if(element.is(".underline")){
			var checkNum=/^\w+$/;
			if(!checkNum.test(element.val())){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：只能由数字、字母、下划线组成");
				return false;
			}
		}
		
		//数字、字母
		if(element.is(".numLetters")){
			var checkNum=/^[0-9a-zA-Z]*$/g;
			if(!checkNum.test(element.val())){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：只能由数字、字母组成");
				return false;
			}
		}
		
		//数字
		if(element.is(".digit")){
			var checkNum=/^[0-9]*$/g;
			if(!checkNum.test(element.val())){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：只能由数字");
				return false;
			}
		}
		
		//email格式
		if(element.is(".verEmail")){
			var checkNum=/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/;
			if(!checkNum.test(element.val())){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：格式不正确");
				return false;
			}
		}
		
		//手机号
		if(element.is(".mobile")){
			var checkNum=/^1[3|4|5|7|8][0-9]\d{8,8}$/;		
			if(!checkNum.test(element.val())){
				HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"：不是正确的手机号");
				return false;
			}
		}
		
		//日期控制开始时间
		if(element.is(".startDate")){
			if(element.val()!=""){
				var elementDate=$(".json-element").eq(i+1);
				if(elementDate.is(".endDate")){
					if(elementDate.val()==""){
						HJSJ.prompts("warning",$("."+elementDate.attr("id")+"Class").eq(0).text()+"不能小"+$("."+element.attr("id")+"Class").eq(0).text());
						return false;
					}
					if(getDate(element.val())>getDate(elementDate.val())){
						HJSJ.prompts("warning",$("."+elementDate.attr("id")+"Class").eq(0).text()+"不能小"+$("."+element.attr("id")+"Class").eq(0).text());
						return false;
					}//endif
				}else{
					HJSJ.prompts("warning","找不到"+$("."+element.attr("id")+"Class").eq(0).text()+",对应的结束时间");
					return false;
				}
			}
		}
		
		//日期控制结束时间
		if(element.is(".endDate")){
			if(element.val()!=""){
				var elementDate=$(".json-element").eq(i-1);
				if(elementDate.is(".startDate")){
					if(elementDate.val()==""){
						HJSJ.prompts("warning","有"+$("."+element.attr("id")+"Class").eq(0).text()+","+$("."+elementDate.attr("id")+"Class").eq(0).text()+"不能为空");
						return false;
					}
					if(getDate(elementDate.val())>getDate(element.val())){
						HJSJ.prompts("warning",$("."+element.attr("id")+"Class").eq(0).text()+"不能小于"+$("."+elementDate.attr("id")+"Class").eq(0).text());
						return false;
					}//endif
				}else{
					HJSJ.prompts("warning","找不到"+$("."+element.attr("id")+"Class").eq(0).text()+",对应的开始时间");
					return false;
				}
			}
		}
	}
	return true;
};

//设置多模态框下的按钮（模态框按钮ID ,按钮id,按钮名称text,是否保留原有按钮type）
HJSJ.setModalIdButton=function(modalButtonId,id,text,type){
	if(type){}else{$("#"+modalButtonId).empty();}
	var html="<button type='button' class='btn btn-default' data-dismiss='modal' id='clos'>关闭</button><button type='button' class='btn btn-primary initial' id={0}>{1}</button>";
	$("#"+modalButtonId).children().each(function(){
		if($(this).is("#clos")){
			html="<button type='button' class='btn btn-primary initial' id={0}>{1}</button>";
		}
	});
	html=String.format(html,id,text);
	$("#"+modalButtonId).append(html);
	HJSJ.button();
};

//设置模态框按钮（按钮id,按钮名称text,是否保留原有按钮type）
HJSJ.setButton=function(id,text,type){
	if(type){}else{$("#user_modalButton").empty();}
	var html="<button type='button' class='btn btn-default' data-dismiss='modal' id='clos'>关闭</button><button type='button' class='btn btn-primary initial' id={0}>{1}</button>";
	$("#user_modalButton").children().each(function(){
		if($(this).is("#clos")){
			html="<button type='button' class='btn btn-primary initial' id={0}>{1}</button>";
		}
	});
	html=String.format(html,id,text);
	$("#user_modalButton").append(html);
	HJSJ.button();
};

//获得元素集的值（表单元素的起始位置start,验证表单元素结束位置end）
HJSJ.getEntity=function(start,end){

	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	//alert(subStart+","+subEnd);
		
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要获取表单数据的范围");return;}
	var ent=new Object();
	var id;
	for(var i=subStart;i<=subEnd;i++){
		id=$(".json-element").eq(i).attr("id");
		
		if(id==undefined || id==""){ent=null; HJSJ.prompts("error","表单中存在无设定对象的元素") ;return JSON.stringify(ent);}
		if($(".json-element").eq(i).get(0).tagName=="INPUT"){
			if($.trim($(".json-element").eq(i).val())!=null && $.trim($(".json-element").eq(i).val())!=""){
				if(id.indexOf("password")>=0 && $(".json-element").eq(i).attr("type")=="password"){
					var ps="HJSJ"+$(".json-element").eq(i).val()+"2015GK#S";
					ent[id]=$.md5(ps).toUpperCase();
					//这里我要提交的密码先不加密
					ent[id]=$(".json-element").eq(i).val();
				}else{
					ent[id]=$(".json-element").eq(i).val();
				}
			}
		}
	}
	return ent;
};

//获得formz中指定元素的元素集的值（表单元素的起始位置start,验证表单元素结束位置end,list需要封装json的集合）
HJSJ.getEntityList=function(start,end,list){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要获取表单数据的范围");return;}
	var ent=new Object();
	var id;
	for(var i=subStart;i<=subEnd;i++){
		id=$(".json-element").eq(i).attr("id");
		if(id==undefined || id==""){ent=null; HJSJ.prompts("error","表单中存在无设定对象的元素") ;return JSON.stringify(ent);}
		if($(".json-element").eq(i).get(0).tagName=="INPUT"){
			if($.trim($(".json-element").eq(i).val())!=null && $.trim($(".json-element").eq(i).val())!=""){
				if(id=="password"){
					var ps="HJSJ"+$(".json-element").eq(i).val()+"2015GK#S";
					ent[id]=$.md5(ps).toUpperCase();
				}else{
					var result= $.inArray(id,list);
					if(result!=-1){
						ent[id]=$(".json-element").eq(i).val();
					}
				}
			}
		}else{
			if($.trim($(".json-element").eq(i).val())!=null && $.trim($(".json-element").eq(i).val())!=""){
				var result= $.inArray(id,list);
				if(result!=-1){
					ent[id]=$(".json-element").eq(i).val();
				}
			}
		}
	}
	return ent;
};

//获得元素集的值带分页（表单元素的起始位置start,验证表单元素结束位置end,每页显示条数pagesize,pageNo）
HJSJ.getEntityPage=function(start,end,pagesize,pageNo){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要获取表单数据的范围");return;}
	var ent=new Object();
	var id;	
	for(var i=subStart;i<=subEnd;i++){
		id=$(".json-element").eq(i).attr("id");
		if(id==undefined || id==""){ent=null; HJSJ.prompts("error","表单中存在无设定对象的元素"); return JSON.stringify(ent);}
		if($(".json-element").eq(i).get(0).tagName=="INPUT"){
			if($.trim($(".json-element").eq(i).val())!=null && $.trim($(".json-element").eq(i).val())!=""){
				ent[id]=$(".json-element").eq(i).val();
			}else{
				ent[id]="";
			}
		}
	}
	ent["pagesize"]=pagesize;
	ent["pageNo"]=pageNo;
	return ent;
};
//获得元素集的值带分页（表单元素的起始位置start,验证表单元素结束位置end,每页显示条数pagesize,pageNo）
HJSJ.getEntityPages=function(start,end,pagesize,pageNo){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要获取表单数据的范围");return;}
	var ent=new Object();
	var id;	
	for(var i=subStart;i<=subEnd;i++){
		id=$(".json-element").eq(i).attr("id");
		if(id==undefined || id==""){ent=null; HJSJ.prompts("error","表单中存在无设定对象的元素"); return JSON.stringify(ent);}
		if($(".json-element").eq(i).get(0).tagName=="INPUT"){
			if($.trim($(".json-element").eq(i).val())!=null && $.trim($(".json-element").eq(i).val())!=""){
				ent[id]=$(".json-element").eq(i).val();
			}else{
				ent[id]="";
			}
		}
	}
	ent["pagesizeIn"]=pagesize;
	ent["pageNoIn"]=pageNo;
	return ent;
};

//给元素集赋值（表单元素的起始位置start,验证表单元素结束位置end,数据源json)
HJSJ.formBinding=function(start,end,json){
	//获取元素下标开始位置
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要绑定表单数据的范围");return;}
	var element;
	for (var i=subStart;i<=subEnd;i++){
		element=$(".json-element").eq(i);
		if(element.get(0).tagName=="INPUT" || element.get(0).tagName=="TEXTAREA"){
			if(json[element.attr("id")]!=null){
				element.val(json[element.attr("id")]);
			}
		}else if(element.get(0).tagName=="IMG"){
			element.attr("src",imgURL+json[element.attr("id")]);
		}else{
			if(json[element.attr("id")]!=null){
				element.text(json[element.attr("id")]);
			}
		}
	}
};

//获得单个元素的值（表单元素的起始位置start,验证表单元素结束位置end,元素id）
HJSJ.getInput=function(start,end,id){
	//获取元素下标开始位
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要绑定表单数据的范围");return;}
	var element;
	for (var i=subStart;i<=subEnd;i++){
		element=$(".json-element").eq(i);
		if(element.attr("id")==id){
			if(element.get(0).tagName=="INPUT" || element.get(0).tagName=="TEXTAREA"){
				return element.val();
			}else{
				return element.text();
			}
		}
	}
	return "";
};

//设置单个元素的值（表单元素的起始位置start,验证表单元素结束位置end,元素id,要赋值的内容：content）
HJSJ.setInput=function(start,end,id,content){
	//获取元素下标开始位
	var subStart=$(".json-element").index($("."+start));
	var subEnd=$(".json-element").index($("."+end));
	if(subStart==-1 || subEnd==-1){HJSJ.prompts("error","请确认需要绑定表单数据的范围");return;}
	var element;
	for (var i=subStart;i<=subEnd;i++){
		element=$(".json-element").eq(i);
		if(element.attr("id")==id){
			if(element.get(0).tagName=="INPUT" || element.get(0).tagName=="TEXTAREA"){
				element.val(content);
				return;
			}else if(element.get(0).tagName=="IMG"){
				element.attr("src",imgURL+content);
				return;
			} else{
				element.text(content);
				return;
			}
		}
	}
};

//设置模态框拖动
HJSJ.draggable=function(id){
	//$("#"+id).draggable();//为模态对话框添加拖拽
	$("#image_modal").draggable();
}

//设置cookie(cookieName名称，cookieValue值)
HJSJ.setCookie=function(cookieName,cookieValue){
	$.cookie(cookieName,cookieValue);
};

//获取cookie(cookieName名称)
HJSJ.getCookie=function(cookieName){
	return $.cookie(cookieName);
};

//销毁cookie(cookieName名称)
HJSJ.destroyCookie=function(cookieName){
	 $.cookie(cookieName,null);
};

//参数签名
HJSJ.sign=function(token,stamp,parameter){
	var json=new Object();
	var md5=$.md5(token+parameter).toUpperCase();
	var sign=$.md5(stamp+md5).toUpperCase();
	return sign;
};

//获取服务器时间戳
function getStamp(url,token){
	var json=new Object();
	json["token"]=token;
	var resp=HJSJ.ajax(url,JSON.stringify(json));//JSON.stringify()[从一个对象中解析出字符串]
	return resp;
}

//获得随机数
HJSJ.getMachine=function(){
	var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
				 ,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
	var machine="";
	for(var i=0; i<16;i++){
		var t=parseInt(61*Math.random())
		machine=machine+chars[t];
	}
	return machine;
}


HJSJ.getData=function(parameter){
	var token=HJSJ.getCookie("token");
	var machine=HJSJ.getMachine();
	var sign=HJSJ.sign(token,machine,JSON.stringify(parameter));
	var data={};
	data["token"]=token;
	data["machine"]=machine;
	data["sign"]=sign;
	data["parameter"]=parameter;
	return JSON.stringify(data);
}

//解决关闭第二层模态框时第一层不能用的情况(id:传入的是第二次打开的模态框id)
HJSJ.hiddenModal=function(id){
	$('#'+id).on('hidden.bs.modal', function () {
  		   //if ($(".modal.fade.in").length > 0) $("body:not(.modal-open)").addClass("modal-open");  此方法也可行
		    $(document.body).addClass("modal-open");
	});
}

//读取配置文件
function readXML(id){
	var val="";
	$.ajax({
		url: "config/config.xml",
		dataType: 'xml',
		type: 'GET',
		async:false,
		timeout: 2000,
		error: function(xml)
		{
			HJSJ.prompts("error","加载XML 文件出错！");
		},
		success: function(xml)
		{
			$(xml).find("taxrate").each(function(i)
			{
				if($(this).attr("key")==id){
					val= $(this).children("value").text();
				}
			});
		}
	});
	return val;
}

//是否包含指定字符（源字符串str,指定字符串appointStr）
HJSJ.indexOf_Str=function(str,appointStr){
	if(str.indexOf(appointStr) > 0 )
	{
		return true;
	}
	return false;
};

//去除字符串中指定字符串(原字符串str,需去除的自定字符串appointStr)
HJSJ.removeStr=function(str,appointStr){
	return $.trim(str.replace(appointStr,""));
};


//上传文件控件id,上传文件功能类型,上传文件地址
HJSJ.upload=function(id,typ,url,fileUrl){
	
	var file=$("#"+id).get(0).files[0];
	var type=(file.name.substr(file.name.lastIndexOf("."))).toLowerCase();
	if(!file){
		HJSJ.prompts("warning","无上传文件");
		return false;
	}
	//.xlsx   .csv   .xls
	if(".xlsx"!=type &&".csv"!=type && ".xls"!=type){
		HJSJ.prompts("warning","上传文件不属于excel类型");
		return false;
	}
	//var fileSize1=Math.round(file.size * 100 / 1024) / 100//;'单位kb'; 
	var fileSize=Math.round(file.size * 100 / (1024 * 1024)) / 100;//'单位MB';
	if(fileSize>20){
		HJSJ.prompts("warning","上传文件不得大于20MB");
		return false;
	}

	var parameter={};
	parameter["fileType"]=typ;
	parameter["url"]=fileUrl;
	var data=HJSJ.getData(parameter);
	//将form对象直接作为参数 new FormData对象{FormData对象用以将数据编译成键值对，以便用XMLHttpRequest来发送数据}
     var formData = new FormData();
	 formData.append("par" , data);
	 
	 formData.append("file" , file);
	 $.ajax({
	　　　　type: "POST",
	　　　　url: url,
	　　　　data: formData ,　　//这里上传的数据使用了formData 对象
	　　　　processData : false, 
	　　　　//必须false才会自动加上正确的Content-Type 
	　　　　contentType : false ,
	　　　　//这里我们先拿到jQuery产生的 XMLHttpRequest对象，为其增加 progress 事件绑定，然后再返回交给ajax使用
        	xhr: function(){ //获取ajaxSettings中的xhr对象，为它的upload属性绑定progress事件的处理函数
                  myXhr = $.ajaxSettings.xhr();
                 if(myXhr.upload){ //检查upload属性是否存在
                  //绑定progress事件的回调函数
                  boxProgress();
                  myXhr.upload.addEventListener('progress',progressHandlingFunction, false);
              }
              return myXhr; //xhr对象返回给jQuery使用
          },
		success:function(data){
		    fileRequestData=data;//上传结果执行
        },
		error:function(jqXHR, textStatus, errorThrown){
			HJSJ.prompts("warning","发送服务器异常:"+jqXHR.status+","+jqXHR.statusText);
		}
　　});
}
//上传进度回调函数：
function progressHandlingFunction(e) {
    if (e.lengthComputable) {
         percent = Math.floor(e.loaded/e.total*100);
     }
}
//上传文件进度显示
function boxProgress(){
    var inter;
    Lobibox.progress({
    	title: '文件上传进度',
    	onShow: function ($this) {
    	    percent=0;
            inter = setInterval(function () {
                   if (percent >= 100) {
                       inter = clearInterval(inter);
                   }
                   $this.setProgress(percent);
             }, 10);
    	},
    	closed: function () {
    		inter = clearInterval(inter);
			timer=setInterval(function(){uploadResults();},200);
    	}
    });
}

//下载文件A标签ID,下载文件地址
HJSJ.download=function(id,url){
	$("#"+id).removeAttr("href");
	$("#"+id).attr("href",url);
	document.getElementById(id).click();
}

//拼接字符串方法
String.format = function() {
    if( arguments.length == 0 )
        return null;

    var str = arguments[0]; 
    for(var i=1;i<arguments.length;i++) {
        var re = new RegExp('\\{' + (i-1) + '\\}','gm');
        str = str.replace(re, arguments[i]);
    }
    return str;
};


//复选框赋值 checkName复选框组名称，json 数据源，entity绑定对象,field数据赋值字段
HJSJ.setChecked=function(checkName,json,entity,field){
	var check = json[entity];
	$.each(check,function(i,item){
		$("input[name="+checkName+"][value="+item[field]+"]").prop("checked","checked");
	});
}


//复选框取值 checkName复选框组名称,组合字段名称field
HJSJ.getChecked=function(checkName,field){
	var i=-1;
	var array=new Array();
	 $("input[name="+checkName+"]").each(function(index) {
		
		if ($(this).prop('checked')) {
			var par={};
			i++;
			par[field]=$(this).val(); 
			array[i]=par;
		}
     }); 
	 return array;
}

//绑定列表数据(元素id,数据源json,绑定对象entity,模态框id modalId,多选 check true/false,多选框名称 checkName,操作控制器 operation true/false,打开操作控制器模态框modalId2)
HJSJ.bindingTable2=function(id,json,entity,modalId,check,checkName,operation,modalId2){
	//清空表数据
	$("."+id+"Class").remove();
	var tdLen=$("#"+id+" td").length;
	var tr="<tr class='{0}' >{1}</tr>";
	var tdList="";
	var html="";
	var td;
	var data=json[entity];
	var text="";
	for(var x in data){
		for(var i=1;i<tdLen;i++){
			if(i==1){
				if(modalId==""){
					td="<Td>{0}</Td>";
				}else{
					td="<Td><a href='#' onClick='modalEdit(this.name)'  name={0} data-toggle='modal'  data-target={1}>{2}</a></Td>";
				}
				if(data[x][$("#"+id+" td").eq(i).attr("id")]==undefined){
					if(check && i-1==0){
						text="<input type='checkbox' name={0} value={1}>";
						text=String.format(text,checkName,data[x][$("#"+id+" td").eq(0).attr("id")]);
					}else{
						text="";
					}
				}else{
					text=data[x][$("#"+id+" td").eq(i).attr("id")];
				}
				if(modalId==""){
					tdList=tdList+String.format(td,text);
				}else{
					tdList=tdList+String.format(td,data[x][$("#"+id+" td").eq(0).attr("id")],"#"+modalId,text);
				}
			}else{
				td="<Td style='overflow: hidden; white-space: nowrap; text-overflow: ellipsis;' title='{0}'>{1}</Td>";
				if(data[x][$("#"+id+" td").eq(i).attr("id")]==undefined){
					if(operation && i+1==tdLen){
						td="<Td style='overflow: hidden; white-space: nowrap; text-overflow: ellipsis;'>{1}</Td>";
						text="<a href='#' class='tableDate_Class' name={0} data-toggle='modal' data-target={1}><span class='glyphicon glyphicon-edit'></span></a>";
						text=String.format(text,data[x][$("#"+id+" td").eq(0).attr("id")],"#"+modalId2);
					}else{
						text="";
					}
				}else{
					text=data[x][$("#"+id+" td").eq(i).attr("id")];
				}
				tdList=tdList+String.format(td,text,text);
			}
		}
		html=html+String.format(tr,id+"Class",tdList);
		tdList="";
	}
	$("#"+id).append(html);
	detailButton();
};

//data转换
function getDate(data){
 var dates = data.split("/");
 var dateReturn = '';
 
 for(var i=0; i<dates.length; i++){
  dateReturn+=dates[i];
 }
 return dateReturn;
};

//图片旋转
function aa(s){
	var jd=$("#jd").val();
	jd=parseInt(jd)+s;
	if(jd==4){jd=0;}
	if(jd==-1){jd=3;}
	document.getElementById("jd").value=jd;
	if( !document.body.filters ){
			rotate(jd);
	}
	var oDiv = document.getElementById("odiv");
	oDiv.style.filter='progid:DXImageTransform.Microsoft.BasicImage(rotation='+jd+')';
};
function rotate(jd){
	var oDiv = document.getElementById("odiv");
	oDiv.style.MozTransform = "rotate(" + jd*90 + "deg)";
	oDiv.style.webkitTransform ="rotate(" + jd*90 + "deg)";
	oDiv.style.msTransform = "rotate(" + jd*90 + "deg)";
	oDiv.style.OTransform = "rotate(" + jd*90 + "deg)";
	oDiv.style.transform = "rotate(" + jd*90 + "deg)";
};

