﻿//文件管理
var indexUrl;
HJSJ.fileClick=$(".fileManagement").click(function(){
			indexUrl=readXML("url")+"web_file";
		if(HJSJ.getCookie("token")==null){
			$(location).attr("href", "login.html");
			return;
			}
	var parameter={};
	parameter["pagesize"]='5';
	parameter["pageNo"]='1';
	var data=JSON.stringify(parameter);
	
	var requestDate=HJSJ.ajax(indexUrl+"/getFileList",data);
	if(requestDate!=""){
		//alert(requestDate["msg"]);
		request(requestDate);
	}else{
		HJSJ.prompts("error",requestDate["msg"]);
	}
	
function request(requestDate){
	if(requestDate["code"]==10000){
		var json=requestDate;
		//$(location).attr("_href", "commodity-documents.html");
		//alert(json["data"]);
		HJSJ.setCookie("upfiles",json["data"]);
		HJSJ.setCookie("count",json["count"]);
		HJSJ.setCookie("pageNo",json["pageNo"]);
		$(location).attr("_href", "commodity-documents.html");
		//HJSJ.setCookie("userName",json["userName"]);href="commodity-documents.html"
		//$("#fileManagement").attr("_href","commodity-documents.html")
	}else{
		HJSJ.prompts("warning",requestDate["msg"]);	
	}
}
		})
//注销登录
var returnUrl;
$(".returnLogin").click(function(){
	indexUrl=readXML("url")+"web_login";
	if(HJSJ.getCookie("token")==null){
			$(location).attr("href", "login.html");
			return;
			}
			
			var parameter = {}
			parameter["token"]=HJSJ.getCookie("token");
			var data=JSON.stringify(parameter);
		//清楚服务器端的信息
		var requestDate=HJSJ.ajax(indexUrl+"/cancel",data);
		
		//清除所有用户操做的客户端的信息
		HJSJ.destroyCookie("token");
		HJSJ.destroyCookie("userName");
		HJSJ.destroyCookie("upfiles");
		HJSJ.destroyCookie("count");
		HJSJ.destroyCookie("pageNo");
		
		HJSJ.req(requestDate);
})
HJSJ.req = function(requestDate){
	if(requestDate["code"]==10000){
		$(".returnLogin").attr("href", "login.html");
	}else if(requestDate["code"]==10002){
		$(".returnLogin").attr("href", "login.html");
	}else{
		HJSJ.prompts("warning",requestDate["msg"]);
	}
}
//商品管理
