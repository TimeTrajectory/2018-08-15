var url;
var siteUrl;

	$(function(){
		if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html";
			return;
			}
		url=readXML("url")+"web_commodity";
		HJSJ.button();
	});
//绑定查询数据
function requestOrder(upfiles){
	$("#order_table").html("");
	
	var str='';
	var tr='';

		var str = upfiles;
		var xqo = eval('(' + str + ')');
		for(var i in xqo){
		
			HJSJ.createEle(xqo[i]);
		}
}	
//遍历得到数据列表
HJSJ.createEle=function(data){

	var tr='';
	
					tr+="<option value="+data.siteCode+">"+data.siteCode+"-----"+data.storeName+"</option> "
					var tu=$("#order_table").html();
		
					tu+=tr;
					$("#order_table").html(tu);
}
//这里要进行数据的展示
function readyIn(json){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
	
		var count = json["count"];
		var siteCodeList = json["data"];
		$(".x-right").html("共有数据："+count+" 条");
		requestOrder(siteCodeList);			
		
		//这里我们把存在cookie中的条件取出来
			var siteCode = HJSJ.getCookie("siteCodeInfo");
			if(null == siteCode || "undefined" == typeof(siteCode) || "" == siteCode){
			}else{//赋值
				$("#siteCode").val(siteCode);
			}
			
			HJSJ.notifys("success","查询成功"+":共"+count+"条数据");
}
//条件的查询
function checkI(){
	if(HJSJ.getCookie("token")==null){
			parent.location.href="login.html"
			return;
			}
			var parameter = {};
			parameter["siteCode"] = $("#siteCode").val();
			//这里把条件放入cookie中防止丢失
			HJSJ.setCookie("siteCodeInfo",$("#siteCode").val());		

				var requestDate=HJSJ.ajax(url+"/getSideList",JSON.stringify(parameter));
				if(requestDate["code"]==10000){
					request(requestDate);
					
					location.reload();
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertError(requestDate["msg"]);//异常产生
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					
				}
}
//门店列表
function getSiteCode(){
	siteUrl=readXML("url")+"web_commodity";
	if(HJSJ.getCookie("token")==null){
		parent.location.href="login.html";
			return;
	}
	var parameter={};
	
	if(HJSJ.getCookie("siteCodeInfo")==null){
		parameter["siteCode"]="";
	}else{
		parameter["siteCode"]=HJSJ.getCookie("siteCodeInfo");
	}	
	var data=JSON.stringify(parameter);
	
	var requestDate=HJSJ.ajax(siteUrl+"/getSideList",data);
	if(requestDate["code"]==10000){
		
		request(requestDate);
	}else{
		window.parent.alertError(requestDate["msg"]);
	}
}
function request(requestDate){
	if(requestDate["code"]==10000){
		var json=requestDate;
		readyIn(json);
		
	}else{
		window.parent.alertWarning(requestDate["msg"]);	
	}
}
//添加门店
function addSite(){
			//登陆验证
			if(HJSJ.getCookie("token")==null){
				parent.location.href="login.html"
				return;
				}
			//参数校验
			var parameter = {};
			var siteCode = $("#siteCode").val();
			var storeName = $("#storeName").val();
			if($.trim(siteCode)==""){
				layer.open({
					  title: '提示信息'
					  ,content: '门店编码不能为空'
					}); 
					return;
			}
			if($.trim(storeName)==""){
				layer.open({
					  title: '提示信息'
					  ,content: '门店名称不能为空'
					}); 
					return;
			}
			
			parameter["siteCode"]=siteCode;
			parameter["storeName"]=storeName;
			
			var requestDate=HJSJ.ajax(url+"/addStore",JSON.stringify(parameter));
			if(requestDate["code"]==10000){
					
					parent.location.reload(); 
				}else if(requestDate["code"]==10004){
					window.parent.alertError(requestDate["msg"]);
				}else if(requestDate["code"]==10003){
					window.parent.alertError(requestDate["msg"]);//异常产生
				}else if(requestDate["code"]==10002){
					window.parent.alertError(requestDate["msg"]);
				}else{
					
				}
}
//添加删除节点的方法
function moveOption(e1, e2){ 
	try{
		for(var i=0;i<e1.options.length;i++){ 
			if(e1.options[i].selected){ 
				var e = e1.options[i]; 
				e2.options.add(new Option(e.text, e.value)); 
				e1.remove(i); 
				i=i-1 
			} 
		} 
	} catch(e){} 
} 
//获取erp门店
function delAllList(){
	siteUrl=readXML("url")+"web_commodity";
	//登陆验证
	if(HJSJ.getCookie("token")==null){
		parent.location.href="login.html";
			return;
	}
	//这里获取select中包含的option数据
	var siteCodeList = document.getElementById("order_site");
	str = [];
	for(i=0;i<siteCodeList.length;i++){
		str[i] = siteCodeList[i].value;
	}
	//验证
	if(str.length == 0){
		window.parent.alertWarning("请选择需要同步的门店");
		return;
	}else if(str.length < 0 || str.length>5){
		window.parent.alertWarning("同步的门店不得超过五家");
		return;
	}
	var data=JSON.stringify(str);
	window.parent.Block();
	var requestDate=HJSJ.ajax(siteUrl+"/synchroERPList",data);
		if(requestDate["code"]==10000){
	window.parent.None();
			location.reload();
		}else{
			window.parent.alertError(requestDate["msg"]);
		}
}